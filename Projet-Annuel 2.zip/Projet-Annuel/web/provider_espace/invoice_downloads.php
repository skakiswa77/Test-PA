<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';
require_once __DIR__ . '/../vendor/fpdf/fpdf.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['user_role'] !== 'provider' && $_SESSION['user_role'] !== 'admin')) {
    setAlert('Accès non autorisé. Veuillez vous connecter.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    setAlert('ID de facture non spécifié', 'danger');
    redirect(APP_URL . '/provider/invoices.php');
    exit;
}

$invoice_id = intval($_GET['id']);
$db = Database::getInstance();

try {
    if ($_SESSION['user_role'] === 'provider') {
        $invoice = $db->query(
            "SELECT pi.*, c.name as company_name, c.address as company_address,
             u.first_name, u.last_name, u.address as provider_address, u.email, u.phone
             FROM provider_invoices pi
             JOIN companies c ON pi.company_id = c.id
             JOIN users u ON pi.provider_id = u.id
             WHERE pi.id = ? AND pi.provider_id = ?",
            [$invoice_id, $_SESSION['user_id']]
        );
    } else {
        $invoice = $db->query(
            "SELECT pi.*, c.name as company_name, c.address as company_address,
             u.first_name, u.last_name, u.address as provider_address, u.email, u.phone
             FROM provider_invoices pi
             JOIN companies c ON pi.company_id = c.id
             JOIN users u ON pi.provider_id = u.id
             WHERE pi.id = ?",
            [$invoice_id]
        );
    }
    
    if (empty($invoice)) {
        throw new Exception("Facture non trouvée ou vous n'êtes pas autorisé à y accéder");
    }
    
    $invoice = $invoice[0];
    
    $services = $db->query(
        "SELECT ps.*, 
         COALESCE(e.title, CONCAT('RDV médical du ', DATE_FORMAT(ma.appointment_datetime, '%d/%m/%Y'))) as description
         FROM provider_services ps
         LEFT JOIN events e ON ps.event_id = e.id
         LEFT JOIN medical_appointments ma ON ps.appointment_id = ma.id
         WHERE ps.provider_invoice_id = ?
         ORDER BY ps.service_date",
        [$invoice_id]
    );
    
    class PDF extends FPDF {
        function Header() {
 
            $this->Image(__DIR__ . '/../assets/img/BCLogo.png', 10, 10, 30);
            $this->SetFont('Arial', 'B', 15);
            $this->Cell(0, 10, 'FACTURE', 0, 1, 'R');
            $this->Ln(20);
        }
        
        function Footer() {
            $this->SetY(-15);
            $this->SetFont('Arial', 'I', 8);
            $this->Cell(0, 10, 'Business Care - Page ' . $this->PageNo(), 0, 0, 'C');
        }
    }
    
    $pdf = new PDF();
    $pdf->AddPage();
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Informations de facturation', 0, 1);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(95, 7, 'Prestataire:', 0, 0);
    $pdf->Cell(95, 7, 'Client:', 0, 1);
    
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(95, 7, $invoice['first_name'] . ' ' . $invoice['last_name'], 0, 0);
    $pdf->Cell(95, 7, $invoice['company_name'], 0, 1);
    
    $pdf->SetFont('Arial', '', 10);
    $provider_address = explode("\n", $invoice['provider_address']);
    foreach ($provider_address as $line) {
        $pdf->Cell(95, 5, $line, 0, 0);
        $pdf->Cell(95, 5, '', 0, 1);
    }

    $pdf->SetXY($pdf->GetX() + 95, $pdf->GetY() - count($provider_address) * 5);
    $company_address = explode("\n", $invoice['company_address']);
    foreach ($company_address as $line) {
        $pdf->Cell(95, 5, $line, 0, 1);
    }
    
    $pdf->Ln(5);
    $pdf->Cell(95, 5, 'Email: ' . $invoice['email'], 0, 0);
    $pdf->Cell(95, 5, '', 0, 1);
    
    $pdf->Cell(95, 5, 'Tél: ' . $invoice['phone'], 0, 0);
    $pdf->Cell(95, 5, '', 0, 1);
    
    $pdf->Ln(10);
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Détails de la facture', 0, 1);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(47.5, 7, 'Numéro de facture:', 0, 0);
    $pdf->Cell(47.5, 7, $invoice['invoice_number'], 0, 0);
    $pdf->Cell(47.5, 7, 'Date d\'émission:', 0, 0);
    $pdf->Cell(47.5, 7, date('d/m/Y', strtotime($invoice['issue_date'])), 0, 1);
    
    $pdf->Cell(47.5, 7, 'Date d\'échéance:', 0, 0);
    $pdf->Cell(47.5, 7, date('d/m/Y', strtotime($invoice['due_date'])), 0, 0);
    $pdf->Cell(47.5, 7, 'Statut:', 0, 0);
    
    $status = '';
    switch ($invoice['status']) {
        case 'pending':
            $status = 'En attente';
            break;
        case 'paid':
            $status = 'Payée';
            break;
        case 'cancelled':
            $status = 'Annulée';
            break;
    }
    
    $pdf->Cell(47.5, 7, $status, 0, 1);
    
    $pdf->Ln(10);
    
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 7, 'Date', 1, 0, 'C');
    $pdf->Cell(80, 7, 'Description', 1, 0, 'C');
    $pdf->Cell(25, 7, 'Heures', 1, 0, 'C');
    $pdf->Cell(25, 7, 'Taux', 1, 0, 'C');
    $pdf->Cell(30, 7, 'Montant', 1, 1, 'C');
    
    $pdf->SetFont('Arial', '', 10);
    $total = 0;
    
    foreach ($services as $service) {
        $pdf->Cell(30, 7, date('d/m/Y', strtotime($service['service_date'])), 1, 0, 'C');
        $pdf->Cell(80, 7, $service['description'], 1, 0, 'L');
        $pdf->Cell(25, 7, $service['hours'], 1, 0, 'C');
        $pdf->Cell(25, 7, number_format($service['rate'], 2, ',', ' ') . ' €', 1, 0, 'R');
        $pdf->Cell(30, 7, number_format($service['total_amount'], 2, ',', ' ') . ' €', 1, 1, 'R');
        
        $total += $service['total_amount'];
    }
    
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(160, 7, 'Total', 1, 0, 'R');
    $pdf->Cell(30, 7, number_format($total, 2, ',', ' ') . ' €', 1, 1, 'R');
    
    $pdf->Ln(10);
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Conditions de paiement', 0, 1);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 5, 'Paiement à réception de facture. Tout paiement effectué après la date d\'échéance pourra faire l\'objet de pénalités.');
    
    $pdf->Ln(5);
    $pdf->MultiCell(0, 5, 'Merci de votre confiance. Pour toute question concernant cette facture, veuillez contacter Business Care à contact@business-care.fr.');
    
    $pdf->Ln(10);
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(0, 10, 'Informations bancaires', 0, 1);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(47.5, 7, 'Bénéficiaire:', 0, 0);
    $pdf->Cell(142.5, 7, 'Business Care', 0, 1);
    
    $pdf->Cell(47.5, 7, 'IBAN:', 0, 0);
    $pdf->Cell(142.5, 7, 'FR76 1234 5678 9101 1121 3141 516', 0, 1);
    
    $pdf->Cell(47.5, 7, 'BIC:', 0, 0);
    $pdf->Cell(142.5, 7, 'BNPAFR123', 0, 1);
    
    $fileName = 'facture_' . $invoice['invoice_number'] . '.pdf';
    
    $pdfPath = '/uploads/invoices/' . $fileName;
    $db->execute(
        "UPDATE provider_invoices SET pdf_path = ? WHERE id = ?",
        [$pdfPath, $invoice_id]
    );
    
    $uploadDir = __DIR__ . '/../uploads/invoices/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $pdf->Output('F', $uploadDir . $fileName);
    $pdf->Output('D', $fileName);
    
} catch (Exception $e) {
    setAlert('Erreur: ' . $e->getMessage(), 'danger');
    redirect(APP_URL . '/provider/invoices.php');
}
?>