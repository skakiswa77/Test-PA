<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Utilisateurs</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php


    require_once '../../config/database.php';

    $stmt = $pdo->query("SELECT u.*, c.name as company_name FROM users u 
                    LEFT JOIN companies c ON u.company_id = c.id
                    WHERE u.is_active = 1
                    ORDER BY u.last_name, u.first_name");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <?php
    require_once '../../composants/nav.php';
    ?>

    <h2>Gestion des Utilisateurs</h2>
    <a href="add.php">Ajouter un utilisateur</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Rôle</th>
            <th>Entreprise</th>
            <th>Dernière connexion</th>
            <th>Date de création</th>
            <th>Actions</th>
        </tr>

        <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo htmlspecialchars($user['last_name'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($user['first_name'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($user['phone'] ?? ''); ?></td>
                <td><?php echo htmlspecialchars($user['role'] ?? ''); ?></td>
                <td><?php echo !empty($user['company_name']) ? htmlspecialchars($user['company_name']) : 'N/A'; ?></td>
                <td><?php echo $user['last_login'] ? date('d/m/Y H:i', strtotime($user['last_login'])) : 'Jamais'; ?></td>
                <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $user['id']; ?>">Modifier</a>
                    <a href="deactivate.php?id=<?php echo $user['id']; ?>"
                        onclick="return confirm('Voulez-vous vraiment désactiver cet utilisateur ?')">Désactiver</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

</body>

</html>