<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'company_admin') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que entreprise.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$admin_id = $_SESSION['user_id'];
$db = Database::getInstance();

$company_id = $db->query(
    "SELECT company_id FROM users WHERE id = ?",
    [$admin_id],
    true
)['company_id'];

if (!$company_id) {
    $error_message = "Erreur: Vous n'êtes pas associé à une entreprise.";
} else {

    $company = $db->query(
        "SELECT * FROM companies WHERE id = ?",
        [$company_id],
        true
    );

    $admin = $db->query(
        "SELECT * FROM users WHERE id = ?",
        [$admin_id],
        true
    );

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_company'])) {
        $company_name = trim($_POST['company_name']);
        $company_address = trim($_POST['company_address']);
        $company_phone = trim($_POST['company_phone']);
        $company_email = trim($_POST['company_email']);

        if (!empty($company_name) && !empty($company_email)) {
            try {
                $db->update(
                    'companies',
                    [
                        'name' => $company_name,
                        'address' => $company_address,
                        'phone' => $company_phone,
                        'email' => $company_email
                    ],
                    'id = ?',
                    [$company_id]
                );

                $company_success_message = "Les informations de l'entreprise ont été mises à jour avec succès.";

                $company['name'] = $company_name;
                $company['address'] = $company_address;
                $company['phone'] = $company_phone;
                $company['email'] = $company_email;
            } catch (Exception $e) {
                $company_error_message = "Une erreur est survenue lors de la mise à jour: " . $e->getMessage();
            }
        } else {
            $company_error_message = "Le nom et l'email de l'entreprise sont obligatoires.";
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_admin'])) {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $postal_code = trim($_POST['postal_code']);
        $city = trim($_POST['city']);

        if (!empty($first_name) && !empty($last_name)) {
            try {
                $db->update(
                    'users',
                    [
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'phone' => $phone,
                        'address' => $address,
                        'postal_code' => $postal_code,
                        'city' => $city
                    ],
                    'id = ?',
                    [$admin_id]
                );

                $admin_success_message = "Vos informations personnelles ont été mises à jour avec succès.";

                $admin['first_name'] = $first_name;
                $admin['last_name'] = $last_name;
                $admin['phone'] = $phone;
                $admin['address'] = $address;
                $admin['postal_code'] = $postal_code;
                $admin['city'] = $city;

              
                $_SESSION['first_name'] = $first_name;
                $_SESSION['last_name'] = $last_name;
            } catch (Exception $e) {
                $admin_error_message = "Une erreur est survenue lors de la mise à jour: " . $e->getMessage();
            }
        } else {
            $admin_error_message = "Le prénom et le nom sont obligatoires.";
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];

        if (!empty($current_password) && !empty($new_password) && !empty($confirm_password)) {
            $hashed_password = $db->query(
                "SELECT password FROM users WHERE id = ?",
                [$admin_id],
                true
            )['password'];

            if (password_verify($current_password, $hashed_password)) {
                if ($new_password === $confirm_password) {
                    if (strlen($new_password) >= 8) {
                        try {
                            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                            $db->update(
                                'users',
                                ['password' => $new_hashed_password],
                                'id = ?',
                                [$admin_id]
                            );

                            $password_success_message = "Votre mot de passe a été changé avec succès.";
                        } catch (Exception $e) {
                            $password_error_message = "Une erreur est survenue lors du changement de mot de passe: " . $e->getMessage();
                        }
                    } else {
                        $password_error_message = "Le nouveau mot de passe doit contenir au moins 8 caractères.";
                    }
                } else {
                    $password_error_message = "Les nouveaux mots de passe ne correspondent pas.";
                }
            } else {
                $password_error_message = "Le mot de passe actuel est incorrect.";
            }
        } else {
            $password_error_message = "Tous les champs sont obligatoires.";
        }
    }
}

?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Profil de l'entreprise</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>

                    <ul class="nav nav-tabs" id="profileTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="company-tab" data-toggle="tab" href="#company" role="tab"
                                aria-controls="company" aria-selected="true">Informations de l'entreprise</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="admin-tab" data-toggle="tab" href="#admin" role="tab"
                                aria-controls="admin" aria-selected="false">Informations personnelles</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="security-tab" data-toggle="tab" href="#security" role="tab"
                                aria-controls="security" aria-selected="false">Sécurité</a>
                        </li>
                    </ul>

                    <div class="tab-content mt-3" id="profileTabsContent">

                        <div class="tab-pane fade show active" id="company" role="tabpanel"
                            aria-labelledby="company-tab">
                            <?php if (isset($company_success_message)): ?>
                                <div class="alert alert-success"><?php echo $company_success_message; ?></div>
                            <?php endif; ?>

                            <?php if (isset($company_error_message)): ?>
                                <div class="alert alert-danger"><?php echo $company_error_message; ?></div>
                            <?php endif; ?>

                            <form method="post" action="">
                                <div class="form-group">
                                    <label for="company_name">Nom de l'entreprise *</label>
                                    <input type="text" name="company_name" id="company_name" class="form-control"
                                        value="<?php echo htmlspecialchars($company['name']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="company_address">Adresse</label>
                                    <textarea name="company_address" id="company_address" class="form-control"
                                        rows="3"><?php echo htmlspecialchars($company['address']); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="company_phone">Téléphone</label>
                                    <input type="tel" name="company_phone" id="company_phone" class="form-control"
                                        value="<?php echo htmlspecialchars($company['phone']); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="company_email">Email *</label>
                                    <input type="email" name="company_email" id="company_email" class="form-control"
                                        value="<?php echo htmlspecialchars($company['email']); ?>" required>
                                </div>
                                <button type="submit" name="update_company" class="btn btn-primary">Mettre à
                                    jour</button>
                            </form>
                        </div>


                        <div class="tab-pane fade" id="admin" role="tabpanel" aria-labelledby="admin-tab">
                            <?php if (isset($admin_success_message)): ?>
                                <div class="alert alert-success"><?php echo $admin_success_message; ?></div>
                            <?php endif; ?>

                            <?php if (isset($admin_error_message)): ?>
                                <div class="alert alert-danger"><?php echo $admin_error_message; ?></div>
                            <?php endif; ?>

                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <img src="/web/assets/img/avatar.jpg" alt="Photo de profil"
                                            class="img-fluid rounded-circle mb-3" style="max-width: 150px;">
                                        <h5><?php echo htmlspecialchars($admin['first_name'] . ' ' . $admin['last_name']); ?>
                                        </h5>
                                        <p class="text-muted"><?php echo htmlspecialchars($admin['email']); ?></p>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <form method="post" action="">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="first_name">Prénom *</label>
                                                    <input type="text" name="first_name" id="first_name"
                                                        class="form-control"
                                                        value="<?php echo htmlspecialchars($admin['first_name']); ?>"
                                                        required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="last_name">Nom *</label>
                                                    <input type="text" name="last_name" id="last_name"
                                                        class="form-control"
                                                        value="<?php echo htmlspecialchars($admin['last_name']); ?>"
                                                        required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="phone">Téléphone</label>
                                            <input type="tel" name="phone" id="phone" class="form-control"
                                                value="<?php echo htmlspecialchars($admin['phone']); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="address">Adresse</label>
                                            <input type="text" name="address" id="address" class="form-control"
                                                value="<?php echo htmlspecialchars($admin['address']); ?>">
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="postal_code">Code postal</label>
                                                    <input type="text" name="postal_code" id="postal_code"
                                                        class="form-control"
                                                        value="<?php echo htmlspecialchars($admin['postal_code']); ?>">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="city">Ville</label>
                                                    <input type="text" name="city" id="city" class="form-control"
                                                        value="<?php echo htmlspecialchars($admin['city']); ?>">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" name="update_admin" class="btn btn-primary">Mettre à
                                            jour</button>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <div class="tab-pane fade" id="security" role="tabpanel" aria-labelledby="security-tab">
                            <?php if (isset($password_success_message)): ?>
                                <div class="alert alert-success"><?php echo $password_success_message; ?></div>
                            <?php endif; ?>

                            <?php if (isset($password_error_message)): ?>
                                <div class="alert alert-danger"><?php echo $password_error_message; ?></div>
                            <?php endif; ?>

                            <h5>Changer le mot de passe</h5>
                            <form method="post" action="">
                                <div class="form-group">
                                    <label for="current_password">Mot de passe actuel *</label>
                                    <input type="password" name="current_password" id="current_password"
                                        class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label for="new_password">Nouveau mot de passe *</label>
                                    <input type="password" name="new_password" id="new_password" class="form-control"
                                        required>
                                    <small class="form-text text-muted">Le mot de passe doit contenir au moins 8
                                        caractères.</small>
                                </div>
                                <div class="form-group">
                                    <label for="confirm_password">Confirmer le nouveau mot de passe *</label>
                                    <input type="password" name="confirm_password" id="confirm_password"
                                        class="form-control" required>
                                </div>
                                <button type="submit" name="change_password" class="btn btn-primary">Changer le mot de
                                    passe</button>
                            </form>

                            <hr>

                            <h5>Dernières connexions</h5>
                            <?php
                            $login_logs = $db->query(
                                "SELECT * FROM action_logs
                                WHERE user_id = ? AND action IN ('login', 'login_failed', 'logout')
                                ORDER BY created_at DESC
                                LIMIT 5",
                                [$admin_id]
                            );
                            ?>

                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Action</th>
                                            <th>IP</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($login_logs as $log): ?>
                                            <tr>
                                                <td><?php echo date('d/m/Y H:i', strtotime($log['created_at'])); ?></td>
                                                <td>
                                                    <?php
                                                    switch ($log['action']) {
                                                        case 'login':
                                                            echo '<span class="text-success">Connexion réussie</span>';
                                                            break;
                                                        case 'login_failed':
                                                            echo '<span class="text-danger">Échec de connexion</span>';
                                                            break;
                                                        case 'logout':
                                                            echo '<span class="text-secondary">Déconnexion</span>';
                                                            break;
                                                    }
                                                    ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($log['ip_address']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>