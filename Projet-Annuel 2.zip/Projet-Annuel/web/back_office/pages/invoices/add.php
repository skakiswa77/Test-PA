<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Facture</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
require_once '../../composants/nav.php';
require_once '../../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $stmt = $pdo->prepare("INSERT INTO invoices (company_id, subscription_id, invoice_number, amount, issue_date, 
                          due_date, status, payment_method, created_at, updated_at)
                           VALUES (:company_id, :subscription_id, :invoice_number, :amount, :issue_date, 
                          :due_date, :status, :payment_method, NOW(), NOW())");
        $stmt->execute([
            ':company_id' => $_POST['company_id'],
            ':subscription_id' => $_POST['subscription_id'] ?: null,
            ':invoice_number' => $_POST['invoice_number'],
            ':amount' => $_POST['amount'],
            ':issue_date' => $_POST['issue_date'],
            ':due_date' => $_POST['due_date'],
            ':status' => $_POST['status'],
            ':payment_method' => $_POST['payment_method']
        ]);

        header("Location: index.php");
        exit();
    }

    $stmt = $pdo->query("SELECT id, name FROM companies ORDER BY name");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, plan_id FROM subscriptions");
    $subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Ajouter une Facture</h2>
    <form method="POST">
        <label for="company_id">Entreprise</label>
        <select name="company_id" id="company_id" required>
            <option value="">Sélectionner une entreprise</option>
            <?php foreach ($companies as $company): ?>
                <option value="<?php echo $company['id']; ?>">
                    <?php echo htmlspecialchars($company['name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="subscription_id">Abonnement (optionnel)</label>
        <select name="subscription_id" id="subscription_id">
            <option value="">Aucun abonnement</option>
            <?php foreach ($subscriptions as $subscription): ?>
                <option value="<?php echo $subscription['id']; ?>">
                    ID: <?php echo $subscription['id']; ?> (Plan: <?php echo $subscription['plan_id']; ?>)
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="invoice_number">Numéro de facture</label>
        <input type="text" name="invoice_number" id="invoice_number" placeholder="ex: INV-2025-001" required><br>

        <label for="amount">Montant</label>
        <input type="number" name="amount" id="amount" step="0.01" placeholder="0.00" required><br>

        <label for="issue_date">Date d'émission</label>
        <input type="date" name="issue_date" id="issue_date" required><br>

        <label for="due_date">Date d'échéance</label>
        <input type="date" name="due_date" id="due_date" required><br>

        <label for="status">Statut</label>
        <select name="status" id="status" required>
            <option value="pending">En attente</option>
            <option value="paid">Payée</option>
            <option value="overdue">En retard</option>
            <option value="cancelled">Annulée</option>
        </select><br>

        <label for="payment_method">Mode de paiement</label>
        <select name="payment_method" id="payment_method">
            <option value="">Aucun</option>
            <option value="credit_card">Carte bancaire</option>
            <option value="bank_transfer">Virement bancaire</option>
            <option value="direct_debit">Prélèvement automatique</option>
        </select><br>

        <button type="submit">Ajouter la Facture</button>
    </form>

</body>

</html>