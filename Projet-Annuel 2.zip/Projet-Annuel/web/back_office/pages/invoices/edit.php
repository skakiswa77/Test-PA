<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Facture</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
require_once '../../composants/nav.php';
require_once '../../config/database.php';


    $id = $_GET['id'];


    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $stmt = $pdo->prepare("UPDATE invoices SET company_id = :company_id, subscription_id = :subscription_id, 
                          invoice_number = :invoice_number, amount = :amount, issue_date = :issue_date, 
                          due_date = :due_date, status = :status, payment_method = :payment_method,
                          updated_at = NOW()
                          WHERE id = :id");
        $stmt->execute([
            ':company_id' => $_POST['company_id'],
            ':subscription_id' => $_POST['subscription_id'] ?: null,
            ':invoice_number' => $_POST['invoice_number'],
            ':amount' => $_POST['amount'],
            ':issue_date' => $_POST['issue_date'],
            ':due_date' => $_POST['due_date'],
            ':status' => $_POST['status'],
            ':payment_method' => $_POST['payment_method'],
            ':id' => $id
        ]);

        header("Location: index.php");
        exit();
    }


    $stmt = $pdo->prepare("SELECT * FROM invoices WHERE id = ?");
    $stmt->execute([$id]);
    $invoice = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, name FROM companies ORDER BY name");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, plan_id FROM subscriptions");
    $subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Modifier une Facture</h2>
    <form method="POST">
        <label for="company_id">Entreprise</label>
        <select name="company_id" id="company_id" required>
            <option value="">Sélectionner une entreprise</option>
            <?php foreach ($companies as $company): ?>
                <option value="<?php echo $company['id']; ?>" <?php if ($invoice['company_id'] == $company['id'])
                       echo 'selected'; ?>>
                    <?php echo htmlspecialchars($company['name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="subscription_id">Abonnement (optionnel)</label>
        <select name="subscription_id" id="subscription_id">
            <option value="">Aucun abonnement</option>
            <?php foreach ($subscriptions as $subscription): ?>
                <option value="<?php echo $subscription['id']; ?>" <?php if ($invoice['subscription_id'] == $subscription['id'])
                       echo 'selected'; ?>>
                    ID: <?php echo $subscription['id']; ?> (Plan: <?php echo $subscription['plan_id']; ?>)
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="invoice_number">Numéro de facture</label>
        <input type="text" name="invoice_number" id="invoice_number"
            value="<?php echo htmlspecialchars($invoice['invoice_number']); ?>" required><br>

        <label for="amount">Montant</label>
        <input type="number" name="amount" id="amount" step="0.01" value="<?php echo $invoice['amount']; ?>"
            required><br>

        <label for="issue_date">Date d'émission</label>
        <input type="date" name="issue_date" id="issue_date" value="<?php echo $invoice['issue_date']; ?>" required><br>

        <label for="due_date">Date d'échéance</label>
        <input type="date" name="due_date" id="due_date" value="<?php echo $invoice['due_date']; ?>" required><br>

        <label for="status">Statut</label>
        <select name="status" id="status" required>
            <option value="pending" <?php if ($invoice['status'] == 'pending')
                echo 'selected'; ?>>En attente</option>
            <option value="paid" <?php if ($invoice['status'] == 'paid')
                echo 'selected'; ?>>Payée</option>
            <option value="overdue" <?php if ($invoice['status'] == 'overdue')
                echo 'selected'; ?>>En retard</option>
            <option value="cancelled" <?php if ($invoice['status'] == 'cancelled')
                echo 'selected'; ?>>Annulée</option>
        </select><br>

        <label for="payment_method">Mode de paiement</label>
        <select name="payment_method" id="payment_method">
            <option value="">Aucun</option>
            <option value="credit_card" <?php if ($invoice['payment_method'] == 'credit_card')
                echo 'selected'; ?>>Carte
                bancaire</option>
            <option value="direct_debit" <?php if ($invoice['payment_method'] == 'direct_debit')
                echo 'selected'; ?>>
                Prélèvement automatique</option>
        </select><br>

        <button type="submit">Mettre à jour la Facture</button>
    </form>

</body>

</html>