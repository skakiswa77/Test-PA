<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
ob_start();
session_start();

$webPath = dirname(__DIR__);

require_once $webPath . '/utils/database.php';

if (!isset($pdo) || !$pdo) {
    error_log("Erreur critique: La connexion à la base de données n'est pas disponible dans contact_process.php");
    
    try {
        $host = 'localhost';
        $dbname = 'business_care';
        $user = 'root'; 
        $password = 'root'; 
        $port = '8889';
        
        $dsn = "mysql:host=$host;dbname=$dbname;port=$port;charset=utf8";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        
        $pdo = new PDO($dsn, $user, $password, $options);
        error_log("Connexion à la base de données établie dans contact_process.php");
    } catch (PDOException $e) {
        error_log("Erreur de connexion à la base de données dans contact_process.php: " . $e->getMessage());
    }
}

function redirect($url) {

    ob_end_clean();
    header("Location: $url");
    exit;
}

require_once $webPath . '/vendor/phpmailer/phpmailer/src/Exception.php';
require_once $webPath . '/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once $webPath . '/vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

function sendContactEmail($to, $subject, $body, $replyToEmail = '', $replyToName = '') {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'businesscareams@gmail.com';
        $mail->Password   = 'jtew sppg slcq xpqr';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';
        
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];
        
        $mail->Timeout = 60;
        
        $mail->SMTPDebug = 0;
        
        $mail->setFrom('businesscareams@gmail.com', 'Business Care');
        $mail->addAddress($to);
        
        if ($replyToEmail) {
            $mail->addReplyTo($replyToEmail, $replyToName);
        }
        
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        $mail->AltBody = strip_tags($body);
        
        $mail->SMTPAutoTLS = false;

        $result = $mail->send();
        error_log("Email envoyé avec succès à $to");
        return $result;
    } catch (Exception $e) {
        error_log("Erreur d'envoi d'email à $to: " . $mail->ErrorInfo);
        return false;
    }
}

function saveContactMessageToDatabase($name, $email, $phone, $company, $subject, $message) {
    global $pdo;
    
    if (!isset($pdo) || !$pdo) {
        error_log("Impossible d'enregistrer le message dans la base de données: connexion PDO non disponible");
        return false;
    }
    
    try {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
        
        $stmt = $pdo->prepare("
            INSERT INTO contact_messages (name, email, phone, company, subject, message, status, ip_address, user_agent, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'unread', ?, ?, NOW())
        ");
        
        $result = $stmt->execute([$name, $email, $phone, $company, $subject, $message, $ip_address, $user_agent]);
        if ($result) {
            error_log("Message de contact enregistré dans la base de données pour: $email");
        } else {
            error_log("Échec de l'enregistrement dans la base de données pour: $email");
        }
        return $result;
    } catch (PDOException $e) {
        error_log("Erreur d'enregistrement du message de contact: " . $e->getMessage());
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_SPECIAL_CHARS);
    $company = filter_input(INPUT_POST, 'company', FILTER_SANITIZE_SPECIAL_CHARS);
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_SPECIAL_CHARS);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_SPECIAL_CHARS);
    $privacy = isset($_POST['privacy']) ? true : false;
    
    if (!$name || !$email || !$subject || !$message || !$privacy) {
        redirect('../index.php?page=contact&error=missing_fields');
    }
    
    $emailSubject = 'Formulaire de contact: ' . $subject;
    $emailBody = "
    <html>
    <head>
        <title>Nouveau message de contact</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            h2 { color: #0056b3; }
            .info { margin-bottom: 20px; }
            .label { font-weight: bold; }
            .message { background-color: #f9f9f9; padding: 15px; border-left: 4px solid #0056b3; }
        </style>
    </head>
    <body>
        <h2>Nouveau message depuis le formulaire de contact</h2>
        <div class='info'>
            <p><span class='label'>Nom:</span> $name</p>
            <p><span class='label'>Email:</span> $email</p>
            <p><span class='label'>Téléphone:</span> $phone</p>
            <p><span class='label'>Entreprise:</span> $company</p>
            <p><span class='label'>Sujet:</span> $subject</p>
        </div>
        <div class='message'>
            <p><span class='label'>Message:</span></p>
            <p>$message</p>
        </div>
        <p>Message envoyé le ".date('d/m/Y à H:i')."</p>
    </body>
    </html>
    ";
    
    $emailSent = sendContactEmail('businesscareams@gmail.com', $emailSubject, $emailBody, $email, $name);
    
    $savedToDb = false;
    if (isset($pdo) && $pdo) {
        $savedToDb = saveContactMessageToDatabase($name, $email, $phone, $company, $subject, $message);
    } else {
        error_log("Impossible de sauvegarder dans la base de données, connexion PDO non disponible");
    }
    
    if (!$emailSent) {
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=utf-8\r\n";
        $headers .= "From: Business Care <businesscareams@gmail.com>\r\n";
        $headers .= "Reply-To: $name <$email>\r\n";
        
        $emailSent = @mail('businesscareams@gmail.com', $emailSubject, $emailBody, $headers);
        
        if ($emailSent) {
            error_log("Email envoyé via fonction mail() native à businesscareams@gmail.com");
        } else {
            error_log("Échec de l'envoi via fonction mail() native");
        }
    }
    
    if ($emailSent || $savedToDb) {
        redirect('../index.php?page=contact&success=message_sent');
    } else {
        error_log("Échec complet du traitement du formulaire de contact de $email ($name)");
        redirect('../index.php?page=contact&error=mail_error');
    }
} else {
    redirect('../index.php?page=contact');
}
?>