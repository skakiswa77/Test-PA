<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Factures</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php


    require_once '../../config/database.php';


    $stmt = $pdo->query("SELECT i.*, c.name as company_name FROM invoices i
                     LEFT JOIN companies c ON i.company_id = c.id 
                     ORDER BY i.issue_date DESC");
    $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <?php
    require_once '../../composants/nav.php';
    ?>

    <h2>Gestion des Factures</h2>
    <a href="add.php">Ajouter une facture</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Entreprise</th>
            <th>Numéro</th>
            <th>Montant</th>
            <th>Date d'émission</th>
            <th>Date d'échéance</th>
            <th>Statut</th>
            <th>Mode de paiement</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($invoices as $invoice): ?>
            <tr>
                <td><?php echo $invoice['id']; ?></td>
                <td><?php echo htmlspecialchars($invoice['company_name']); ?></td>
                <td><?php echo htmlspecialchars($invoice['invoice_number']); ?></td>
                <td><?php echo $invoice['amount']; ?> €</td>
                <td><?php echo date('d/m/Y', strtotime($invoice['issue_date'])); ?></td>
                <td><?php echo date('d/m/Y', strtotime($invoice['due_date'])); ?></td>
                <td><?php echo htmlspecialchars($invoice['status']); ?></td>
                <td><?php echo htmlspecialchars($invoice['payment_method']); ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $invoice['id']; ?>">Modifier</a>
                    <a href="delete.php?id=<?php echo $invoice['id']; ?>"
                        onclick="return confirm('Voulez-vous vraiment supprimer cette facture?')">Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

</body>

</html>