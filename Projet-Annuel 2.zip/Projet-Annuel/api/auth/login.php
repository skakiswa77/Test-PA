<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
$database = new Database();
$db = $database->getConnection();

$data = json_decode(file_get_contents("php://input"));

if(!isset($data->email) || !isset($data->password)) {
    http_response_code(400);
    echo json_encode(array("message" => "Email et mot de passe requis."));
    exit();
}

$query = "SELECT id, email, password, first_name, last_name, role FROM users WHERE email = :email AND is_active = 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':email', $data->email);
$stmt->execute();

if($stmt->rowCount() > 0) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if(password_verify($data->password, $row['password'])) {
        $token = bin2hex(random_bytes(32));
        $userId = $row['id'];
        $expires = date('Y-m-d H:i:s', strtotime('+30 days'));
        
        $tokenQuery = "INSERT INTO remember_tokens (user_id, token, expires_at, created_at) VALUES (:user_id, :token, :expires_at, NOW())";
        $tokenStmt = $db->prepare($tokenQuery);
        $tokenStmt->bindParam(':user_id', $userId);
        $tokenStmt->bindParam(':token', $token);
        $tokenStmt->bindParam(':expires_at', $expires);
        $tokenStmt->execute();
        
        $logQuery = "INSERT INTO action_logs (user_id, action, description, ip_address, created_at) VALUES (:user_id, 'login', 'Connexion réussie', :ip, NOW())";
        $logStmt = $db->prepare($logQuery);
        $logStmt->bindParam(':user_id', $userId);
        $logStmt->bindParam(':ip', $_SERVER['REMOTE_ADDR']);
        $logStmt->execute();
        
        $updateQuery = "UPDATE users SET last_login = NOW() WHERE id = :id";
        $updateStmt = $db->prepare($updateQuery);
        $updateStmt->bindParam(':id', $userId);
        $updateStmt->execute();
        

        http_response_code(200);
        echo json_encode(array(
            "message" => "Connexion réussie.",
            "user" => array(
                "id" => $row['id'],
                "first_name" => $row['first_name'],
                "last_name" => $row['last_name'],
                "email" => $row['email'],
                "role" => $row['role']
            ),
            "token" => $token,
            "expires" => $expires
        ));
    } else {
        $logQuery = "INSERT INTO action_logs (user_id, action, description, ip_address, created_at) VALUES (NULL, 'login_failed', :description, :ip, NOW())";
        $logStmt = $db->prepare($logQuery);
        $description = "Tentative de connexion échouée pour: " . $data->email;
        $logStmt->bindParam(':description', $description);
        $logStmt->bindParam(':ip', $_SERVER['REMOTE_ADDR']);
        $logStmt->execute();
        
        http_response_code(401);
        echo json_encode(array("message" => "Email ou mot de passe incorrect."));
    }
} else {

    $logQuery = "INSERT INTO action_logs (user_id, action, description, ip_address, created_at) VALUES (NULL, 'login_failed', :description, :ip, NOW())";
    $logStmt = $db->prepare($logQuery);
    $description = "Tentative de connexion échouée pour: " . $data->email;
    $logStmt->bindParam(':description', $description);
    $logStmt->bindParam(':ip', $_SERVER['REMOTE_ADDR']);
    $logStmt->execute();
    
    http_response_code(401);
    echo json_encode(array("message" => "Email ou mot de passe incorrect."));
}
?>