document.addEventListener('DOMContentLoaded', function() {
    const chatbotToggle = document.getElementById('chatbot-toggle');
    const chatbotBox = document.getElementById('chatbot-box');
    const chatbotClose = document.getElementById('chatbot-close');
    const chatbotInput = document.getElementById('chatbot-input');
    const chatbotSend = document.getElementById('chatbot-send');
    const chatbotMessages = document.getElementById('chatbot-messages');

    chatbotToggle.addEventListener('click', function() {
        chatbotBox.classList.toggle('hidden');
    });

    chatbotClose.addEventListener('click', function() {
        chatbotBox.classList.add('hidden');
    });
    function appendMessage(sender, text) {
        const messageEl = document.createElement('div');
        messageEl.innerHTML = `<strong>${sender}:</strong> ${text}`;
        chatbotMessages.appendChild(messageEl);
        chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }
    function sendMessage() {
        const message = chatbotInput.value.trim();
        if (!message) return;

        appendMessage('Vous', message);

        fetch('/chatbot/chatbot.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => response.json())
        .then(data => {
            appendMessage('Bot', data.reply);
        })
        .catch(error => {
            console.error('Erreur:', error);
            appendMessage('Bot', 'Désolé, une erreur est survenue.');
        });

        chatbotInput.value = '';
    }
    chatbotSend.addEventListener('click', sendMessage);

    chatbotInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});


