<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$employee_id = $_SESSION['user_id'];
$db = Database::getInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_appointment'])) {
    $provider_id = $_POST['provider_id'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];
    $appointment_datetime = $appointment_date . ' ' . $appointment_time;
    $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
    $notes = $_POST['notes'];

    try {
        $db->execute(
            "INSERT INTO medical_appointments (user_id, provider_id, appointment_datetime, is_virtual, notes, status)
            VALUES (?, ?, ?, ?, ?, 'pending')",
            [
                $employee_id,
                $provider_id,
                $appointment_datetime,
                $is_virtual,
                $notes
            ]
        );

        $success_message = "Votre demande de rendez-vous a bien été enregistrée.";
    } catch (Exception $e) {
        $error_message = "Une erreur est survenue lors de la demande de rendez-vous: " . $e->getMessage();
    }
}

$appointments = $db->query(
    "SELECT ma.*, u.first_name, u.last_name, ps.name as specialization
    FROM medical_appointments ma
    JOIN provider_profiles pp ON ma.provider_id = pp.id
    JOIN users u ON pp.user_id = u.id
    JOIN provider_specializations ps ON pp.specialization_id = ps.id
    WHERE ma.user_id = ?
    ORDER BY ma.appointment_datetime DESC",
    [$employee_id]
);

$providers = $db->query(
    "SELECT pp.id, u.first_name, u.last_name, ps.name as specialization
    FROM provider_profiles pp
    JOIN users u ON pp.user_id = u.id
    JOIN provider_specializations ps ON pp.specialization_id = ps.id
    WHERE pp.is_verified = 1
    ORDER BY ps.name, u.last_name, u.first_name"
);


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Mes rendez-vous médicaux</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>

                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>

                    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#newAppointmentModal">
                        Demander un nouveau rendez-vous
                    </button>

                    <?php if (empty($appointments)): ?>
                        <div class="alert alert-info">Vous n'avez aucun rendez-vous médical pour le moment.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Prestataire</th>
                                        <th>Spécialité</th>
                                        <th>Date et heure</th>
                                        <th>Type</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($appointments as $appointment): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']); ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($appointment['specialization']); ?></td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($appointment['appointment_datetime'])); ?>
                                            </td>
                                            <td><?php echo $appointment['is_virtual'] ? 'Visioconférence' : 'Présentiel'; ?>
                                            </td>
                                            <td>
                                                <?php
                                                switch ($appointment['status']) {
                                                    case 'pending':
                                                        echo '<span class="badge badge-warning">En attente</span>';
                                                        break;
                                                    case 'confirmed':
                                                        echo '<span class="badge badge-success">Confirmé</span>';
                                                        break;
                                                    case 'cancelled':
                                                        echo '<span class="badge badge-danger">Annulé</span>';
                                                        break;
                                                    case 'completed':
                                                        echo '<span class="badge badge-info">Terminé</span>';
                                                        break;
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <a href="appointment_detail.php?id=<?php echo $appointment['id']; ?>"
                                                    class="btn btn-sm btn-info">Détails</a>

                                                <?php if ($appointment['status'] === 'pending' || $appointment['status'] === 'confirmed'): ?>
                                                    <a href="cancel_appointment.php?id=<?php echo $appointment['id']; ?>"
                                                        class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous?')">Annuler</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="newAppointmentModal" tabindex="-1" role="dialog" aria-labelledby="newAppointmentModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newAppointmentModalLabel">Demander un nouveau rendez-vous</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="provider_id">Prestataire</label>
                        <select name="provider_id" id="provider_id" class="form-control" required>
                            <option value="">Sélectionner un prestataire</option>
                            <?php foreach ($providers as $provider): ?>
                                <option value="<?php echo $provider['id']; ?>">
                                    <?php echo htmlspecialchars($provider['first_name'] . ' ' . $provider['last_name'] . ' (' . $provider['specialization'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="appointment_date">Date</label>
                        <input type="date" name="appointment_date" id="appointment_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="appointment_time">Heure</label>
                        <input type="time" name="appointment_time" id="appointment_time" class="form-control" required>
                    </div>
                    <div class="form-group form-check">
                        <input type="checkbox" name="is_virtual" id="is_virtual" class="form-check-input">
                        <label for="is_virtual" class="form-check-label">Rendez-vous en visioconférence</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" name="create_appointment" class="btn btn-primary">Demander le rendez-vous</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>