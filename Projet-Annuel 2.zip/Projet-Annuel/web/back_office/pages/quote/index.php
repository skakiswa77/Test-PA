<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Devis</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php

    require_once '../../config/database.php';

    $stmt = $pdo->query("SELECT q.*, c.name as company_name, u.first_name, u.last_name 
                    FROM quotes q
                    LEFT JOIN companies c ON q.company_id = c.id
                    LEFT JOIN users u ON q.user_id = u.id
                    WHERE q.archived = 0
                    ORDER BY q.created_at DESC");
    $quotes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    require_once '../../composants/nav.php';

    ?>

    <h2>Gestion des Devis</h2>
    <a href="add.php">Ajouter un devis</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Client</th>
            <th>Entreprise</th>
            <th>Montant</th>
            <th>Date d'émission</th>
            <th>Date d'expiration</th>
            <th>Statut</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($quotes as $quote): ?>
            <tr>
                <td><?php echo $quote['id']; ?></td>
                <td><?php
                $fullName = trim(($quote['first_name'] ?? '') . ' ' . ($quote['last_name'] ?? ''));
                echo htmlspecialchars($fullName ?: 'Client non défini');
                ?></td>
                <td><?php echo htmlspecialchars($quote['company_name'] ?? 'Aucune entreprise'); ?></td>
                <td><?php echo number_format(floatval($quote['amount'] ?? 0), 2, ',', ' '); ?> €</td>
                <td><?php echo date('d/m/Y', strtotime($quote['issue_date'] ?? 'now')); ?></td>
                <td><?php echo date('d/m/Y', strtotime($quote['expiration_date'] ?? 'now')); ?></td>
                <td><?php echo htmlspecialchars($quote['status'] ?? 'Statut non défini'); ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $quote['id']; ?>">Modifier</a>
                    <a href="archive.php?id=<?php echo $quote['id']; ?>"
                        onclick="return confirm('Voulez-vous vraiment archiver ce devis?')">Archiver</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>

</html>