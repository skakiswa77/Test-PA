<?php
session_start();
require_once '../../utils/database.php';

$predefinedQuestions = [
    "services" => "Nous proposons la gestion des clients, abonnements, plannings, prestataires et événements.",
    "planning" => "Les employés peuvent accéder à leur planning en étant connecté via leur tableau de bord.",
    "modifier mon mot de passe" => "Vous pouvez modifier votre mot de passe dans les paramètres de votre compte.",
    "contacter un prestataire" => "Oui, nos prestataires sont disponibles dans votre espace.",
    "abonnements" => "Vos abonnements sont visibles en vous connectant sur notre site.",
    "une activité" => "Les activités sont accessibles via votre tableau de bord.",
    "un événement" => "Bien sûr ! Contactez un administrateur ou utilisez le module d'événements.",
    "ajouter un client" => "Les admins peuvent ajouter un client depuis la section 'Gestion des clients'.",
    "évaluer un salarié" => "Les évaluations se font depuis la fiche de chaque employé.",
    "business care" => "Business Care simplifie la gestion RH, les plannings, les prestataires et le bien-être en entreprise."
];

function getChatbotResponse($message) {
    global $predefinedQuestions;
    
    $normalizedMessage = strtolower(trim($message));
   
    foreach ($predefinedQuestions as $key => $response) {
        if (strpos($normalizedMessage, strtolower($key)) !== false) {
            return $response;
        }
    }
    
    return "Je n'ai pas trouvé de réponse précise. Pourriez-vous reformuler votre question ?";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');

    $data = json_decode(file_get_contents('php://input'), true);
    $message = $data['message'] ?? '';

    $user_id = $_SESSION['user_id'] ?? null;

    $response = getChatbotResponse($message);
    
    if ($user_id) {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO chatbot_questions 
                (user_id, question, answer, is_anonymous) 
                VALUES 
                (:user_id, :question, :answer, :is_anonymous)
            ");
            $stmt->execute([
                ':user_id' => $user_id,
                ':question' => $message,
                ':answer' => $response,
                ':is_anonymous' => 0
            ]);
        } catch (PDOException $e) {
            error_log("Erreur d'enregistrement du chatbot : " . $e->getMessage());
        }
    }
  
    echo json_encode([
        'reply' => $response,
        'user_id' => $user_id
    ]);
    exit;
}
?>
