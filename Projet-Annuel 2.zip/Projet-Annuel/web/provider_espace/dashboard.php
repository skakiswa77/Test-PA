<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'provider') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que prestataire.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
try {
    $user = $db->query(
        "SELECT u.*, pp.bio, pp.hourly_rate, pp.is_verified, pp.rating, ps.name as specialization
         FROM users u
         LEFT JOIN provider_profiles pp ON u.id = pp.user_id
         LEFT JOIN provider_specializations ps ON pp.specialization_id = ps.id
         WHERE u.id = ? LIMIT 1",
        [$_SESSION['user_id']],
        true
    );

    if (!$user) {
        throw new Exception("Utilisateur non trouvé");
    }
} catch (Exception $e) {
    $user = [
        'id' => $_SESSION['user_id'],
        'first_name' => $_SESSION['user_name'] ?? 'Prestataire',
        'last_name' => '',
        'profile_picture' => '',
        'rating' => 0,
        'specialization' => 'Non définie',
        'hourly_rate' => 0,
        'is_verified' => 0
    ];
}

try {
    $upcomingAppointmentsCount = $db->query(
        "SELECT COUNT(*) as count FROM medical_appointments 
         WHERE provider_id = ? AND appointment_datetime > NOW() AND status != 'cancelled'",
        [$_SESSION['user_id']],
        true
    );
    $appointmentsCount = $upcomingAppointmentsCount['count'] ?? 0;

    $upcomingEventsCount = $db->query(
        "SELECT COUNT(*) as count FROM events 
         WHERE provider_id = ? AND start_datetime > NOW()",
        [$_SESSION['user_id']],
        true
    );
    $eventsCount = $upcomingEventsCount['count'] ?? 0;

    $currentMonthInvoicesCount = $db->query(
        "SELECT COUNT(*) as count FROM provider_invoices 
         WHERE provider_id = ? AND MONTH(issue_date) = MONTH(CURRENT_DATE()) 
         AND YEAR(issue_date) = YEAR(CURRENT_DATE())",
        [$_SESSION['user_id']],
        true
    );
    $invoicesCount = $currentMonthInvoicesCount['count'] ?? 0;

    $reviewsTotal = $reviewsCount['count'] ?? 0;
} catch (Exception $e) {
    $appointmentsCount = 0;
    $eventsCount = 0;
    $invoicesCount = 0;
}

$dashboardStats = [
    'stat1' => ['value' => $appointmentsCount, 'label' => 'Rendez-vous à venir', 'icon' => 'calendar-check'],
    'stat2' => ['value' => $eventsCount, 'label' => 'Événements à venir', 'icon' => 'users'],
    'stat3' => ['value' => $invoicesCount, 'label' => 'Factures du mois', 'icon' => 'file-invoice-dollar'],
];

try {
    $upcomingAppointments = $db->query(
        "SELECT a.*, u.first_name as client_first_name, u.last_name as client_last_name, c.name as company_name
         FROM medical_appointments a
         JOIN users u ON a.user_id = u.id
         JOIN companies c ON u.company_id = c.id
         WHERE a.provider_id = ? AND a.appointment_datetime > NOW() AND a.status != 'cancelled'
         ORDER BY a.appointment_datetime ASC
         LIMIT 5",
        [$_SESSION['user_id']]
    );
} catch (Exception $e) {
    $upcomingAppointments = [];
}

try {
    $upcomingEvents = $db->query(
        "SELECT e.*, et.name as event_type_name
         FROM events e
         LEFT JOIN event_types et ON e.event_type_id = et.id
         WHERE e.provider_id = ? AND e.start_datetime > NOW()
         ORDER BY e.start_datetime ASC
         LIMIT 3",
        [$_SESSION['user_id']]
    );
} catch (Exception $e) {
    $upcomingEvents = [];
}

try {
    $latestInvoices = $db->query(
        "SELECT pi.*, c.name as company_name
         FROM provider_invoices pi
         JOIN companies c ON pi.company_id = c.id
         WHERE pi.provider_id = ?
         ORDER BY pi.issue_date DESC
         LIMIT 3",
        [$_SESSION['user_id']]
    );
} catch (Exception $e) {
    $latestInvoices = [];
}

$monthlyEarnings = 0;
try {
    $earnings = $db->query(
        "SELECT SUM(amount) as total FROM provider_invoices 
         WHERE provider_id = ? AND MONTH(issue_date) = MONTH(CURRENT_DATE()) 
         AND YEAR(issue_date) = YEAR(CURRENT_DATE())",
        [$_SESSION['user_id']],
        true
    );
    $monthlyEarnings = $earnings['total'] ?? 0;
} catch (Exception $e) {
    $monthlyEarnings = 0;
}

$pageTitle = "Tableau de bord";
$spaceName = "Espace Prestataire";

?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> | Business Care</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="/web/assets/css/espace.css">
</head>

<body>

    <div class="nav" id="navbar">
        <div class="brand">
            <i class="fas fa-heartbeat"></i>
            <span>Business Care</span>
        </div>

            <a href="profile.php">
                <i class="fas fa-user"></i>
                <span>Profil</span>
            </a>

            <a href="../logout.php">
                <i class="fas fa-sign-out-alt"></i>
                <span>Déconnexion</span>
            </a>
        </div>
    </div>


    <div class="main-content" id="mainContent">

        <div class="card mb-4">
            <div class="card-body d-flex justify-content-between align-items-center py-3">
                <div>
                    <button class="btn btn-link text-primary p-0 me-2" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="h4 mb-0 d-inline-block"><?= $spaceName ?></span>
                </div>
                <div class="d-flex align-items-center">
                    <div class="me-3 text-end">
                        <div class="fw-bold"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>
                        </div>
                        <small class="text-muted">
                            <?= htmlspecialchars($user['specialization']) ?>
                            <?= $user['is_verified'] ? '<i class="fas fa-check-circle text-success"></i>' : '' ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>


        <div class="card mb-4">
            <div class="card-body">
                <h2 class="mb-0">Bienvenue, <?= htmlspecialchars($user['first_name']) ?> !</h2>
                <p class="text-muted mb-0">
                    <?= htmlspecialchars($user['specialization']) ?>
                    <?= $user['is_verified'] ? '<span class="text-success"><i class="fas fa-check-circle"></i> Vérifié</span>' : '<span class="text-warning"><i class="fas fa-exclamation-circle"></i> En attente de vérification</span>' ?>
                </p>
                <p>Gérez vos interventions, rendez-vous et factures depuis cet espace. Votre taux horaire actuel est de
                    <?= number_format($user['hourly_rate'], 2) ?> €/h.</p>
            </div>
        </div>


        <div class="row">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-primary-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat1']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat1']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat1']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-success-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat2']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat2']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat2']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-info-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat3']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat3']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat3']['label'] ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-8">

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Prochains rendez-vous</h5>
                        <a href="appointments.php" class="btn btn-sm btn-primary">Voir tout</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($upcomingAppointments)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-calendar-check fa-3x text-muted mb-3"></i>
                                <p>Vous n'avez aucun rendez-vous à venir pour le moment.</p>
                                <a href="availability.php" class="btn btn-sm btn-outline-primary">Définir mes
                                    disponibilités</a>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($upcomingAppointments as $appointment): ?>
                                    <div class="calendar-item">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <div class="calendar-date">
                                                    <?= date('d/m/Y H:i', strtotime($appointment['appointment_datetime'])) ?>
                                                </div>
                                                <div class="calendar-title">
                                                    <?= htmlspecialchars($appointment['client_first_name'] . ' ' . $appointment['client_last_name']) ?>
                                                </div>
                                                <small
                                                    class="text-muted"><?= htmlspecialchars($appointment['company_name']) ?></small>
                                            </div>
                                            <span
                                                class="badge bg-<?= $appointment['status'] === 'pending' ? 'warning' : ($appointment['status'] === 'confirmed' ? 'success' : 'primary') ?>">
                                                <?= $appointment['status'] === 'pending' ? 'En attente' : ($appointment['status'] === 'confirmed' ? 'Confirmé' : 'Planifié') ?>
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Événements à venir</h5>
                        <a href="events.php" class="btn btn-sm btn-primary">Voir tout</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($upcomingEvents)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-calendar-alt fa-3x text-muted mb-3"></i>
                                <p>Vous n'avez aucun événement à venir pour le moment.</p>
                                <a href="event_create.php" class="btn btn-sm btn-outline-primary">Créer un
                                    événement</a>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($upcomingEvents as $event): ?>
                                    <div class="calendar-item">
                                        <div class="calendar-date">
                                            <?= date('d/m/Y', strtotime($event['start_datetime'])) ?>
                                            <?= date('H:i', strtotime($event['start_datetime'])) ?> -
                                            <?= date('H:i', strtotime($event['end_datetime'])) ?>
                                        </div>
                                        <div class="calendar-title"><?= htmlspecialchars($event['title']) ?></div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small
                                                class="text-muted"><?= htmlspecialchars($event['event_type_name'] ?? 'Type non défini') ?></small>
                                            <small><?= htmlspecialchars($event['location']) ?></small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Revenus du mois</h5>
                    </div>
                    <div class="card-body">
                        <div class="text-center mb-4">
                            <h2 class="display-4 fw-bold"><?= number_format($monthlyEarnings, 2) ?> €</h2>
                            <p class="text-muted"><?= date('F Y') ?></p>
                        </div>
                        <div class="progress-wrapper">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span>Objectif mensuel</span>
                                <span><?= round(($monthlyEarnings / 2000) * 100) ?>%</span>
                            </div>
                            <div class="progress">
                                <div class="progress-bar bg-success" role="progressbar"
                                    style="width: <?= min(100, ($monthlyEarnings / 2000) * 100) ?>%"
                                    aria-valuenow="<?= min(100, ($monthlyEarnings / 2000) * 100) ?>" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                            <div class="text-end mt-1">
                                <small class="text-muted">2000 €</small>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer text-center">
                        <a href="invoices.php" class="text-decoration-none">Voir toutes les factures</a>
                    </div>
                </div>


                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Dernières factures</h5>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($latestInvoices)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-file-invoice-dollar fa-3x text-muted mb-3"></i>
                                <p>Aucune facture émise pour le moment.</p>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($latestInvoices as $invoice): ?>
                                    <a href="invoices.php?id=<?= $invoice['id'] ?>"
                                        class="list-group-item list-group-item-action">
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0 me-3">
                                                <div class="avatar bg-info-soft text-info rounded-circle p-2">
                                                    <i class="fas fa-file-invoice-dollar"></i>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">
                                                <p class="mb-1"><?= htmlspecialchars($invoice['invoice_number']) ?></p>
                                                <div class="d-flex justify-content-between">
                                                    <small
                                                        class="text-muted"><?= htmlspecialchars($invoice['company_name']) ?></small>
                                                    <span class="fw-bold"><?= number_format($invoice['amount'], 2) ?> €</span>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Actions rapides</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="availability.php" class="btn btn-primary">
                                <i class="fas fa-clock me-2"></i>Définir mes disponibilités
                            </a>
                            <a href="events.php?action=new" class="btn btn-outline-primary">
                                <i class="fas fa-calendar-plus me-2"></i>Créer un événement
                            </a>
                        </div>
                    </div>
                </div>

                <?php if ($user['is_verified'] != 1): ?>
                    <div class="card mb-4 border-warning">
                        <div class="card-header bg-warning-soft">
                            <h5 class="mb-0 text-warning"><i class="fas fa-exclamation-triangle me-2"></i>Vérification en
                                attente</h5>
                        </div>
                        <div class="card-body">
                            <p>Votre compte est en cours de vérification par l'équipe Business Care. Une fois vérifié, vous
                                pourrez recevoir plus de demandes de services.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const sidebarToggle = document.getElementById('sidebarToggle');

            function toggleSidebar() {
                sidebar.classList.toggle('expanded');
                mainContent.classList.toggle('contracted');
            }

            sidebarToggle.addEventListener('click', toggleSidebar);
            
            <?php if (isset($_SESSION['alert'])): ?>
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show';
                alertDiv.setAttribute('role', 'alert');
                alertalertDiv.innerHTML = `
                <?= $_SESSION['alert']['message'] ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            `;

                mainContent.insertBefore(alertDiv, mainContent.firstChild);

                setTimeout(function () {
                    const bsAlert = new bootstrap.Alert(alertDiv);
                    bsAlert.close();
                }, 5000);

                <?php unset($_SESSION['alert']); ?>
            <?php endif; ?>
        });
    </script>
</body>

</html>