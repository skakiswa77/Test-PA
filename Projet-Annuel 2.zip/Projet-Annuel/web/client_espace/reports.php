<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'company_admin') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que entreprise.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$admin_id = $_SESSION['user_id'];
$db = Database::getInstance();

$company_id = $db->query(
    "SELECT company_id FROM users WHERE id = ?",
    [$admin_id],
    true
)['company_id'];

if (!$company_id) {
    $error_message = "Erreur: Vous n'êtes pas associé à une entreprise.";
} else {
    
    $company = $db->query(
        "SELECT * FROM companies WHERE id = ?",
        [$company_id],
        true
    );
    
    $start_date = date('Y-m-01');
    $end_date = date('Y-m-t');

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_report'])) {
        $report_period = $_POST['report_period'];
        
        switch ($report_period) {
            case 'current_month':
                $start_date = date('Y-m-01');
                $end_date = date('Y-m-t');
                break;
            case 'last_month':
                $start_date = date('Y-m-01', strtotime('-1 month'));
                $end_date = date('Y-m-t', strtotime('-1 month'));
                break;
            case 'last_3_months':
                $start_date = date('Y-m-01', strtotime('-2 months'));
                $end_date = date('Y-m-t');
                break;
            case 'last_6_months':
                $start_date = date('Y-m-01', strtotime('-5 months'));
                $end_date = date('Y-m-t');
                break;
            case 'year_to_date':
                $start_date = date('Y-01-01');
                $end_date = date('Y-m-d');
                break;
            case 'custom':
                $start_date = $_POST['custom_start_date'];
                $end_date = $_POST['custom_end_date'];
                break;
        }
    }
    
    $db_start_date = date('Y-m-d', strtotime($start_date));
    $db_end_date = date('Y-m-d', strtotime($end_date));
    
    $event_stats = $db->query(
        "SELECT et.name as event_type, COUNT(e.id) as event_count
        FROM events e
        JOIN event_types et ON e.event_type_id = et.id
        JOIN event_registrations er ON e.id = er.event_id
        JOIN users u ON er.user_id = u.id
        WHERE u.company_id = ?
        AND e.start_datetime BETWEEN ? AND ?
        GROUP BY et.name
        ORDER BY event_count DESC",
        [
            $company_id,
            $db_start_date . ' 00:00:00',
            $db_end_date . ' 23:59:59'
        ]
    );
    
    $appointment_stats = $db->query(
        "SELECT 
            ps.name as specialization, 
            COUNT(ma.id) as appointment_count
        FROM medical_appointments ma
        JOIN users u ON ma.user_id = u.id
        JOIN provider_profiles pp ON ma.provider_id = pp.id
        JOIN provider_specializations ps ON pp.specialization_id = ps.id
        WHERE u.company_id = ?
        AND ma.appointment_datetime BETWEEN ? AND ?
        GROUP BY ps.name
        ORDER BY appointment_count DESC",
        [
            $company_id,
            $db_start_date . ' 00:00:00',
            $db_end_date . ' 23:59:59'
        ]
    );
    
    $participation_stats = $db->query(
        "SELECT
            COUNT(DISTINCT er.user_id) as unique_participants,
            (SELECT COUNT(*) FROM users WHERE company_id = ? AND role = 'employee') as total_employees
        FROM event_registrations er
        JOIN events e ON er.event_id = e.id
        JOIN users u ON er.user_id = u.id
        WHERE u.company_id = ?
        AND e.start_datetime BETWEEN ? AND ?",
        [
            $company_id,
            $company_id,
            $db_start_date . ' 00:00:00',
            $db_end_date . ' 23:59:59'
        ],
        true
    );
    
    $participation_rate = 0;
    if ($participation_stats['total_employees'] > 0) {
        $participation_rate = ($participation_stats['unique_participants'] / $participation_stats['total_employees']) * 100;
    }
    
    $top_employees = $db->query(
        "SELECT 
            u.id,
            u.first_name,
            u.last_name,
            COUNT(er.id) as participation_count
        FROM users u
        LEFT JOIN event_registrations er ON u.id = er.user_id
        LEFT JOIN events e ON er.event_id = e.id
        WHERE u.company_id = ?
        AND u.role = 'employee'
        AND (er.id IS NULL OR e.start_datetime BETWEEN ? AND ?)
        GROUP BY u.id
        ORDER BY participation_count DESC
        LIMIT 5",
        [
            $company_id,
            $db_start_date . ' 00:00:00',
            $db_end_date . ' 23:59:59'
        ]
    );
    
    $chatbot_stats = $db->query(
        "SELECT 
            COUNT(*) as total_questions,
            SUM(CASE WHEN is_anonymous = 1 THEN 1 ELSE 0 END) as anonymous_questions,
            SUM(CASE WHEN answer IS NOT NULL THEN 1 ELSE 0 END) as answered_questions
        FROM chatbot_questions cq
        JOIN users u ON cq.user_id = u.id
        WHERE u.company_id = ?
        AND cq.created_at BETWEEN ? AND ?",
        [
            $company_id,
            $db_start_date . ' 00:00:00',
            $db_end_date . ' 23:59:59'
        ],
        true
    );
    
    $month_names = [
        'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
        'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];
    
    $activity_data = [];
    
    if (strtotime($end_date) - strtotime($start_date) > 31 * 24 * 60 * 60) {
        $current_month = date('Y-m-01', strtotime($start_date));
        
        while (strtotime($current_month) <= strtotime($end_date)) {
            $month_start = $current_month;
            $month_end = date('Y-m-t', strtotime($current_month));
            
            $event_count = $db->query(
                "SELECT COUNT(*) as count
                FROM event_registrations er
                JOIN events e ON er.event_id = e.id
                JOIN users u ON er.user_id = u.id
                WHERE u.company_id = ?
                AND e.start_datetime BETWEEN ? AND ?",
                [
                    $company_id,
                    $month_start . ' 00:00:00',
                    $month_end . ' 23:59:59'
                ],
                true
            )['count'] ?? 0;
            
            $appointment_count = $db->query(
                "SELECT COUNT(*) as count
                FROM medical_appointments ma
                JOIN users u ON ma.user_id = u.id
                WHERE u.company_id = ?
                AND ma.appointment_datetime BETWEEN ? AND ?",
                [
                    $company_id,
                    $month_start . ' 00:00:00',
                    $month_end . ' 23:59:59'
                ],
                true
            )['count'] ?? 0;
            
            $chatbot_count = $db->query(
                "SELECT COUNT(*) as count
                FROM chatbot_questions cq
                JOIN users u ON cq.user_id = u.id
                WHERE u.company_id = ?
                AND cq.created_at BETWEEN ? AND ?",
                [
                    $company_id,
                    $month_start . ' 00:00:00',
                    $month_end . ' 23:59:59'
                ],
                true
            )['count'] ?? 0;
            
            $month_name = $month_names[date('n', strtotime($current_month)) - 1] . ' ' . date('Y', strtotime($current_month));
            
            $activity_data[] = [
                'month' => $month_name,
                'events' => $event_count,
                'appointments' => $appointment_count,
                'chatbot' => $chatbot_count
            ];
            
            $current_month = date('Y-m-01', strtotime($current_month . ' +1 month'));
        }
    } else {
        $current_day = $start_date;
        
        while (strtotime($current_day) <= strtotime($end_date)) {
            $event_count = $db->query(
                "SELECT COUNT(*) as count
                FROM event_registrations er
                JOIN events e ON er.event_id = e.id
                JOIN users u ON er.user_id = u.id
                WHERE u.company_id = ?
                AND DATE(e.start_datetime) = ?",
                [
                    $company_id,
                    $current_day
                ],
                true
            )['count'] ?? 0;
            
            $appointment_count = $db->query(
                "SELECT COUNT(*) as count
                FROM medical_appointments ma
                JOIN users u ON ma.user_id = u.id
                WHERE u.company_id = ?
                AND DATE(ma.appointment_datetime) = ?",
                [
                    $company_id,
                    $current_day
                ],
                true
            )['count'] ?? 0;
            
            $chatbot_count = $db->query(
                "SELECT COUNT(*) as count
                FROM chatbot_questions cq
                JOIN users u ON cq.user_id = u.id
                WHERE u.company_id = ?
                AND DATE(cq.created_at) = ?",
                [
                    $company_id,
                    $current_day
                ],
                true
            )['count'] ?? 0;
            
            $day_name = date('d/m', strtotime($current_day));
            
            $activity_data[] = [
                'month' => $day_name,
                'events' => $event_count,
                'appointments' => $appointment_count,
                'chatbot' => $chatbot_count
            ];
            
            $current_day = date('Y-m-d', strtotime($current_day . ' +1 day'));
        }
    }
    
    $activity_chart_data = json_encode($activity_data);
}

?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Rapports et statistiques</h4>
                    <button class="btn btn-outline-primary" id="print-report">
                        <i class="fas fa-print"></i> Imprimer le rapport
                    </button>
                </div>
                <div class="card-body">
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <form method="post" action="" class="mb-4">
                        <div class="row align-items-end">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="report_period">Période</label>
                                    <select name="report_period" id="report_period" class="form-control">
                                        <option value="current_month" <?php echo ($_SERVER['REQUEST_METHOD'] !== 'POST' || $_POST['report_period'] === 'current_month') ? 'selected' : ''; ?>>Mois en cours</option>
                                        <option value="last_month" <?php echo (isset($_POST['report_period']) && $_POST['report_period'] === 'last_month') ? 'selected' : ''; ?>>Mois précédent</option>
                                        <option value="last_3_months" <?php echo (isset($_POST['report_period']) && $_POST['report_period'] === 'last_3_months') ? 'selected' : ''; ?>>3 derniers mois</option>
                                        <option value="last_6_months" <?php echo (isset($_POST['report_period']) && $_POST['report_period'] === 'last_6_months') ? 'selected' : ''; ?>>6 derniers mois</option>
                                        <option value="year_to_date" <?php echo (isset($_POST['report_period']) && $_POST['report_period'] === 'year_to_date') ? 'selected' : ''; ?>>Depuis le début de l'année</option>
                                        <option value="custom" <?php echo (isset($_POST['report_period']) && $_POST['report_period'] === 'custom') ? 'selected' : ''; ?>>Personnalisée</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3 custom-dates <?php echo (isset($_POST['report_period']) && $_POST['report_period'] === 'custom') ? '' : 'd-none'; ?>">
                                <div class="form-group">
                                    <label for="custom_start_date">Date de début</label>
                                    <input type="date" name="custom_start_date" id="custom_start_date" class="form-control" value="<?php echo isset($_POST['custom_start_date']) ? $_POST['custom_start_date'] : date('Y-m-d', strtotime('-1 month')); ?>">
                                </div>
                            </div>
                            <div class="col-md-3 custom-dates <?php echo (isset($_POST['report_period']) && $_POST['report_period'] === 'custom') ? '' : 'd-none'; ?>">
                                <div class="form-group">
                                    <label for="custom_end_date">Date de fin</label>
                                    <input type="date" name="custom_end_date" id="custom_end_date" class="form-control" value="<?php echo isset($_POST['custom_end_date']) ? $_POST['custom_end_date'] : date('Y-m-d'); ?>">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" name="generate_report" class="btn btn-primary">Générer le rapport</button>
                            </div>
                        </div>
                    </form>
                    
                    <div id="report-content">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5>Rapport d'activité</h5>
                            <span class="badge badge-info">Période: <?php echo date('d/m/Y', strtotime($start_date)); ?> - <?php echo date('d/m/Y', strtotime($end_date)); ?></span>
                        </div>

                        <div class="row mb-4">
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Taux de participation</h5>
                                        <h2 class="display-4"><?php echo number_format($participation_rate, 1); ?>%</h2>
                                        <p class="mb-0"><?php echo $participation_stats['unique_participants']; ?> / <?php echo $participation_stats['total_employees']; ?> employés</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Événements</h5>
                                        <h2 class="display-4"><?php echo array_sum(array_column($event_stats, 'event_count')); ?></h2>
                                        <p class="mb-0">Participations totales</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Rendez-vous médicaux</h5>
                                        <h2 class="display-4"><?php echo array_sum(array_column($appointment_stats, 'appointment_count')); ?></h2>
                                        <p class="mb-0">Consultations totales</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Questions au chatbot</h5>
                                        <h2 class="display-4"><?php echo $chatbot_stats['total_questions']; ?></h2>
                                        <p class="mb-0"><?php echo $chatbot_stats['anonymous_questions']; ?> anonymes, <?php echo $chatbot_stats['answered_questions']; ?> répondues</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Évolution de l'activité</h5>
                            </div>
                            <div class="card-body">
                                <canvas id="activityChart" height="100"></canvas>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5 class="mb-0">Types d'événements</h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($event_stats)): ?>
                                            <div class="alert alert-info">Aucun événement sur la période sélectionnée.</div>
                                        <?php else: ?>
                                            <canvas id="eventTypeChart" height="200"></canvas>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <h5 class="mb-0">Types de rendez-vous médicaux</h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($appointment_stats)): ?>
                                            <div class="alert alert-info">Aucun rendez-vous médical sur la période sélectionnée.</div>
                                        <?php else: ?>
                                            <canvas id="appointmentTypeChart" height="200"></canvas>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        

                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Top 5 des employés les plus actifs</h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($top_employees) || max(array_column($top_employees, 'participation_count')) == 0): ?>
                                    <div class="alert alert-info">Aucune participation sur la période sélectionnée.</div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Employé</th>
                                                    <th>Participations</th>
                                                    <th>Progression</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $max_participations = max(array_column($top_employees, 'participation_count'));
                                                foreach ($top_employees as $employee): 
                                                    $percentage = 0;
                                                    if ($max_participations > 0) {
                                                        $percentage = ($employee['participation_count'] / $max_participations) * 100;
                                                    }
                                                ?>
                                                    <tr>
                                                        <td><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></td>
                                                        <td><?php echo $employee['participation_count']; ?></td>
                                                        <td>
                                                            <div class="progress">
                                                                <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $percentage; ?>%" aria-valuenow="<?php echo $percentage; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const reportPeriodSelect = document.getElementById('report_period');
        const customDatesFields = document.querySelectorAll('.custom-dates');
        
        reportPeriodSelect.addEventListener('change', function() {
            if (this.value === 'custom') {
                customDatesFields.forEach(field => field.classList.remove('d-none'));
            } else {
                customDatesFields.forEach(field => field.classList.add('d-none'));
            }
        });
        
        const activityData = <?php echo $activity_chart_data; ?>;
        
        if (activityData.length > 0) {
            const ctx = document.getElementById('activityChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: activityData.map(item => item.month),
                    datasets: [
                        {
                            label: 'Événements',
                            data: activityData.map(item => item.events),
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 2,
                            tension: 0.1
                        },
                        {
                            label: 'Rendez-vous médicaux',
                            data: activityData.map(item => item.appointments),
                            backgroundColor: 'rgba(255, 99, 132, 0.2)',
                            borderColor: 'rgba(255, 99, 132, 1)',
                            borderWidth: 2,
                            tension: 0.1
                        },
                        {
                            label: 'Questions chatbot',
                            data: activityData.map(item => item.chatbot),
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderColor: 'rgba(75, 192, 192, 1)',
                            borderWidth: 2,
                            tension: 0.1
                        }
                    ]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
        
        <?php if (!empty($event_stats)): ?>
        const eventTypeData = {
            labels: <?php echo json_encode(array_column($event_stats, 'event_type')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($event_stats, 'event_count')); ?>,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(255, 159, 64, 0.7)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        };
        
        const eventTypeCtx = document.getElementById('eventTypeChart').getContext('2d');
        new Chart(eventTypeCtx, {
            type: 'pie',
            data: eventTypeData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
        <?php endif; ?>
        
        <?php if (!empty($appointment_stats)): ?>
        const appointmentTypeData = {
            labels: <?php echo json_encode(array_column($appointment_stats, 'specialization')); ?>,
            datasets: [{
                data: <?php echo json_encode(array_column($appointment_stats, 'appointment_count')); ?>,
                backgroundColor: [
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(255, 159, 64, 0.7)',
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)'
                ],
                borderWidth: 1
            }]
        };
        
        const appointmentTypeCtx = document.getElementById('appointmentTypeChart').getContext('2d');
        new Chart(appointmentTypeCtx, {
            type: 'doughnut',
            data: appointmentTypeData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
        <?php endif; ?>
        
        document.getElementById('print-report').addEventListener('click', function() {
            window.print();
        });
    });
</script>
<style>
    @media print {
        body * {
            visibility: hidden;
        }
        #report-content, #report-content * {
            visibility: visible;
        }
        #report-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }
        .card {
            border: 1px solid #ddd !important;
            break-inside: avoid;
        }
        .card-header {
            background-color: #f8f9fa !important;
            border-bottom: 1px solid #ddd !important;
        }
    }
</style>

<?php include '../includes/footer.php'; ?>