<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'company_admin') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que entreprise.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();

try {
    $user = $db->query(
        "SELECT u.*, c.* 
         FROM users u
         JOIN companies c ON u.company_id = c.id
         WHERE u.id = ? LIMIT 1",
        [$_SESSION['user_id']],
        true
    );

    if (!$user) {
        throw new Exception("Utilisateur non trouvé");
    }


    $subscription = $db->query(
        "SELECT s.*, sp.name as plan_name, sp.description as plan_description, 
                sp.max_employees, sp.activities_per_month, sp.medical_appointments_per_month, 
                sp.chatbot_questions_limit
         FROM subscriptions s
         JOIN subscription_plans sp ON s.plan_id = sp.id
         WHERE s.company_id = ? AND s.is_active = 1
         ORDER BY s.end_date DESC
         LIMIT 1",
        [$user['company_id']],
        true
    );
} catch (Exception $e) {
    $user = [
        'id' => $_SESSION['user_id'],
        'first_name' => $_SESSION['user_name'] ?? 'Administrateur',
        'last_name' => '',
        'name' => 'Entreprise',
        'address' => '',
        'phone' => '',
        'email' => ''
    ];
    $subscription = null;
}


try {

    $employeesCount = $db->query(
        "SELECT COUNT(*) as count FROM users 
         WHERE company_id = ? AND role = 'employee' AND is_active = 1",
        [$user['company_id']],
        true
    );
    $totalEmployees = $employeesCount['count'] ?? 0;

    $activeEventsCount = $db->query(
        "SELECT COUNT(*) as count FROM events e
         JOIN event_registrations er ON e.id = er.event_id
         JOIN users u ON er.user_id = u.id
         WHERE u.company_id = ? AND e.start_datetime > NOW()
         GROUP BY u.company_id",
        [$user['company_id']],
        true
    );
    $activeEvents = $activeEventsCount['count'] ?? 0;

    $activeAppointmentsCount = $db->query(
        "SELECT COUNT(*) as count FROM medical_appointments a
         JOIN users u ON a.user_id = u.id
         WHERE u.company_id = ? AND a.appointment_datetime > NOW() AND a.status != 'cancelled'",
        [$user['company_id']],
        true
    );
    $activeAppointments = $activeAppointmentsCount['count'] ?? 0;

    $usageRate = 0;
    if ($subscription) {
        $totalAllowedAppointments = $subscription['medical_appointments_per_month'] * $totalEmployees;

        if ($totalAllowedAppointments > 0) {
            $usedAppointmentsCount = $db->query(
                "SELECT COUNT(*) as count FROM medical_appointments a
                 JOIN users u ON a.user_id = u.id
                 WHERE u.company_id = ? AND MONTH(a.appointment_datetime) = MONTH(CURRENT_DATE()) 
                 AND YEAR(a.appointment_datetime) = YEAR(CURRENT_DATE())",
                [$user['company_id']],
                true
            );
            $usedAppointments = $usedAppointmentsCount['count'] ?? 0;
            $usageRate = round(($usedAppointments / $totalAllowedAppointments) * 100);
        }
    }
} catch (Exception $e) {
    $totalEmployees = 0;
    $activeEvents = 0;
    $activeAppointments = 0;
    $usageRate = 0;
}

$dashboardStats = [
    'stat1' => ['value' => $totalEmployees, 'label' => 'Employés', 'icon' => 'users'],
    'stat2' => ['value' => $activeEvents, 'label' => 'Événements actifs', 'icon' => 'calendar-day'],
    'stat3' => ['value' => $activeAppointments, 'label' => 'Rendez-vous actifs', 'icon' => 'calendar-check'],
    'stat4' => ['value' => $usageRate, 'label' => 'Utilisation (%)', 'icon' => 'chart-line']
];

try {
    $recentEmployees = $db->query(
        "SELECT * FROM users
         WHERE company_id = ? AND role = 'employee'
         ORDER BY created_at DESC
         LIMIT 5",
        [$user['company_id']]
    );
} catch (Exception $e) {
    $recentEmployees = [];
}

try {
    $upcomingEvents = $db->query(
        "SELECT e.*, et.name as event_type_name, 
                COUNT(er.id) as current_participants,
                u.first_name as provider_first_name, u.last_name as provider_last_name
         FROM events e
         LEFT JOIN event_registrations er ON e.id = er.event_id
         LEFT JOIN event_types et ON e.event_type_id = et.id
         LEFT JOIN provider_profiles pp ON e.provider_id = pp.id
         LEFT JOIN users u ON pp.user_id = u.id
         JOIN users participant ON er.user_id = participant.id
         WHERE participant.company_id = ? AND e.start_datetime > NOW()
         GROUP BY e.id
         ORDER BY e.start_datetime ASC
         LIMIT 3",
        [$user['company_id']]
    );
} catch (Exception $e) {
    $upcomingEvents = [];
}

try {
    $recentInvoices = $db->query(
        "SELECT * FROM invoices
         WHERE company_id = ?
         ORDER BY issue_date DESC
         LIMIT 3",
        [$user['company_id']]
    );
} catch (Exception $e) {
    $recentInvoices = [];
}

$pageTitle = "Tableau de bord";
$spaceName = "Espace Entreprise";
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> | Business Care</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/espace.css">
</head>

<body>

    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-heartbeat"></i>
            <span>Business Care</span>
        </div>
        <div class="sidebar-menu">
            <a href="dashboards.php" class="active">
                <i class="fas fa-tachometer-alt"></i>
                <span>Tableau de bord</span>
            </a>
            <a href="profile.php">
                <i class="fas fa-user"></i>
                <span>Profil</span>
            </a>
            <a href="../logout.php">
                <i class="fas fa-sign-out-alt"></i>
                <span>Déconnexion</span>
            </a>
        </div>
    </div>


    <div class="main-content" id="mainContent">
        <div class="card mb-4">
            <div class="card-body d-flex justify-content-between align-items-center py-3">
                <div>
                    <button class="btn btn-link text-primary p-0 me-2" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <span class="h4 mb-0 d-inline-block"><?= $spaceName ?></span>
                </div>
                <div class="d-flex align-items-center">
                    <div class="me-3 text-end">
                        <div class="fw-bold"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?>
                        </div>
                        <small class="text-muted"><?= htmlspecialchars($user['name']) ?></small>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h2 class="mb-0">Bienvenue, <?= htmlspecialchars($user['first_name']) ?> !</h2>
                <p class="text-muted mb-0">
                    Gérez votre entreprise, vos employés et vos abonnements depuis cet espace.
                </p>
                <?php if ($subscription): ?>
                    <p>Abonnement actuel : <strong><?= htmlspecialchars($subscription['plan_name']) ?></strong>
                        <span class="text-muted">(expire le
                            <?= date('d/m/Y', strtotime($subscription['end_date'])) ?>)</span>
                    </p>
                <?php else: ?>
                    <p class="text-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Vous n'avez pas d'abonnement actif.
                        <a href="subscriptions.php" class="text-decoration-none">Choisir un abonnement</a>
                    </p>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-primary-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat1']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat1']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat1']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-success-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat2']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat2']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat2']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-info-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat3']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat3']['value'] ?></div>
                        <div class="text-muted"><?= $dashboardStats['stat3']['label'] ?></div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <div class="stat-icon bg-warning-soft mx-auto">
                            <i class="fas fa-<?= $dashboardStats['stat4']['icon'] ?>"></i>
                        </div>
                        <div class="h2 mt-2"><?= $dashboardStats['stat4']['value'] ?>%</div>
                        <div class="text-muted"><?= $dashboardStats['stat4']['label'] ?></div>
                        <?php if ($subscription): ?>
                            <div class="progress mt-2" style="height: 10px;">
                                <div class="progress-bar bg-<?= $usageRate < 70 ? 'success' : ($usageRate < 90 ? 'warning' : 'danger') ?>"
                                    role="progressbar" style="width: <?= min(100, $usageRate) ?>%;"
                                    aria-valuenow="<?= $usageRate ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">

            <div class="col-lg-8">

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Derniers employés</h5>
                        <a href="employees.php" class="btn btn-sm btn-primary">Voir tout</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($recentEmployees)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-users fa-3x text-muted mb-3"></i>
                                <p>Vous n'avez pas encore d'employés.</p>
                                <a href="employees.php?action=new" class="btn btn-sm btn-outline-primary">Ajouter un
                                    employé</a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Nom</th>
                                            <th>Email</th>
                                            <th>Date d'ajout</th>
                                            <th>Statut</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recentEmployees as $employee): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($employee['email']) ?></td>
                                                <td><?= date('d/m/Y', strtotime($employee['created_at'])) ?></td>
                                                <td>
                                                    <span class="badge bg-<?= $employee['is_active'] ? 'success' : 'danger' ?>">
                                                        <?= $employee['is_active'] ? 'Actif' : 'Inactif' ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Événements à venir</h5>
                        <a href="events.php" class="btn btn-sm btn-primary">Voir tout</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($upcomingEvents)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-calendar-alt fa-3x text-muted mb-3"></i>
                                <p>Aucun événement à venir pour votre entreprise.</p>
                                <a href="events.php?action=browse" class="btn btn-sm btn-outline-primary">Explorer les
                                    événements</a>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($upcomingEvents as $event): ?>
                                    <div class="calendar-item">
                                        <div class="calendar-date">
                                            <?= date('d/m/Y', strtotime($event['start_datetime'])) ?>
                                            <?= date('H:i', strtotime($event['start_datetime'])) ?> -
                                            <?= date('H:i', strtotime($event['end_datetime'])) ?>
                                        </div>
                                        <div class="calendar-title"><?= htmlspecialchars($event['title']) ?></div>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <small
                                                    class="text-muted"><?= htmlspecialchars($event['event_type_name'] ?? 'Type non défini') ?></small>
                                                <?php if (!empty($event['provider_first_name'])): ?>
                                                    <small class="ms-2">par
                                                        <?= htmlspecialchars($event['provider_first_name'] . ' ' . $event['provider_last_name']) ?></small>
                                                <?php endif; ?>
                                            </div>
                                            <small>
                                                <?= $event['current_participants'] ?> participant(s)
                                                <?php if (!empty($event['max_participants'])): ?>
                                                    / <?= $event['max_participants'] ?>
                                                <?php endif; ?>
                                            </small>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Détails de l'abonnement</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($subscription): ?>
                            <h5 class="card-title"><?= htmlspecialchars($subscription['plan_name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($subscription['plan_description']) ?></p>

                            <ul class="list-group list-group-flush">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Employés max.
                                    <span
                                        class="badge bg-primary rounded-pill"><?= $subscription['max_employees'] == 999999 ? 'Illimité' : $subscription['max_employees'] ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Activités / mois
                                    <span
                                        class="badge bg-primary rounded-pill"><?= $subscription['activities_per_month'] ?></span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    RDV médicaux / mois
                                    <span
                                        class="badge bg-primary rounded-pill"><?= $subscription['medical_appointments_per_month'] ?>
                                        par employé</span>
                                </li>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Questions chatbot
                                    <span
                                        class="badge bg-primary rounded-pill"><?= $subscription['chatbot_questions_limit'] == -1 ? 'Illimité' : $subscription['chatbot_questions_limit'] ?></span>
                                </li>
                            </ul>

                            <p class="card-text mt-3">
                                <small class="text-muted">
                                    Valide jusqu'au <?= date('d/m/Y', strtotime($subscription['end_date'])) ?>
                                </small>
                            </p>
                        <?php else: ?>
                            <div class="text-center py-3">
                                <i class="fas fa-exclamation-triangle fa-3x text-warning mb-3"></i>
                                <p>Vous n'avez pas d'abonnement actif.</p>
                                <a href="subscriptions.php" class="btn btn-primary mt-2">Voir les abonnements</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Dernières factures</h5>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($recentInvoices)): ?>
                            <div class="text-center py-3">
                                <i class="fas fa-file-invoice-dollar fa-3x text-muted mb-3"></i>
                                <p>Aucune facture pour le moment.</p>
                            </div>
                        <?php else: ?>
                            <div class="list-group list-group-flush">
                                <?php foreach ($recentInvoices as $invoice): ?>
                                    <a href="invoices.php?id=<?= $invoice['id'] ?>"
                                        class="list-group-item list-group-item-action">
                                        <div class="d-flex align-items-center">
                                            <div class="flex-shrink-0 me-3">
                                                <div class="avatar bg-info-soft text-info rounded-circle p-2">
                                                    <i class="fas fa-file-invoice-dollar"></i>
                                                </div>
                                            </div>
                                            <div class="flex-grow-1">
                                                <p class="mb-1"><?= htmlspecialchars($invoice['invoice_number']) ?></p>
                                                <div class="d-flex justify-content-between">
                                                    <small
                                                        class="text-muted"><?= date('d/m/Y', strtotime($invoice['issue_date'])) ?></small>
                                                    <span class="fw-bold"><?= number_format($invoice['amount'], 2) ?> €</span>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer text-center">
                        <a href="invoices.php" class="text-decoration-none">Voir toutes les factures</a>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Actions rapides</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="employees.php?action=new" class="btn btn-primary">
                                <i class="fas fa-user-plus me-2"></i>Ajouter un employé
                            </a>
                            <a href="reports.php?action=new" class="btn btn-outline-primary">
                                <i class="fas fa-chart-bar me-2"></i>Générer un rapport
                            </a>
                            <?php if ($subscription): ?>
                                <a href="events.php?action=request" class="btn btn-outline-primary">
                                    <i class="fas fa-calendar-plus me-2"></i>Demander un événement
                                </a>
                            <?php else: ?>
                                <a href="subscriptions.php" class="btn btn-outline-warning">
                                    <i class="fas fa-credit-card me-2"></i>Souscrire à un abonnement
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const sidebarToggle = document.getElementById('sidebarToggle');

            function toggleSidebar() {
                sidebar.classList.toggle('expanded');
                mainContent.classList.toggle('contracted');
            }

            sidebarToggle.addEventListener('click', toggleSidebar);

            <?php if (isset($_SESSION['alert'])): ?>
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show';
                alertDiv.setAttribute('role', 'alert');
                alertDiv.innerHTML = `
                    <?= $_SESSION['alert']['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                `;

                mainContent.insertBefore(alertDiv, mainContent.firstChild);

                setTimeout(function () {
                    const bsAlert = new bootstrap.Alert(alertDiv);
                    bsAlert.close();
                }, 5000);

                <?php unset($_SESSION['alert']); ?>
            <?php endif; ?>
        });
    </script>
</body>

</html>