<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$employee_id = $_SESSION['user_id'];
$db = Database::getInstance();
$pageTitle = "Compte Rendu et Suivi du Rendez-vous";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setAlert('ID de rendez-vous invalide.', 'danger');
    redirect('appointments.php');
    exit;
}

$appointmentId = (int)$_GET['id'];

try {
    $appointment = $db->query(
        "SELECT ma.*, u.first_name, u.last_name, ps.name as specialization
         FROM medical_appointments ma
         JOIN provider_profiles pp ON ma.provider_id = pp.id
         JOIN users u ON pp.user_id = u.id
         JOIN provider_specializations ps ON pp.specialization_id = ps.id
         WHERE ma.id = ? AND ma.user_id = ? AND ma.status = 'completed'
         LIMIT 1",
        [$appointmentId, $employee_id],
        true
    );

    if (!$appointment) {
        setAlert('Rendez-vous non trouvé, non terminé, ou vous n\'êtes pas autorisé à y accéder.', 'danger');
        redirect('appointments.php');
        exit;
    }

    $notes = $appointment['notes'] ?? '';
    $hasEmployeeReport = strpos($notes, '[COMMENTAIRE EMPLOYÉ]') !== false;

} catch (Exception $e) {
    setAlert('Erreur lors du chargement des données: ' . $e->getMessage(), 'danger');
    redirect('appointments.php');
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_notes = $_POST['employee_notes'] ?? '';
    $health_improvement = isset($_POST['health_improvement']) ? (int)$_POST['health_improvement'] : 0;
    $follow_up_needed = isset($_POST['follow_up_needed']) ? 'Oui' : 'Non';
    
    if (empty($employee_notes)) {
        $errors[] = 'Veuillez saisir vos remarques sur la consultation.';
    }
    
    if ($health_improvement < 1 || $health_improvement > 5) {
        $errors[] = 'Veuillez évaluer l\'amélioration de votre état entre 1 et 5.';
    }
    
    if (empty($errors)) {
        try {

            $currentNotes = $appointment['notes'] ?? '';
            
 
            if ($hasEmployeeReport) {
 
                $pattern = '/\[COMMENTAIRE EMPLOYÉ\].*?\[\/COMMENTAIRE EMPLOYÉ\]/s';
                $currentNotes = preg_replace($pattern, '', $currentNotes);
            }
            
            $employeeReport = "\n\n[COMMENTAIRE EMPLOYÉ]\n";
            $employeeReport .= "Date: " . date('d/m/Y H:i') . "\n";
            $employeeReport .= "Amélioration de l'état: $health_improvement/5\n";
            $employeeReport .= "Besoin d'un suivi supplémentaire: $follow_up_needed\n";
            $employeeReport .= "Commentaire: \n$employee_notes\n";
            $employeeReport .= "[/COMMENTAIRE EMPLOYÉ]";
            
            $updatedNotes = $currentNotes . $employeeReport;
            
            $db->update(
                'medical_appointments',
                ['notes' => $updatedNotes, 'updated_at' => date('Y-m-d H:i:s')],
                'id = ?',
                [$appointmentId]
            );

            $db->insert('action_logs', [
                'user_id' => $employee_id,
                'action' => 'add_appointment_feedback',
                'description' => "Ajout d'un commentaire par l'employé pour le rendez-vous #$appointmentId",
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $success = true;
            setAlert('Votre commentaire a été enregistré avec succès.', 'success');
            
            $appointment = $db->query(
                "SELECT ma.*, u.first_name, u.last_name, ps.name as specialization
                 FROM medical_appointments ma
                 JOIN provider_profiles pp ON ma.provider_id = pp.id
                 JOIN users u ON pp.user_id = u.id
                 JOIN provider_specializations ps ON pp.specialization_id = ps.id
                 WHERE ma.id = ? AND ma.user_id = ?
                 LIMIT 1",
                [$appointmentId, $employee_id],
                true
            );
            
            $notes = $appointment['notes'] ?? '';
            $hasEmployeeReport = strpos($notes, '[COMMENTAIRE EMPLOYÉ]') !== false;
            
        } catch (Exception $e) {
            $errors[] = 'Erreur lors de l\'enregistrement du commentaire: ' . $e->getMessage();
        }
    }
}

$employeeComment = '';
$employeeRating = '';
$employeeFollowUp = '';

if ($hasEmployeeReport) {
    preg_match('/\[COMMENTAIRE EMPLOYÉ\](.*?)\[\/COMMENTAIRE EMPLOYÉ\]/s', $notes, $matches);
    if (isset($matches[1])) {
        $reportContent = $matches[1];

        preg_match('/Amélioration de l\'état: (\d)\/5/', $reportContent, $ratingMatches);
        $employeeRating = isset($ratingMatches[1]) ? $ratingMatches[1] : '';
  
        preg_match('/Besoin d\'un suivi supplémentaire: (Oui|Non)/', $reportContent, $followUpMatches);
        $employeeFollowUp = isset($followUpMatches[1]) ? $followUpMatches[1] : '';
        
  
        preg_match('/Commentaire: \n(.*?)(\n\[\/COMMENTAIRE EMPLOYÉ\]|$)/s', $reportContent, $commentMatches);
        $employeeComment = isset($commentMatches[1]) ? $commentMatches[1] : '';
    }
}


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Suivi du Rendez-vous Médical</h2>
            <p class="text-muted">
                Prestataire: <?= htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']) ?> |
                Date: <?= date('d/m/Y', strtotime($appointment['appointment_datetime'])) ?>
            </p>
        </div>
        <div class="col-md-4 text-end">
            <a href="appointment_detail.php?id=<?= $appointmentId ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Retour aux détails
            </a>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            Votre commentaire a été enregistré avec succès.
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h4><?= $hasEmployeeReport ? 'Mettre à jour mon commentaire' : 'Ajouter mon commentaire' ?></h4>
        </div>
        <div class="card-body">
            <?php 

            $providerNotes = $notes;
            if ($hasEmployeeReport) {
                $providerNotes = preg_replace('/\[COMMENTAIRE EMPLOYÉ\].*?\[\/COMMENTAIRE EMPLOYÉ\]/s', '', $notes);
            }
            
            if (!empty(trim($providerNotes))):
            ?>
            <div class="mb-4">
                <h5>Compte rendu du prestataire</h5>
                <div class="p-3 bg-light rounded">
                    <?= nl2br(htmlspecialchars($providerNotes)) ?>
                </div>
            </div>
            <hr>
            <?php endif; ?>

            <form method="post" action="appointment_report.php?id=<?= $appointmentId ?>">
                <div class="mb-3">
                    <label for="employee_notes" class="form-label">Vos remarques sur la consultation</label>
                    <textarea class="form-control" id="employee_notes" name="employee_notes" rows="5" required><?= $employeeComment ?></textarea>
                    <div class="form-text">
                        Décrivez ici vos impressions sur la consultation, les recommandations qui vous ont été faites, 
                        et comment vous vous sentez après la consultation.
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Évaluation de l'amélioration de votre état</label>
                    <div class="d-flex">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="health_improvement" id="health_improvement_<?= $i ?>" 
                                value="<?= $i ?>" <?= ($employeeRating == $i) ? 'checked' : '' ?> required>
                            <label class="form-check-label" for="health_improvement_<?= $i ?>">
                                <?= $i ?> <?= $i == 1 ? '(Pas d\'amélioration)' : ($i == 5 ? '(Nette amélioration)' : '') ?>
                            </label>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="follow_up_needed" name="follow_up_needed" 
                           <?= ($employeeFollowUp == 'Oui') ? 'checked' : '' ?>>
                    <label class="form-check-label" for="follow_up_needed">
                        J'estime avoir besoin d'un suivi supplémentaire ou d'un nouveau rendez-vous
                    </label>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?= $hasEmployeeReport ? 'Mettre à jour' : 'Soumettre' ?> mon commentaire
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>form-control" id="employee_notes" name="employee_notes" rows="5" required><?= $employeeComment ?></textarea>
                    <div class="form-text">
                        Décrivez ici vos impressions sur la consultation, les recommandations qui vous ont été faites, 
                        et comment vous vous sentez après la consultation.
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Évaluation de l'amélioration de votre état</label>
                    <div class="d-flex">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="health_improvement" id="health_improvement_<?= $i ?>" 
                                value="<?= $i ?>" <?= ($employeeRating == $i) ? 'checked' : '' ?> required>
                            <label class="form-check-label" for="health_improvement_<?= $i ?>">
                                <?= $i ?> <?= $i == 1 ? '(Pas d\'amélioration)' : ($i == 5 ? '(Nette amélioration)' : '') ?>
                            </label>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="follow_up_needed" name="follow_up_needed" 
                           <?= ($employeeFollowUp == 'Oui') ? 'checked' : '' ?>>
                    <label class="form-check-label" for="follow_up_needed">
                        J'estime avoir besoin d'un suivi supplémentaire ou d'un nouveau rendez-vous
                    </label>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?= $hasEmployeeReport ? 'Mettre à jour' : 'Soumettre' ?> mon commentaire
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>form-control" id="employee_notes" name="employee_notes" rows="5" required><?= $existingReport ? htmlspecialchars($existingReport['employee_notes']) : '' ?></textarea>
                    <div class="form-text">
                        Décrivez ici vos impressions sur la consultation, les recommandations qui vous ont été faites, 
                        et comment vous vous sentez après la consultation.
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Évaluation de l'amélioration de votre état</label>
                    <div class="d-flex">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="health_improvement" id="health_improvement_<?= $i ?>" 
                                value="<?= $i ?>" <?= ($existingReport && $existingReport['health_improvement_rating'] == $i) ? 'checked' : '' ?> required>
                            <label class="form-check-label" for="health_improvement_<?= $i ?>">
                                <?= $i ?> <?= $i == 1 ? '(Pas d\'amélioration)' : ($i == 5 ? '(Nette amélioration)' : '') ?>
                            </label>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="follow_up_needed" name="follow_up_needed" 
                           <?= ($existingReport && $existingReport['follow_up_needed']) ? 'checked' : '' ?>>
                    <label class="form-check-label" for="follow_up_needed">
                        J'estime avoir besoin d'un suivi supplémentaire ou d'un nouveau rendez-vous
                    </label>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?= $existingReport ? 'Mettre à jour' : 'Soumettre' ?> le suivi
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>