<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Carte NFC</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $stmt = $pdo->prepare("INSERT INTO nfc_cards (user_id, card_uid, is_active, issued_date, created_at, updated_at)
                           VALUES (:user_id, :card_uid, :is_active, :issued_date, NOW(), NOW())");
        $stmt->execute([
            ':user_id' => $_POST['user_id'],
            ':card_uid' => $_POST['card_uid'],
            ':is_active' => isset($_POST['is_active']) ? 1 : 0,
            ':issued_date' => $_POST['issued_date']
        ]);

        header("Location: index.php");
        exit();
    }

    $stmt = $pdo->query("SELECT id, first_name, last_name FROM users ORDER BY last_name, first_name");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Ajouter une Carte NFC</h2>
    <form method="POST">
        <label for="user_id">Utilisateur</label>
        <select name="user_id" id="user_id" required>
            <option value="">Sélectionner un utilisateur</option>
            <?php foreach ($users as $user): ?>
                <option value="<?php echo $user['id']; ?>">
                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="card_uid">UID de la carte</label>
        <input type="text" name="card_uid" id="card_uid" placeholder="Identifiant unique de la carte" required><br>

        <label for="is_active">Carte active</label>
        <input type="checkbox" name="is_active" id="is_active" checked><br>

        <label for="issued_date">Date d'émission</label>
        <input type="date" name="issued_date" id="issued_date" value="<?php echo date('Y-m-d'); ?>" required><br>

        <button type="submit">Ajouter la Carte</button>
    </form>

</body>

</html>