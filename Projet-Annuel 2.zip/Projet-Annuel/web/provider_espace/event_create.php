<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'provider') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que prestataire.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Créer un Événement";

try {
    $eventTypes = $db->query("SELECT * FROM event_types ORDER BY name");
    
$companies = $db->query(
    "SELECT DISTINCT c.id, c.name 
     FROM companies c
     JOIN users u ON u.company_id = c.id
     WHERE EXISTS (
         SELECT 1 FROM provider_profiles pp
         WHERE pp.user_id = ?
     )",
    [$_SESSION['user_id']]
);

} catch (Exception $e) {
    $eventTypes = [];
    $companies = [];
    setAlert('Erreur lors du chargement des données: ' . $e->getMessage(), 'danger');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $event_type_id = $_POST['event_type_id'] ?? '';
    $location = $_POST['location'] ?? '';
    $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
    $company_id = $_POST['company_id'] ?? null;
    $max_participants = $_POST['max_participants'] ? intval($_POST['max_participants']) : null;
    $start_date = $_POST['start_date'] ?? '';
    $start_time = $_POST['start_time'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $end_time = $_POST['end_time'] ?? '';
    
    $errors = [];
    
    if (empty($title)) {
        $errors[] = "Le titre est requis";
    }
    
    if (empty($event_type_id)) {
        $errors[] = "Le type d'événement est requis";
    }
    
    if (empty($location) && $is_virtual == 0) {
        $errors[] = "Le lieu est requis pour un événement en présentiel";
    }
    
    if (empty($start_date) || empty($start_time)) {
        $errors[] = "La date et l'heure de début sont requises";
    }
    
    if (empty($end_date) || empty($end_time)) {
        $errors[] = "La date et l'heure de fin sont requises";
    }
    
    $start_datetime = strtotime("$start_date $start_time");
    $end_datetime = strtotime("$end_date $end_time");
    
    if ($end_datetime <= $start_datetime) {
        $errors[] = "La date et l'heure de fin doivent être postérieures à la date et l'heure de début";
    }
    
    if (empty($errors)) {
        try {
            $start_datetime_formatted = date('Y-m-d H:i:s', $start_datetime);
            $end_datetime_formatted = date('Y-m-d H:i:s', $end_datetime);
            
            $db->execute(
                "INSERT INTO events (title, description, event_type_id, location, is_virtual, 
                 max_participants, provider_id, company_id, start_datetime, end_datetime, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())",
                [
                    $title,
                    $description,
                    $event_type_id,
                    $location,
                    $is_virtual,
                    $max_participants,
                    $_SESSION['user_id'],
                    $company_id,
                    $start_datetime_formatted,
                    $end_datetime_formatted
                ]
            );
            
            $lastEvent = $db->query(
                "SELECT id FROM events 
                 WHERE provider_id = ? 
                 ORDER BY id DESC 
                 LIMIT 1",
                [$_SESSION['user_id']]
            );
            
            if (empty($lastEvent)) {
                throw new Exception("Erreur lors de la récupération de l'ID de l'événement");
            }
            
            $event_id = $lastEvent[0]['id'];
            
            setAlert('Événement créé avec succès', 'success');
            redirect(APP_URL . '/provider/event_details.php?id=' . $event_id);
            
        } catch (Exception $e) {
            setAlert('Erreur lors de la création de l\'événement: ' . $e->getMessage(), 'danger');
        }
    } else {
        setAlert(implode('<br>', $errors), 'danger');
    }
}

?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Créer un Nouvel Événement</h1>
        <a href="events.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Retour
        </a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form method="post" action="">
                <div class="row mb-3">
                    <div class="col-md-8">
                        <label for="title" class="form-label">Titre de l'événement *</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?= isset($_POST['title']) ? htmlspecialchars($_POST['title']) : '' ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label for="event_type_id" class="form-label">Type d'événement *</label>
                        <select class="form-select" id="event_type_id" name="event_type_id" required>
                            <option value="">Sélectionnez un type</option>
                            <?php foreach ($eventTypes as $type): ?>
                                <option value="<?= $type['id'] ?>" <?= isset($_POST['event_type_id']) && $_POST['event_type_id'] == $type['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($type['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="4"><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-8">
                        <label for="company_id" class="form-label">Entreprise associée</label>
                        <select class="form-select" id="company_id" name="company_id">
                            <option value="">Aucune (événement ouvert à tous)</option>
                            <?php foreach ($companies as $company): ?>
                                <option value="<?= $company['id'] ?>" <?= isset($_POST['company_id']) && $_POST['company_id'] == $company['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($company['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small class="form-text text-muted">Si l'événement est destiné à une entreprise spécifique</small>
                    </div>
                    <div class="col-md-4">
                        <label for="max_participants" class="form-label">Nombre maximum de participants</label>
                        <input type="number" class="form-control" id="max_participants" name="max_participants" min="1" value="<?= isset($_POST['max_participants']) ? htmlspecialchars($_POST['max_participants']) : '' ?>">
                        <small class="form-text text-muted">Laissez vide pour un nombre illimité</small>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_virtual" name="is_virtual" <?= isset($_POST['is_virtual']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_virtual">
                            Événement virtuel
                        </label>
                    </div>
                </div>
                
                <div class="mb-3" id="location_field">
                    <label for="location" class="form-label">Lieu *</label>
                    <input type="text" class="form-control" id="location" name="location" value="<?= isset($_POST['location']) ? htmlspecialchars($_POST['location']) : '' ?>">
                    <small class="form-text text-muted">Pour un événement virtuel, indiquez l'URL ou "Lien envoyé après inscription"</small>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="start_date" class="form-label">Date de début *</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" value="<?= isset($_POST['start_date']) ? htmlspecialchars($_POST['start_date']) : date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label for="start_time" class="form-label">Heure de début *</label>
                        <input type="time" class="form-control" id="start_time" name="start_time" value="<?= isset($_POST['start_time']) ? htmlspecialchars($_POST['start_time']) : date('H:i') ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label for="end_date" class="form-label">Date de fin *</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" value="<?= isset($_POST['end_date']) ? htmlspecialchars($_POST['end_date']) : date('Y-m-d') ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label for="end_time" class="form-label">Heure de fin *</label>
                        <input type="time" class="form-control" id="end_time" name="end_time" value="<?= isset($_POST['end_time']) ? htmlspecialchars($_POST['end_time']) : date('H:i', strtotime('+1 hour')) ?>" required>
                    </div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Créer l'événement
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const isVirtualCheckbox = document.getElementById('is_virtual');
    const locationField = document.getElementById('location_field');
    const locationInput = document.getElementById('location');
    
    isVirtualCheckbox.addEventListener('change', function() {
        if (this.checked) {
            locationInput.placeholder = "URL de l'événement ou 'Lien envoyé après inscription'";
        } else {
            locationInput.placeholder = "";
        }
    });
 
    isVirtualCheckbox.dispatchEvent(new Event('change'));
});
</script>

<?php
include_once __DIR__ . '/../includes/footer.php';
?>