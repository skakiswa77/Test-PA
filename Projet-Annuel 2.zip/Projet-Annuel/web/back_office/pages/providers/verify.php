<?php
require_once '../../config/database.php';

if (!isset($_GET['id']) || !isset($_GET['verify'])) {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];
$verify = $_GET['verify'] == '1' ? 1 : 0;

$stmt = $pdo->prepare("UPDATE provider_profiles SET is_verified = :verify, updated_at = NOW() WHERE id = :id");
$stmt->execute([
    ':verify' => $verify,
    ':id' => $id
]);

header("Location: index.php");
exit();
?>