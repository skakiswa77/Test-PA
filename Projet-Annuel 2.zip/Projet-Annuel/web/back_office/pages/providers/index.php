<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Prestataires</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php

    require_once '../../config/database.php';

    $stmt = $pdo->query("SELECT pp.*, u.first_name, u.last_name, u.email, u.phone, ps.name as specialization_name 
                     FROM provider_profiles pp
                     JOIN users u ON pp.user_id = u.id
                     JOIN provider_specializations ps ON pp.specialization_id = ps.id
                     WHERE pp.is_verified = 1 OR pp.is_verified = 0
                     ORDER BY pp.rating DESC, u.last_name, u.first_name");
    $providers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <?php
    require_once '../../composants/nav.php';
    ?>

    <h2>Gestion des Prestataires</h2>
    <a href="add.php">Ajouter un prestataire</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Spécialisation</th>
            <th>Taux horaire</th>
            <th>Vérifié</th>
            <th>Note</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($providers as $provider): ?>
            <tr>
                <td><?php echo $provider['id']; ?></td>
                <td><?php echo htmlspecialchars($provider['first_name'] . ' ' . $provider['last_name']); ?></td>
                <td><?php echo htmlspecialchars($provider['email']); ?></td>
                <td><?php echo htmlspecialchars($provider['phone']); ?></td>
                <td><?php echo htmlspecialchars($provider['specialization_name']); ?></td>
                <td><?php echo number_format($provider['hourly_rate'], 2, ',', ' '); ?> €</td>
                <td><?php echo $provider['is_verified'] ? 'Oui' : 'Non'; ?></td>
                <td><?php echo $provider['rating'] > 0 ? number_format($provider['rating'], 1, ',', ' ') . '/5' : 'N/A'; ?>
                </td>
                <td>
                    <a href="edit.php?id=<?php echo $provider['id']; ?>">Modifier</a>
                    <a href="verify.php?id=<?php echo $provider['id']; ?>&verify=<?php echo $provider['is_verified'] ? '0' : '1'; ?>"
                        onclick="return confirm('Voulez-vous vraiment <?php echo $provider['is_verified'] ? 'annuler la vérification' : 'vérifier'; ?> ce prestataire?')">
                        <?php echo $provider['is_verified'] ? 'Annuler vérification' : 'Vérifier'; ?>
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

</body>

</html>