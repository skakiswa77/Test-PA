<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Abonnement</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php

    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $stmt = $pdo->prepare("INSERT INTO subscriptions (company_id, plan_id, start_date, end_date, is_active, created_at, updated_at) 
                          VALUES (:company_id, :plan_id, :start_date, :end_date, :is_active, NOW(), NOW())");

        $stmt->execute([
            ':company_id' => $_POST['company_id'],
            ':plan_id' => $_POST['plan_id'],
            ':start_date' => $_POST['start_date'],
            ':end_date' => $_POST['end_date'],
            ':is_active' => isset($_POST['is_active']) ? 1 : 0
        ]);


        header("Location: index.php");
        exit();
    }

    $stmt = $pdo->query("SELECT id, name FROM companies ORDER BY name");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, name, description FROM subscription_plans ORDER BY id");
    $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Ajouter un Abonnement</h2>
    <form method="POST">
        <label for="company_id">Entreprise</label>
        <select name="company_id" id="company_id" required>
            <option value="">Sélectionner une entreprise</option>
            <?php foreach ($companies as $company): ?>
                <option value="<?php echo $company['id']; ?>">
                    <?php echo htmlspecialchars($company['name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="plan_id">Plan d'abonnement</label>
        <select name="plan_id" id="plan_id" required>
            <option value="">Sélectionner un plan</option>
            <?php foreach ($plans as $plan): ?>
                <option value="<?php echo $plan['id']; ?>">
                    <?php echo htmlspecialchars($plan['name'] . ' - ' . $plan['description']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="start_date">Date de début</label>
        <input type="date" name="start_date" id="start_date" required><br>

        <label for="end_date">Date de fin</label>
        <input type="date" name="end_date" id="end_date" required><br>

        <label for="is_active">Abonnement actif</label>
        <input type="checkbox" name="is_active" id="is_active" checked><br>

        <button type="submit">Ajouter l'abonnement</button>
    </form>

</body>

</html>