<?php
require_once '../../config/database.php';
require_once '../../composants/nav.php';

$stmt_providers = $pdo->query("
    SELECT pp.id, u.first_name, u.last_name
    FROM provider_profiles pp
    JOIN users u ON pp.user_id = u.id
    WHERE pp.is_verified = 1
");
$providers = $stmt_providers->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $provider_id = !empty($_POST['provider_id']) ? $_POST['provider_id'] : null;
        
        if ($provider_id !== null) {
            $provider_check = $pdo->prepare("
                SELECT id FROM provider_profiles 
                WHERE id = :provider_id AND is_verified = 1
            ");
            $provider_check->execute([':provider_id' => $provider_id]);
            
            if (!$provider_check->fetch()) {
                throw new Exception("Prestataire invalide ou non vérifié");
            }
        }

        $stmt = $pdo->prepare("
            INSERT INTO events (
                title, description, event_type_id, location, is_virtual, 
                max_participants, provider_id, start_datetime, end_datetime, 
                created_at, updated_at
            ) VALUES (
                :title, :description, :event_type_id, :location, :is_virtual, 
                :max_participants, :provider_id, :start_datetime, :end_datetime, 
                NOW(), NOW()
            )
        ");

        $result = $stmt->execute([
            ':title' => $_POST['title'],
            ':description' => $_POST['description'],
            ':event_type_id' => $_POST['event_type_id'],
            ':location' => $_POST['location'],
            ':is_virtual' => isset($_POST['is_virtual']) ? 1 : 0,
            ':max_participants' => $_POST['max_participants'],
            ':provider_id' => $provider_id,
            ':start_datetime' => $_POST['start_datetime'],
            ':end_datetime' => $_POST['end_datetime']
        ]);

        if ($result) {
            header("Location: index.php?success=1");
            exit();
        }
    } catch (PDOException $e) {
        error_log("Erreur d'insertion d'événement : " . $e->getMessage());
        $error = "Erreur lors de l'ajout de l'événement : " . $e->getMessage();
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un Événement</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>
<body>
    <?php if (isset($error)): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <h2>Ajouter un Événement</h2>

        <label for="title">Titre</label>
        <input type="text" id="title" name="title" required>

        <label for="description">Description</label>
        <textarea id="description" name="description"></textarea>

        <label for="event_type_id">Type d'événement</label>
        <select id="event_type_id" name="event_type_id" required>
            <option value="">Sélectionner un type</option>
            <option value="1">Atelier bien-être</option>
            <option value="2">Conférence</option>
            <option value="3">Activité sportive</option>
            <option value="4">Rendez-vous médical</option>
            <option value="5">Événement solidaire</option>
            <option value="6">Activité team building</option>
        </select>

        <label for="location">Lieu</label>
        <input type="text" id="location" name="location">

        <label>
            <input type="checkbox" name="is_virtual"> Événement virtuel
        </label>

        <label for="max_participants">Nombre max de participants</label>
        <input type="number" id="max_participants" name="max_participants">

        <label for="provider_id">Prestataire (optionnel)</label>
        <select id="provider_id" name="provider_id">
            <option value="">Aucun prestataire</option>
            <?php foreach ($providers as $provider): ?>
                <option value="<?php echo $provider['id']; ?>">
                    <?php echo htmlspecialchars($provider['first_name'] . ' ' . $provider['last_name']); ?> 
                    (ID: <?php echo $provider['id']; ?>)
                </option>
            <?php endforeach; ?>
        </select>

        <label for="start_datetime">Date et heure de début</label>
        <input type="datetime-local" id="start_datetime" name="start_datetime" required>

        <label for="end_datetime">Date et heure de fin</label>
        <input type="datetime-local" id="end_datetime" name="end_datetime" required>

        <button type="submit">Ajouter l'événement</button>
    </form>
</body>
</html>