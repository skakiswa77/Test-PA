<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'provider') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que prestataire.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Prévisualisation des Factures";

$firstDayOfMonth = date('Y-m-01');
$lastDayOfMonth = date('Y-m-t');

try {
    $providerInfo = $db->query(
        "SELECT pp.*, u.first_name, u.last_name, u.email, u.phone, ps.name as specialization
         FROM provider_profiles pp
         JOIN users u ON pp.user_id = u.id
         JOIN provider_specializations ps ON pp.specialization_id = ps.id
         WHERE pp.user_id = ?",
        [$_SESSION['user_id']]
    );
    
    if (empty($providerInfo)) {
        throw new Exception("Profil de prestataire non trouvé");
    }
    
    $providerInfo = $providerInfo[0];
    
    $services = $db->query(
        "SELECT ps.*, 
         COALESCE(e.title, CONCAT('RDV médical du ', DATE_FORMAT(ma.appointment_datetime, '%d/%m/%Y'))) as description,
         COALESCE(c1.name, c2.name) as company_name,
         COALESCE(c1.id, c2.id) as company_id
         FROM provider_services ps
         LEFT JOIN events e ON ps.event_id = e.id
         LEFT JOIN companies c1 ON e.company_id = c1.id
         LEFT JOIN medical_appointments ma ON ps.appointment_id = ma.id
         LEFT JOIN users u ON ma.user_id = u.id
         LEFT JOIN companies c2 ON u.company_id = c2.id
         WHERE ps.provider_id = ? 
         AND ps.provider_invoice_id IS NULL
         AND ps.service_date BETWEEN ? AND ?
         ORDER BY company_name, ps.service_date",
        [$_SESSION['user_id'], $firstDayOfMonth, $lastDayOfMonth]
    );
    
    $servicesByCompany = [];
    $totalsByCompany = [];
    
    foreach ($services as $service) {
        $companyId = $service['company_id'];
        
        if (!isset($servicesByCompany[$companyId])) {
            $servicesByCompany[$companyId] = [
                'company_name' => $service['company_name'],
                'services' => []
            ];
            $totalsByCompany[$companyId] = 0;
        }
        
        $servicesByCompany[$companyId]['services'][] = $service;
        $totalsByCompany[$companyId] += $service['total_amount'];
    }
    
} catch (Exception $e) {
    setAlert('Erreur: ' . $e->getMessage(), 'danger');
    redirect(APP_URL . '/provider/invoices.php');
}


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Prévisualisation de la Facturation</h1>
        <a href="invoices.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Retour
        </a>
    </div>
    
    <div class="alert alert-info">
        <i class="fas fa-info-circle me-2"></i>
        Cette page vous montre un aperçu des factures qui seront générées automatiquement à la fin du mois en cours (<?= date('F Y') ?>).
    </div>
    
    <?php if (empty($services)): ?>
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="text-center py-5">
                <i class="fas fa-file-invoice fa-4x mb-3 text-gray-300"></i>
                <h4 class="mb-3">Aucune prestation à facturer pour ce mois</h4>
                <p class="text-muted mb-0">Les prestations que vous réaliserez au cours de ce mois apparaîtront ici et seront automatiquement facturées en fin de mois.</p>
            </div>
        </div>
    </div>
    <?php else: ?>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Résumé des Factures à Générer</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Entreprise</th>
                            <th>Nombre de prestations</th>
                            <th>Montant total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($servicesByCompany as $companyId => $companyData): ?>
                        <tr>
                            <td><?= htmlspecialchars($companyData['company_name']) ?></td>
                            <td><?= count($companyData['services']) ?></td>
                            <td><?= number_format($totalsByCompany[$companyId], 2, ',', ' ') ?> €</td>
                            <td>
                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="collapse" data-bs-target="#details-<?= $companyId ?>">
                                    <i class="fas fa-eye me-1"></i> Détails
                                </button>
                            </td>
                        </tr>
                        <tr class="collapse" id="details-<?= $companyId ?>">
                            <td colspan="4" class="p-0">
                                <div class="p-3">
                                    <h6 class="font-weight-bold mb-3">Détail des prestations pour <?= htmlspecialchars($companyData['company_name']) ?></h6>
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Description</th>
                                                <th>Heures</th>
                                                <th>Taux horaire</th>
                                                <th>Montant</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($companyData['services'] as $service): ?>
                                            <tr>
                                                <td><?= date('d/m/Y', strtotime($service['service_date'])) ?></td>
                                                <td><?= htmlspecialchars($service['description']) ?></td>
                                                <td><?= $service['hours'] ?></td>
                                                <td><?= number_format($service['rate'], 2, ',', ' ') ?> €</td>
                                                <td><?= number_format($service['total_amount'], 2, ',', ' ') ?> €</td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th colspan="4" class="text-end">Total</th>
                                                <th><?= number_format($totalsByCompany[$companyId], 2, ',', ' ') ?> €</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>Total</th>
                            <th><?= array_sum(array_map(function($company) { return count($company['services']); }, $servicesByCompany)) ?></th>
                            <th><?= number_format(array_sum($totalsByCompany), 2, ',', ' ') ?> €</th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Actions</h6>
        </div>
        <div class="card-body">
            <p>Vous pouvez générer manuellement ces factures maintenant, ou attendre la facturation automatique en fin de mois.</p>
            <div class="d-flex gap-2">
                <a href="generate_monthly_invoices.php" class="btn btn-primary" onclick="return confirm('Êtes-vous sûr de vouloir générer toutes les factures maintenant ?');">
                    <i class="fas fa-file-invoice me-1"></i> Générer toutes les factures maintenant
                </a>
                <a href="invoices.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i> Retour
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
