<?php

require_once '../../config/database.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];
$stmt = $pdo->prepare("UPDATE users SET is_active = 0, updated_at = NOW() WHERE id = :id");
$stmt->execute([':id' => $id]);

header("Location: index.php");
exit();
?>