<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Prestataire</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $stmt = $pdo->prepare("SELECT id, role FROM users WHERE email = ?");
        $stmt->execute([$_POST['email']]);
        $existingUser = $stmt->fetch(PDO::FETCH_ASSOC);

        $userId = null;

        $pdo->beginTransaction();

        try {
            if (!$existingUser) {
                $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, email, phone, gender, 
                                  password, role, is_active, created_at, updated_at) 
                                  VALUES (:first_name, :last_name, :email, :phone, :gender, 
                                  :password, 'provider', 1, NOW(), NOW())");
                $stmt->execute([
                    ':first_name' => $_POST['first_name'],
                    ':last_name' => $_POST['last_name'],
                    ':email' => $_POST['email'],
                    ':phone' => $_POST['phone'],
                    ':gender' => $_POST['gender'],
                    ':password' => password_hash($_POST['password'], PASSWORD_DEFAULT)
                ]);

                $userId = $pdo->lastInsertId();
            } else {
                if ($existingUser['role'] != 'provider') {
                    $stmt = $pdo->prepare("UPDATE users SET role = 'provider', updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$existingUser['id']]);
                }

                $userId = $existingUser['id'];
            }

            $stmt = $pdo->prepare("INSERT INTO provider_profiles (user_id, specialization_id, bio, hourly_rate, 
                              is_verified, rating, created_at, updated_at) 
                              VALUES (:user_id, :specialization_id, :bio, :hourly_rate, 
                              :is_verified, 0.00, NOW(), NOW())");
            $stmt->execute([
                ':user_id' => $userId,
                ':specialization_id' => $_POST['specialization_id'],
                ':bio' => $_POST['bio'],
                ':hourly_rate' => $_POST['hourly_rate'],
                ':is_verified' => isset($_POST['is_verified']) ? 1 : 0
            ]);

            $pdo->commit();

            header("Location: index.php");
            exit();
        } catch (Exception $e) {

            $pdo->rollBack();
            $error = "Erreur lors de l'ajout du prestataire: " . $e->getMessage();
        }
    }

    $stmt = $pdo->query("SELECT id, name, description FROM provider_specializations ORDER BY name");
    $specializations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Ajouter un Prestataire</h2>

    <?php if (isset($error)): ?>
        <div style="color: red; margin-bottom: 15px;"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST">
        <h3>Informations personnelles</h3>

        <label for="first_name">Prénom</label>
        <input type="text" name="first_name" id="first_name" placeholder="Prénom" required><br>

        <label for="last_name">Nom</label>
        <input type="text" name="last_name" id="last_name" placeholder="Nom" required><br>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Email" required><br>

        <label for="phone">Téléphone</label>
        <input type="text" name="phone" id="phone" placeholder="Téléphone"><br>

        <label for="gender">Genre</label>
        <select name="gender" id="gender">
            <option value="M">Homme</option>
            <option value="F">Femme</option>
            <option value="">Non spécifié</option>
        </select><br>

        <label for="password">Mot de passe</label>
        <input type="password" name="password" id="password" placeholder="Mot de passe (minimum 8 caractères)"
            minlength="8" required><br>

        <h3>Informations professionnelles</h3>

        <label for="specialization_id">Spécialisation</label>
        <select name="specialization_id" id="specialization_id" required>
            <option value="">Sélectionner une spécialisation</option>
            <?php foreach ($specializations as $specialization): ?>
                <option value="<?php echo $specialization['id']; ?>">
                    <?php echo htmlspecialchars($specialization['name'] . ' - ' . $specialization['description']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="bio">Biographie</label>
        <textarea name="bio" id="bio" rows="4"
            placeholder="Courte description de l'expérience et des compétences du prestataire..."></textarea><br>

        <label for="hourly_rate">Taux horaire (€)</label>
        <input type="number" name="hourly_rate" id="hourly_rate" step="0.01" placeholder="0.00" required><br>

        <label for="is_verified">Prestataire vérifié</label>
        <input type="checkbox" name="is_verified" id="is_verified"><br>

        <button type="submit">Ajouter</button>
    </form>

</body>

</html>