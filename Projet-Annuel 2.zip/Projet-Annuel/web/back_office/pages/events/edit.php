<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Événements</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body></body>

</html>

<?php
require_once '../../composants/nav.php';
require_once '../../config/database.php';

$id = $_GET['id'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("UPDATE events SET title = :title, description = :description, 
                          event_type_id = :event_type_id, location = :location, is_virtual = :is_virtual,
                          max_participants = :max_participants, provider_id = :provider_id,
                          start_datetime = :start_datetime, end_datetime = :end_datetime,
                          updated_at = NOW() WHERE id = :id");
    $stmt->execute([
        ':title' => $_POST['title'],
        ':description' => $_POST['description'],
        ':event_type_id' => $_POST['event_type_id'],
        ':location' => $_POST['location'],
        ':is_virtual' => isset($_POST['is_virtual']) ? 1 : 0,
        ':max_participants' => $_POST['max_participants'],
        ':provider_id' => $_POST['provider_id'],
        ':start_datetime' => $_POST['start_datetime'],
        ':end_datetime' => $_POST['end_datetime'],
        ':id' => $id
    ]);
    header("Location: index.php");
    exit();
}
$stmt = $pdo->prepare("SELECT * FROM events WHERE id = ?");
$stmt->execute([$id]);
$event = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<h2>Modifier l'Événement</h2>
<form method="POST">
    <input type="text" name="title" value="<?php echo htmlspecialchars($event['title']); ?>" required><br>
    <textarea name="description"><?php echo htmlspecialchars($event['description']); ?></textarea><br>
    <select name="event_type_id" required>
        <option value="">Sélectionner un type</option>
        <option value="1" <?php echo $event['event_type_id'] == 1 ? 'selected' : ''; ?>>Atelier bien-être</option>
        <option value="2" <?php echo $event['event_type_id'] == 2 ? 'selected' : ''; ?>>Conférence</option>
        <option value="3" <?php echo $event['event_type_id'] == 3 ? 'selected' : ''; ?>>Activité sportive</option>
        <option value="4" <?php echo $event['event_type_id'] == 4 ? 'selected' : ''; ?>>Rendez-vous médical</option>
        <option value="5" <?php echo $event['event_type_id'] == 5 ? 'selected' : ''; ?>>Événement solidaire</option>
        <option value="6" <?php echo $event['event_type_id'] == 6 ? 'selected' : ''; ?>>Activité team building</option>
    </select><br>
    <input type="text" name="location" value="<?php echo htmlspecialchars($event['location']); ?>"><br>
    <label>
        <input type="checkbox" name="is_virtual" <?php echo $event['is_virtual'] ? 'checked' : ''; ?>> Événement virtuel
    </label><br>
    <input type="number" name="max_participants" value="<?php echo $event['max_participants']; ?>"><br>
    <input type="number" name="provider_id" value="<?php echo $event['provider_id']; ?>"><br>
    <input type="datetime-local" name="start_datetime" value="<?php echo date('Y-m-d\TH:i', strtotime($event['start_datetime'])); ?>" required><br>
    <input type="datetime-local" name="end_datetime" value="<?php echo date('Y-m-d\TH:i', strtotime($event['end_datetime'])); ?>" required><br>
    <button type="submit">Mettre à jour</button>
</form>