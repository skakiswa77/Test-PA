<?php
session_start();
require_once __DIR__ . '/../utils/database.php';

$db = Database::getInstance();

try {

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Méthode non autorisée.");
    }
    
    $role = isset($_POST['role']) ? trim($_POST['role']) : '';
    
    if (!in_array($role, ['company_admin', 'provider', 'admin'])) {
        throw new Exception("Rôle invalide.");
    }
    
    if (!isset($_POST['terms']) || $_POST['terms'] !== 'on') {
        throw new Exception("Vous devez accepter les conditions d'utilisation.");
    }
    
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $confirm_password = isset($_POST['confirm_password']) ? trim($_POST['confirm_password']) : '';
    
    if (empty($password)) {
        throw new Exception("Le mot de passe est obligatoire.");
    }
    
    if (strlen($password) < 8) {
        throw new Exception("Le mot de passe doit contenir au moins 8 caractères.");
    }
    
    if ($password !== $confirm_password) {
        throw new Exception("Les mots de passe ne correspondent pas.");
    }
    
    $db->beginTransaction();
 
    switch ($role) {
        case 'company_admin':
            registerCompany($db);
            break;
        case 'provider':
            registerProvider($db);
            break;
        case 'admin':
            registerAdmin($db);
            break;
    }
    $db->commit();
    
    header('Location: ../index.php?page=login&success=registration');
    exit;
    
} catch (Exception $e) {
    if ($db->getConnection()->inTransaction()) {
        $db->rollback();
    }
    $_SESSION['register_form_data'] = $_POST;
    
    header('Location: ../index.php?page=register&error=' . urlencode($e->getMessage()));
    exit;
}

function registerCompany($db) {

    $company_name = isset($_POST['company_name']) ? trim($_POST['company_name']) : '';
    $company_email = isset($_POST['company_email']) ? trim($_POST['company_email']) : '';
    $company_phone = isset($_POST['company_phone']) ? trim($_POST['company_phone']) : null;
    $company_address = isset($_POST['company_address']) ? trim($_POST['company_address']) : null;
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    if (empty($company_name) || empty($company_email)) {
        throw new Exception("Tous les champs obligatoires doivent être remplis.");
    }
    
    if (!filter_var($company_email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Adresse email invalide.");
    }

    $count = $db->query("SELECT COUNT(*) as count FROM users WHERE email = ?", [$company_email], true);
    if ($count['count'] > 0) {
        throw new Exception("Cet email est déjà utilisé.");
    }
 
    $company_id = $db->insert('companies', [
        'name' => $company_name,
        'email' => $company_email,
        'phone' => $company_phone,
        'address' => $company_address,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);
    
    if (!$company_id) {
        throw new Exception("Erreur lors de la création de l'entreprise.");
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $user_id = $db->insert('users', [
        'first_name' => $company_name, 
        'last_name' => '',
        'email' => $company_email,
        'password' => $hashed_password,
        'role' => 'company_admin',
        'company_id' => $company_id,
        'is_active' => 1,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);
    
    if (!$user_id) {
        throw new Exception("Erreur lors de la création de l'utilisateur.");
    }
    
    $db->insert('subscriptions', [
        'company_id' => $company_id,
        'plan_id' => 1,
        'start_date' => date('Y-m-d'),
        'end_date' => date('Y-m-d', strtotime('+1 month')),
        'is_active' => 1,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);
}

function registerProvider($db) {
    $first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
    $last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
    $admin_email = isset($_POST['admin_email']) ? trim($_POST['admin_email']) : '';
    $admin_phone = isset($_POST['admin_phone']) ? trim($_POST['admin_phone']) : '';
    $gender = isset($_POST['gender']) ? trim($_POST['gender']) : '';
    $birthdate = isset($_POST['birthdate']) ? trim($_POST['birthdate']) : '';
    $address = isset($_POST['address']) ? trim($_POST['address']) : '';
    $postal_code = isset($_POST['postal_code']) ? trim($_POST['postal_code']) : '';
    $city = isset($_POST['city']) ? trim($_POST['city']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    if (empty($first_name) || empty($last_name) || empty($admin_email) || empty($admin_phone) || 
        empty($gender) || empty($birthdate) || empty($address) || empty($postal_code) || 
        empty($city) || empty($password)) {
        throw new Exception("Tous les champs obligatoires doivent être remplis.");
    }
    
    if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Adresse email invalide.");
    }
    
    $count = $db->query("SELECT COUNT(*) as count FROM users WHERE email = ?", [$admin_email], true);
    if ($count['count'] > 0) {
        throw new Exception("Cet email est déjà utilisé.");
    }
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $user_id = $db->insert('users', [
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $admin_email,
        'phone' => $admin_phone,
        'gender' => $gender,
        'birthdate' => $birthdate,
        'address' => $address,
        'postal_code' => $postal_code,
        'city' => $city,
        'password' => $hashed_password,
        'role' => 'provider',
        'is_active' => 1,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);
    
    if (!$user_id) {
        throw new Exception("Erreur lors de la création de l'utilisateur.");
    }
    
    $db->insert('provider_profiles', [
        'user_id' => $user_id,
        'specialization_id' => 1,
        'hourly_rate' => 50.00,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);
}

function registerAdmin($db) {
    $first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : '';
    $last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : '';
    $admin_email = isset($_POST['admin_email']) ? trim($_POST['admin_email']) : '';
    $admin_phone = isset($_POST['admin_phone']) ? trim($_POST['admin_phone']) : '';
    $gender = isset($_POST['gender']) ? trim($_POST['gender']) : '';
    $birthdate = isset($_POST['birthdate']) ? trim($_POST['birthdate']) : '';
    $address = isset($_POST['address']) ? trim($_POST['address']) : '';
    $postal_code = isset($_POST['postal_code']) ? trim($_POST['postal_code']) : '';
    $city = isset($_POST['city']) ? trim($_POST['city']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    if (empty($first_name) || empty($last_name) || empty($admin_email) || empty($admin_phone) || 
        empty($gender) || empty($birthdate) || empty($address) || empty($postal_code) || 
        empty($city) || empty($password)) {
        throw new Exception("Tous les champs obligatoires doivent être remplis.");
    }
    
    if (!filter_var($admin_email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Adresse email invalide.");
    }
    
    $count = $db->query("SELECT COUNT(*) as count FROM users WHERE email = ?", [$admin_email], true);
    if ($count['count'] > 0) {
        throw new Exception("Cet email est déjà utilisé.");
    }
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $user_id = $db->insert('users', [
        'first_name' => $first_name,
        'last_name' => $last_name,
        'email' => $admin_email,
        'phone' => $admin_phone,
        'gender' => $gender,
        'birthdate' => $birthdate,
        'address' => $address,
        'postal_code' => $postal_code,
        'city' => $city,
        'password' => $hashed_password,
        'role' => 'admin',
        'is_active' => 0,
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);
    
    if (!$user_id) {
        throw new Exception("Erreur lors de la création de l'utilisateur.");
    }
    
    $db->insert('admin_requests', [
        'user_id' => $user_id,
        'request_reason' => 'Demande de compte administrateur',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s')
    ]);
}
?>