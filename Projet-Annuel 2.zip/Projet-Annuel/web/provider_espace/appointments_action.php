<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'provider') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que prestataire.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id']) || !isset($_GET['action'])) {
    setAlert('Paramètres invalides.', 'danger');
    redirect('appointments.php');
    exit;
}

$appointmentId = (int)$_GET['id'];
$action = $_GET['action'];

$validActions = ['confirm', 'cancel', 'complete'];
if (!in_array($action, $validActions)) {
    setAlert('Action non valide.', 'danger');
    redirect('appointments.php');
    exit;
}

$db = Database::getInstance();

try {
    $appointment = $db->query(
        "SELECT * FROM medical_appointments 
         WHERE id = ? AND provider_id = ?
         LIMIT 1",
        [$appointmentId, $_SESSION['user_id']],
        true
    );

    if (!$appointment) {
        setAlert('Rendez-vous non trouvé ou vous n\'êtes pas autorisé à le modifier.', 'danger');
        redirect('appointments.php');
        exit;
    }

    switch ($action) {
        case 'confirm':
            if ($appointment['status'] == 'pending') {
                $db->update(
                    'medical_appointments',
                    ['status' => 'confirmed', 'updated_at' => date('Y-m-d H:i:s')],
                    'id = ?',
                    [$appointmentId]
                );
                
                $db->insert('action_logs', [
                    'user_id' => $_SESSION['user_id'],
                    'action' => 'confirm_appointment',
                    'description' => "Confirmation du rendez-vous #$appointmentId",
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                setAlert('Le rendez-vous a été confirmé avec succès.', 'success');
            } else {
                setAlert('Ce rendez-vous ne peut pas être confirmé.', 'warning');
            }
            break;
            
        case 'cancel':
            if ($appointment['status'] != 'cancelled' && $appointment['status'] != 'completed') {
                $db->update(
                    'medical_appointments',
                    ['status' => 'cancelled', 'updated_at' => date('Y-m-d H:i:s')],
                    'id = ?',
                    [$appointmentId]
                );
                
                $db->insert('action_logs', [
                    'user_id' => $_SESSION['user_id'],
                    'action' => 'cancel_appointment',
                    'description' => "Annulation du rendez-vous #$appointmentId",
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                setAlert('Le rendez-vous a été annulé avec succès.', 'success');
            } else {
                setAlert('Ce rendez-vous ne peut pas être annulé.', 'warning');
            }
            break;
            
        case 'complete':
            if ($appointment['status'] == 'confirmed') {
                $db->update(
                    'medical_appointments',
                    ['status' => 'completed', 'updated_at' => date('Y-m-d H:i:s')],
                    'id = ?',
                    [$appointmentId]
                );
                
                $db->insert('action_logs', [
                    'user_id' => $_SESSION['user_id'],
                    'action' => 'complete_appointment',
                    'description' => "Rendez-vous #$appointmentId marqué comme terminé",
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                setAlert('Le rendez-vous a été marqué comme terminé.', 'success');
            } else {
                setAlert('Ce rendez-vous ne peut pas être marqué comme terminé.', 'warning');
            }
            break;
    }

    if (isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], 'appointment_details.php') !== false) {
        redirect("appointment_details.php?id=$appointmentId");
    } else {
        redirect('appointments.php');
    }

} catch (Exception $e) {
    setAlert('Erreur lors de la modification du rendez-vous: ' . $e->getMessage(), 'danger');
    redirect('appointments.php');
    exit;
}
?>