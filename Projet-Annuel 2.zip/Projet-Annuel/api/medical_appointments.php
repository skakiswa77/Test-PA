<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id']) ? $_GET['id'] : null;

switch($method) {
    case 'GET':
        if($id) {
            getAppointment($db, $id);
        } else {
            getAppointments($db);
        }
        break;
    case 'POST':
        createAppointment($db);
        break;
    case 'PUT':
        if($id) {
            updateAppointment($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID rendez-vous manquant."));
        }
        break;
    case 'DELETE':
        if($id) {
            deleteAppointment($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID rendez-vous manquant."));
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Méthode non autorisée."));
        break;
}

function getAppointments($db) {

    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $start = ($page - 1) * $limit;
    

    $where = "WHERE 1";
    $params = array();
    
    if(isset($_GET['user_id']) && !empty($_GET['user_id'])) {
        $where .= " AND ma.user_id = :user_id";
        $params[':user_id'] = $_GET['user_id'];
    }
    
    if(isset($_GET['provider_id']) && !empty($_GET['provider_id'])) {
        $where .= " AND ma.provider_id = :provider_id";
        $params[':provider_id'] = $_GET['provider_id'];
    }
    
    if(isset($_GET['status']) && !empty($_GET['status'])) {
        $where .= " AND ma.status = :status";
        $params[':status'] = $_GET['status'];
    }
    
    if(isset($_GET['is_virtual'])) {
        $where .= " AND ma.is_virtual = :is_virtual";
        $params[':is_virtual'] = $_GET['is_virtual'];
    }
    
    if(isset($_GET['date_from']) && !empty($_GET['date_from'])) {
        $where .= " AND DATE(ma.appointment_datetime) >= :date_from";
        $params[':date_from'] = $_GET['date_from'];
    }
    
    if(isset($_GET['date_to']) && !empty($_GET['date_to'])) {
        $where .= " AND DATE(ma.appointment_datetime) <= :date_to";
        $params[':date_to'] = $_GET['date_to'];
    }
    
    if(isset($_GET['future_only']) && $_GET['future_only'] == '1') {
        $where .= " AND ma.appointment_datetime > NOW()";
    }
    

    $query = "SELECT ma.*,
              pp.id as provider_profile_id, u_provider.first_name as provider_first_name, u_provider.last_name as provider_last_name,
              ps.name as specialization
              FROM medical_appointments ma 
              JOIN provider_profiles pp ON ma.provider_id = pp.id 
              JOIN users u_provider ON pp.user_id = u_provider.id 
              JOIN provider_specializations ps ON pp.specialization_id = ps.id 
              $where 
              ORDER BY ma.appointment_datetime 
              LIMIT :start, :limit";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':start', $start, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    
    foreach($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    

    $countQuery = "SELECT COUNT(*) as total 
                  FROM medical_appointments ma 
                  JOIN provider_profiles pp ON ma.provider_id = pp.id 
                  JOIN users u_provider ON pp.user_id = u_provider.id 
                  JOIN provider_specializations ps ON pp.specialization_id = ps.id 
                  $where";
    $countStmt = $db->prepare($countQuery);
    
    foreach($params as $key => $value) {
        $countStmt->bindValue($key, $value);
    }
    
    $countStmt->execute();
    $row = $countStmt->fetch(PDO::FETCH_ASSOC);
    $totalAppointments = $row['total'];
    

    if($stmt->rowCount() > 0) {
        $appointments_arr = array();
        $appointments_arr["appointments"] = array();
        $appointments_arr["pagination"] = array(
            "total" => $totalAppointments,
            "pages" => ceil($totalAppointments / $limit),
            "current_page" => (int)$page,
            "per_page" => (int)$limit
        );
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

            $appointment_item = array(
                "id" => $row['id'],
                "provider" => array(
                    "id" => $row['provider_profile_id'],
                    "name" => $row['provider_first_name'] . ' ' . $row['provider_last_name'],
                    "specialization" => $row['specialization']
                ),
                "appointment_datetime" => $row['appointment_datetime'],
                "is_virtual" => (bool)$row['is_virtual'],
                "status" => $row['status'],
                "created_at" => $row['created_at']
            );
            

            if(isset($_GET['user_id']) && $_GET['user_id'] == $row['user_id']) {
                $appointment_item["user_id"] = $row['user_id'];
                $appointment_item["notes"] = $row['notes'];
            }
            
            array_push($appointments_arr["appointments"], $appointment_item);
        }
        
        http_response_code(200);
        echo json_encode($appointments_arr);
    } else {
        http_response_code(200);
        echo json_encode(array("message" => "Aucun rendez-vous trouvé.", "appointments" => array()));
    }
}


function getAppointment($db, $id) {

    $user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;
    
    $query = "SELECT ma.*,
              pp.id as provider_profile_id, u_provider.id as provider_user_id, 
              u_provider.first_name as provider_first_name, u_provider.last_name as provider_last_name,
              ps.name as specialization,
              u_patient.first_name as patient_first_name, u_patient.last_name as patient_last_name
              FROM medical_appointments ma 
              JOIN provider_profiles pp ON ma.provider_id = pp.id 
              JOIN users u_provider ON pp.user_id = u_provider.id 
              JOIN users u_patient ON ma.user_id = u_patient.id 
              JOIN provider_specializations ps ON pp.specialization_id = ps.id 
              WHERE ma.id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $canAccessDetails = ($user_id && ($user_id == $row['user_id'] || $user_id == $row['provider_user_id']));
        
        $appointment = array(
            "id" => $row['id'],
            "provider" => array(
                "id" => $row['provider_profile_id'],
                "name" => $row['provider_first_name'] . ' ' . $row['provider_last_name'],
                "specialization" => $row['specialization']
            ),
            "appointment_datetime" => $row['appointment_datetime'],
            "is_virtual" => (bool)$row['is_virtual'],
            "status" => $row['status'],
            "created_at" => $row['created_at'],
            "updated_at" => $row['updated_at']
        );
        
        if($canAccessDetails) {
            $appointment["patient"] = array(
                "id" => $row['user_id'],
                "name" => $row['patient_first_name'] . ' ' . $row['patient_last_name']
            );
            $appointment["notes"] = $row['notes'];
        }
        
        http_response_code(200);
        echo json_encode($appointment);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Rendez-vous non trouvé."));
    }
}

function createAppointment($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if(
        !empty($data->user_id) && 
        !empty($data->provider_id) && 
        !empty($data->appointment_datetime)
    ) {
        $userQuery = "SELECT id FROM users WHERE id = :id";
        $userStmt = $db->prepare($userQuery);
        $userStmt->bindParam(':id', $data->user_id);
        $userStmt->execute();
        
        if($userStmt->rowCount() == 0) {
            http_response_code(404);
            echo json_encode(array("message" => "Utilisateur non trouvé."));
            return;
        }
        
        $providerQuery = "SELECT id FROM provider_profiles WHERE id = :id";
        $providerStmt = $db->prepare($providerQuery);
        $providerStmt->bindParam(':id', $data->provider_id);
        $providerStmt->execute();
        
        if($providerStmt->rowCount() == 0) {
            http_response_code(404);
            echo json_encode(array("message" => "Prestataire non trouvé."));
            return;
        }

        $appointmentDatetime = new DateTime($data->appointment_datetime);
        $dayOfWeek = $appointmentDatetime->format('N') % 7; 
        $appointmentTime = $appointmentDatetime->format('H:i:s');
        
        $availabilityQuery = "SELECT id FROM provider_availability 
                             WHERE provider_id = :provider_id 
                             AND day_of_week = :day_of_week 
                             AND start_time <= :appointment_time 
                             AND end_time > :appointment_time 
                             AND is_available = 1";
        $availabilityStmt = $db->prepare($availabilityQuery);
        $availabilityStmt->bindParam(':provider_id', $data->provider_id);
        $availabilityStmt->bindParam(':day_of_week', $dayOfWeek);
        $availabilityStmt->bindParam(':appointment_time', $appointmentTime);
        $availabilityStmt->execute();
        
        if($availabilityStmt->rowCount() == 0) {
            http_response_code(400);
            echo json_encode(array("message" => "Le prestataire n'est pas disponible à cette date et heure."));
            return;
        }
        
        $checkAppointmentQuery = "SELECT id FROM medical_appointments 
                                 WHERE provider_id = :provider_id 
                                 AND appointment_datetime = :appointment_datetime 
                                 AND status != 'cancelled'";
        $checkAppointmentStmt = $db->prepare($checkAppointmentQuery);
        $checkAppointmentStmt->bindParam(':provider_id', $data->provider_id);
        $checkAppointmentStmt->bindParam(':appointment_datetime', $data->appointment_datetime);
        $checkAppointmentStmt->execute();
        
        if($checkAppointmentStmt->rowCount() > 0) {
            http_response_code(400);
            echo json_encode(array("message" => "Le prestataire a déjà un rendez-vous à cette heure."));
            return;
        }
        
        $query = "INSERT INTO medical_appointments 
                 (user_id, provider_id, appointment_datetime, is_virtual, notes, status, created_at) 
                 VALUES 
                 (:user_id, :provider_id, :appointment_datetime, :is_virtual, :notes, :status, NOW())";
        
        $stmt = $db->prepare($query);
        
        $isVirtual = isset($data->is_virtual) ? $data->is_virtual : 0;
        $notes = isset($data->notes) ? htmlspecialchars(strip_tags($data->notes)) : null;
        $status = isset($data->status) ? $data->status : 'pending';
        
        $stmt->bindParam(':user_id', $data->user_id);
        $stmt->bindParam(':provider_id', $data->provider_id);
        $stmt->bindParam(':appointment_datetime', $data->appointment_datetime);
        $stmt->bindParam(':is_virtual', $isVirtual);
        $stmt->bindParam(':notes', $notes);
        $stmt->bindParam(':status', $status);
        
        if($stmt->execute()) {
            $appointment_id = $db->lastInsertId();
            
            http_response_code(201);
            echo json_encode(array(
                "message" => "Rendez-vous créé avec succès.",
                "id" => $appointment_id
            ));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Impossible de créer le rendez-vous."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Données incomplètes."));
    }
}

function updateAppointment($db, $id) {
    $data = json_decode(file_get_contents("php://input"));
    
    $checkQuery = "SELECT id, user_id, provider_id, appointment_datetime, status 
                  FROM medical_appointments 
                  WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $row = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        $now = new DateTime();
        $appointmentDatetime = new DateTime($row['appointment_datetime']);
        
        if($appointmentDatetime < $now && $row['status'] != 'cancelled') {
            http_response_code(400);
            echo json_encode(array("message" => "Impossible de modifier un rendez-vous passé."));
            return;
        }
        
        $fields = array();
        $params = array();
        

        if(isset($data->appointment_datetime) && $data->appointment_datetime != $row['appointment_datetime']) {
            $newAppointmentDatetime = new DateTime($data->appointment_datetime);
            $dayOfWeek = $newAppointmentDatetime->format('N') % 7; 
            $appointmentTime = $newAppointmentDatetime->format('H:i:s');
            
            $availabilityQuery = "SELECT id FROM provider_availability 
                                 WHERE provider_id = :provider_id 
                                 AND day_of_week = :day_of_week 
                                 AND start_time <= :appointment_time 
                                 AND end_time > :appointment_time 
                                 AND is_available = 1";
            $availabilityStmt = $db->prepare($availabilityQuery);
            $availabilityStmt->bindParam(':provider_id', $row['provider_id']);
            $availabilityStmt->bindParam(':day_of_week', $dayOfWeek);
            $availabilityStmt->bindParam(':appointment_time', $appointmentTime);
            $availabilityStmt->execute();
            
            if($availabilityStmt->rowCount() == 0) {
                http_response_code(400);
                echo json_encode(array("message" => "Le prestataire n'est pas disponible à cette nouvelle date et heure."));
                return;
            }
            
            $checkAppointmentQuery = "SELECT id FROM medical_appointments 
                                     WHERE provider_id = :provider_id 
                                     AND appointment_datetime = :appointment_datetime 
                                     AND id != :id 
                                     AND status != 'cancelled'";
            $checkAppointmentStmt = $db->prepare($checkAppointmentQuery);
            $checkAppointmentStmt->bindParam(':provider_id', $row['provider_id']);
            $checkAppointmentStmt->bindParam(':appointment_datetime', $data->appointment_datetime);
            $checkAppointmentStmt->bindParam(':id', $id);
            $checkAppointmentStmt->execute();
            
            if($checkAppointmentStmt->rowCount() > 0) {
                http_response_code(400);
                echo json_encode(array("message" => "Le prestataire a déjà un rendez-vous à cette heure."));
                return;
            }
            
            $fields[] = "appointment_datetime = :appointment_datetime";
            $params[':appointment_datetime'] = $data->appointment_datetime;
        }
        
        if(isset($data->is_virtual)) {
            $fields[] = "is_virtual = :is_virtual";
            $params[':is_virtual'] = $data->is_virtual ? 1 : 0;
        }
        
        if(isset($data->notes)) {
            $fields[] = "notes = :notes";
            $params[':notes'] = htmlspecialchars(strip_tags($data->notes));
        }
        
        if(isset($data->status)) {
            $fields[] = "status = :status";
            $params[':status'] = $data->status;
        }
        
        if(count($fields) > 0) {
            $query = "UPDATE medical_appointments SET " . implode(", ", $fields) . ", updated_at = NOW() WHERE id = :id";
            $params[':id'] = $id;
            
            $stmt = $db->prepare($query);
            
            foreach($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            if($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("message" => "Rendez-vous mis à jour avec succès."));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de mettre à jour le rendez-vous."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Aucune donnée fournie pour la mise à jour."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Rendez-vous non trouvé."));
    }
}

function deleteAppointment($db, $id) {
    $checkQuery = "SELECT id, appointment_datetime, status 
                  FROM medical_appointments 
                  WHERE id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();
    
    if($checkStmt->rowCount() > 0) {
        $row = $checkStmt->fetch(PDO::FETCH_ASSOC);
        
        $now = new DateTime();
        $appointmentDatetime = new DateTime($row['appointment_datetime']);
        
        if($appointmentDatetime < $now) {
            http_response_code(400);
            echo json_encode(array("message" => "Impossible d'annuler un rendez-vous passé."));
            return;
        }
        
        $query = "UPDATE medical_appointments SET status = 'cancelled', updated_at = NOW() WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("message" => "Rendez-vous annulé avec succès."));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Impossible d'annuler le rendez-vous."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Rendez-vous non trouvé."));
    }
}
?>