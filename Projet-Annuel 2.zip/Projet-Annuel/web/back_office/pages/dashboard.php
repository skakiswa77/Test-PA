<?php
session_start();

require_once __DIR__ . '/../config/database.php';

try {
    $stmt_events = $pdo->query("SELECT COUNT(*) as total FROM events WHERE start_datetime >= NOW()");
    $events_count = $stmt_events->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt_companies = $pdo->query("SELECT COUNT(*) as total FROM companies");
    $companies_count = $stmt_companies->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt_users = $pdo->query("SELECT COUNT(*) as total FROM users WHERE is_active = 1");
    $users_count = $stmt_users->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt_employees = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'employee' AND is_active = 1");
    $employees_count = $stmt_employees->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt_providers = $pdo->query("SELECT COUNT(*) as total FROM provider_profiles WHERE is_verified = 1");
    $providers_count = $stmt_providers->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt_subscriptions = $pdo->query("SELECT COUNT(*) as total FROM subscriptions WHERE is_active = 1");
    $subscriptions_count = $stmt_subscriptions->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt_invoices = $pdo->query("SELECT COUNT(*) as total FROM invoices WHERE status IN ('pending', 'overdue')");
    $invoices_count = $stmt_invoices->fetch(PDO::FETCH_ASSOC)['total'];

    $stmt_recent_events = $pdo->query("SELECT e.title, e.start_datetime, et.name as event_type 
                                      FROM events e 
                                      JOIN event_types et ON e.event_type_id = et.id 
                                      WHERE e.start_datetime >= NOW() 
                                      ORDER BY e.start_datetime ASC LIMIT 5");
    $recent_events = $stmt_recent_events->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
    exit;
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Back Office - Dashboard</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>
    <h1>Back Office - Gestion de Business Care</h1>
    <nav>
        <a href="dashboard.php">Menu</a> |
        <a href="events/index.php">Gestion des Événements</a> |
        <a href="companies/index.php">Gestion des Entreprises</a> |
        <a href="nfc-card/index.php">Gestion des Carte NFC</a> |
        <a href="providers/index.php">Gestion des Prestatairess</a> |
        <a href="users/index.php">Gestion des Utilisateurs</a> |
        <a href="subscriptions/index.php">Gestion des Abonnements</a> |
        <a href="invoices/index.php">Gestion des Factures</a> |
        <a href="quote/index.php">Gestion des Devis</a> |
        <a href="../../logout.php">Déconnexion
    </nav>
    <div>
        <h2>Bienvenue dans le Back Office</h2>
        <p>Utilisez le menu pour gérer les différentes sections.</p>
    </div>

    <main>

        <section class="dashboard-stats">
            <div class="stats-container">
                <div class="stat-card">
                    <h3>Événements à venir</h3>
                    <p><?php echo $events_count; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Entreprises</h3>
                    <p><?php echo $companies_count; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Utilisateurs</h3>
                    <p><?php echo $users_count; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Employés</h3>
                    <p><?php echo $employees_count; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Prestataires</h3>
                    <p><?php echo $providers_count; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Abonnements actifs</h3>
                    <p><?php echo $subscriptions_count; ?></p>
                </div>
                <div class="stat-card">
                    <h3>Factures en attente</h3>
                    <p><?php echo $invoices_count; ?></p>
                </div>
            </div>
        </section>


        <section class="recent-activities">
            <h2>Prochains Événements</h2>
            <?php if (empty($recent_events)): ?>
                <p>Aucun événement à venir à afficher.</p>
            <?php else: ?>
                <ul>
                    <?php foreach ($recent_events as $event): ?>
                        <li>
                            <strong><?php echo htmlspecialchars($event['title']); ?></strong>
                            (<?php echo htmlspecialchars($event['event_type']); ?>)
                            - <?php echo date('d/m/Y H:i', strtotime($event['start_datetime'])); ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </section>


        <section class="quick-actions">
            <h2>Actions Rapides</h2>
            <div class="actions-container">
                <a href="events/add.php" class="action-btn">Ajouter un Événement</a>
                <a href="companies/add.php" class="action-btn">Ajouter une Entreprise</a>
                <a href="users/add.php" class="action-btn">Ajouter un Utilisateur</a>
                <a href="providers/add.php" class="action-btn">Ajouter un Prestataire</a>
                <a href="subscriptions/add.php" class="action-btn">Ajouter un Abonnement</a>
                <a href="invoices/add.php" class="action-btn">Ajouter une Facture</a>
                <a href="nfc-card/add.php" class="action-btn">Ajouter une Carte NFC</a>
                <a href="quote/add.php" class="action-btn">Ajouter un Devis</a>
            </div>
        </section>
    </main>

    <script>
document.addEventListener('DOMContentLoaded', function() {
    document.body.addEventListener('click', function(event) {
        console.log('Élément cliqué:', event.target);
        
        console.log('Tagname:', event.target.tagName);
        console.log('Classes:', event.target.className);
        console.log('ID:', event.target.id);
        console.log('href:', event.target.href);

        let path = [];
        let current = event.target;
        while (current) {
            let selector = current.tagName.toLowerCase();
            if (current.id) selector += '#' + current.id;
            if (current.className) selector += '.' + current.className.replace(/\s+/g, '.');
            path.unshift(selector);
            current = current.parentElement;
        }
        console.log('Chemin de l\'élément:', path.join(' > '));
    });
});
</script>
</body>
</html>