<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant qu\'employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Proposer un Événement";

try {
    $eventTypes = $db->query("SELECT * FROM event_types ORDER BY name");
    
    $providers = $db->query(
        "SELECT pp.id, u.first_name, u.last_name, ps.name as specialization
         FROM provider_profiles pp
         JOIN users u ON pp.user_id = u.id
         JOIN provider_specializations ps ON pp.specialization_id = ps.id
         WHERE pp.is_verified = 1
         AND EXISTS (
            SELECT 1 FROM medical_appointments ma 
            JOIN users emp ON ma.user_id = emp.id
            WHERE ma.provider_id = pp.id 
            AND emp.company_id = (SELECT company_id FROM users WHERE id = ?)
         )
         ORDER BY ps.name, u.last_name, u.first_name",
        [$_SESSION['user_id']]
    );
    
    $company = $db->query(
        "SELECT c.* FROM companies c
         JOIN users u ON u.company_id = c.id
         WHERE u.id = ?
         LIMIT 1",
        [$_SESSION['user_id']],
        true
    );
    
} catch (Exception $e) {
    $eventTypes = [];
    $providers = [];
    $company = null;
    setAlert('Erreur lors du chargement des données: ' . $e->getMessage(), 'danger');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $event_type_id = $_POST['event_type_id'] ?? '';
    $provider_id = $_POST['provider_id'] ?? null;
    $location = $_POST['location'] ?? '';
    $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
    $max_participants = $_POST['max_participants'] ? intval($_POST['max_participants']) : null;
    $start_date = $_POST['start_date'] ?? '';
    $start_time = $_POST['start_time'] ?? '';
    $end_date = $_POST['end_date'] ?? '';
    $end_time = $_POST['end_time'] ?? '';
    
    $errors = [];
    
    if (empty($title)) {
        $errors[] = "Le titre est requis";
    }
    
    if (empty($event_type_id)) {
        $errors[] = "Le type d'événement est requis";
    }
    
    if (empty($location) && $is_virtual == 0) {
        $errors[] = "Le lieu est requis pour un événement en présentiel";
    }
    
    if (empty($start_date) || empty($start_time)) {
        $errors[] = "La date et l'heure de début sont requises";
    }
    
    if (empty($end_date) || empty($end_time)) {
        $errors[] = "La date et l'heure de fin sont requises";
    }
    
    $start_datetime = strtotime("$start_date $start_time");
    $end_datetime = strtotime("$end_date $end_time");
    
    if ($end_datetime <= $start_datetime) {
        $errors[] = "La date et l'heure de fin doivent être postérieures à la date et l'heure de début";
    }
    
    if (empty($errors)) {
        try {
            $start_datetime_formatted = date('Y-m-d H:i:s', $start_datetime);
            $end_datetime_formatted = date('Y-m-d H:i:s', $end_datetime);
            
            $db->execute(
                "INSERT INTO admin_requests (user_id, request_reason, status, created_at)
                 VALUES (?, ?, 'pending', NOW())",
                [
                    $_SESSION['user_id'],
                    "Demande de création d'événement: $title"
                ]
            );
            
            $request = $db->query(
                "SELECT id FROM admin_requests 
                 WHERE user_id = ? 
                 ORDER BY id DESC 
                 LIMIT 1",
                [$_SESSION['user_id']],
                true
            );
            
            if (!$request) {
                throw new Exception("Erreur lors de la création de la demande d'événement");
            }
            
            $eventDetails = [
                'title' => $title,
                'description' => $description,
                'event_type_id' => $event_type_id,
                'provider_id' => $provider_id,
                'location' => $location,
                'is_virtual' => $is_virtual,
                'max_participants' => $max_participants,
                'company_id' => $company['id'] ?? null,
                'start_datetime' => $start_datetime_formatted,
                'end_datetime' => $end_datetime_formatted
            ];
            
            $db->execute(
                "UPDATE admin_requests 
                 SET request_reason = ? 
                 WHERE id = ?",
                [
                    json_encode($eventDetails, JSON_UNESCAPED_UNICODE),
                    $request['id']
                ]
            );
            
            $db->execute(
                "INSERT INTO action_logs (user_id, action, description, created_at)
                 VALUES (?, 'event_suggested', ?, NOW())",
                [$_SESSION['user_id'], "Proposition d'événement: $title"]
            );
            
            setAlert('Votre proposition d\'événement a été soumise avec succès et est en attente d\'approbation', 'success');
            redirect(APP_URL . '/employee/events.php');
            
        } catch (Exception $e) {
            setAlert('Erreur lors de la proposition de l\'événement: ' . $e->getMessage(), 'danger');
        }
    } else {
        setAlert(implode('<br>', $errors), 'danger');
    }
}


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Proposer un Nouvel Événement</h1>
        <a href="events.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Retour à la liste
        </a>
    </div>

    <div class="alert alert-info mb-4">
        <i class="fas fa-info-circle me-2"></i>
        Votre proposition d'événement sera examinée par un administrateur avant d'être publiée. 
        Vous recevrez une notification lorsque votre proposition aura été traitée.
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Informations de l'événement</h6>
        </div>
        <div class="card-body">
            <form method="post" action="">
                <div class="row mb-3">
                    <div class="col-md-8">
                        <label for="title" class="form-label">Titre de l'événement *</label>
                        <input type="text" class="form-control" id="title" name="title" 
                               value="<?= isset($_POST['title']) ? htmlspecialchars($_POST['title']) : '' ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label for="event_type_id" class="form-label">Type d'événement *</label>
                        <select class="form-select" id="event_type_id" name="event_type_id" required>
                            <option value="">Sélectionnez un type</option>
                            <?php foreach ($eventTypes as $type): ?>
                                <option value="<?= $type['id'] ?>" <?= isset($_POST['event_type_id']) && $_POST['event_type_id'] == $type['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($type['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="4"><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
                    <div class="form-text">Décrivez l'événement, son objectif et ce que les participants peuvent en attendre.</div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-8">
                        <label for="provider_id" class="form-label">Prestataire suggéré</label>
                        <select class="form-select" id="provider_id" name="provider_id">
                            <option value="">Sélectionnez un prestataire (optionnel)</option>
                            <?php foreach ($providers as $provider): ?>
                                <option value="<?= $provider['id'] ?>" <?= isset($_POST['provider_id']) && $_POST['provider_id'] == $provider['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($provider['first_name'] . ' ' . $provider['last_name'] . ' (' . $provider['specialization'] . ')') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Suggérer un prestataire pour animer cet événement.</div>
                    </div>
                    <div class="col-md-4">
                        <label for="max_participants" class="form-label">Nombre maximum de participants</label>
                        <input type="number" class="form-control" id="max_participants" name="max_participants" min="1" 
                               value="<?= isset($_POST['max_participants']) ? htmlspecialchars($_POST['max_participants']) : '' ?>">
                        <div class="form-text">Laissez vide pour un nombre illimité</div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_virtual" name="is_virtual" 
                               <?= isset($_POST['is_virtual']) ? 'checked' : '' ?>>
                        <label class="form-check-label" for="is_virtual">
                            Événement virtuel
                        </label>
                    </div>
                </div>
                
                <div class="mb-3" id="location_field">
                    <label for="location" class="form-label">Lieu *</label>
                    <input type="text" class="form-control" id="location" name="location" 
                           value="<?= isset($_POST['location']) ? htmlspecialchars($_POST['location']) : '' ?>">
                    <div class="form-text">Pour un événement virtuel, indiquez l'URL ou "Lien envoyé après inscription"</div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-3">
                        <label for="start_date" class="form-label">Date de début *</label>
                        <input type="date" class="form-control" id="start_date" name="start_date" 
                               value="<?= isset($_POST['start_date']) ? htmlspecialchars($_POST['start_date']) : date('Y-m-d', strtotime('+1 week')) ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label for="start_time" class="form-label">Heure de début *</label>
                        <input type="time" class="form-control" id="start_time" name="start_time" 
                               value="<?= isset($_POST['start_time']) ? htmlspecialchars($_POST['start_time']) : '09:00' ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label for="end_date" class="form-label">Date de fin *</label>
                        <input type="date" class="form-control" id="end_date" name="end_date" 
                               value="<?= isset($_POST['end_date']) ? htmlspecialchars($_POST['end_date']) : date('Y-m-d', strtotime('+1 week')) ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label for="end_time" class="form-label">Heure de fin *</label>
                        <input type="time" class="form-control" id="end_time" name="end_time" 
                               value="<?= isset($_POST['end_time']) ? htmlspecialchars($_POST['end_time']) : '12:00' ?>" required>
                    </div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane me-1"></i> Soumettre la proposition
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const isVirtualCheckbox = document.getElementById('is_virtual');
    const locationField = document.getElementById('location_field');
    const locationInput = document.getElementById('location');
    
    isVirtualCheckbox.addEventListener('change', function() {
        if (this.checked) {
            locationInput.placeholder = "URL de l'événement ou 'Lien envoyé après inscription'";
        } else {
            locationInput.placeholder = "";
        }
    });
 
    isVirtualCheckbox.dispatchEvent(new Event('change'));
});
</script>

<?php
include_once __DIR__ . '/../includes/footer.php';
?>