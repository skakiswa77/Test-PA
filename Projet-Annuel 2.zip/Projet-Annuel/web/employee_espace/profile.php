<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant qu\'employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Mon Profil";


try {
    $user = $db->query(
        "SELECT u.*, c.name as company_name 
         FROM users u
         LEFT JOIN companies c ON u.company_id = c.id
         WHERE u.id = ? LIMIT 1",
        [$_SESSION['user_id']],
        true
    );
} catch (Exception $e) {
    $user = [
        'id' => $_SESSION['user_id'],
        'first_name' => $_SESSION['user_name'] ?? 'Employé',
        'last_name' => '',
        'email' => '',
    ];
    setAlert('Erreur lors du chargement du profil: ' . $e->getMessage(), 'danger');
}


try {
    $notification_prefs = $db->query(
        "SELECT * FROM notification_preferences WHERE user_id = ? LIMIT 1",
        [$_SESSION['user_id']],
        true
    );
    
    if (!$notification_prefs) {
        $notification_prefs = [
            'email_events' => 1,
            'email_appointments' => 1,
            'email_community' => 1,
            'email_marketing' => 0,
            'push_events' => 1,
            'push_appointments' => 1,
            'push_community' => 1,
            'push_marketing' => 0
        ];
    }
} catch (Exception $e) {
    $notification_prefs = [];
    setAlert('Erreur lors du chargement des préférences de notification: ' . $e->getMessage(), 'warning');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $firstName = trim($_POST['first_name'] ?? '');
    $lastName = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $postalCode = trim($_POST['postal_code'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $gender = $_POST['gender'] ?? null;
    $birthdate = $_POST['birthdate'] ?? null;

    $errors = [];


    if (empty($firstName)) {
        $errors[] = 'Le prénom est requis.';
    }

    if (empty($lastName)) {
        $errors[] = 'Le nom est requis.';
    }

    if (empty($email)) {
        $errors[] = 'L\'email est requis.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'L\'email est invalide.';
    }

    if (empty($errors)) {
        try {
            $db->beginTransaction();


            $db->update(
                'users',
                [
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'email' => $email,
                    'phone' => $phone,
                    'address' => $address,
                    'postal_code' => $postalCode,
                    'city' => $city,
                    'gender' => $gender,
                    'birthdate' => $birthdate,
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'id = ?',
                [$_SESSION['user_id']]
            );

            $db->commit();


            $_SESSION['user_name'] = $firstName . ' ' . $lastName;

            setAlert('Votre profil a été mis à jour avec succès.', 'success');
            redirect('profile.php');
            exit;

        } catch (Exception $e) {
            try {
                $db->rollBack();
            } catch (Exception $rollbackEx) {
                error_log('Erreur de rollback: ' . $rollbackEx->getMessage());
            }
            setAlert('Erreur lors de la mise à jour du profil: ' . $e->getMessage(), 'danger');
        }
    } else {

        setAlert(implode('<br>', $errors), 'danger');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_notifications'])) {
    $email_events = isset($_POST['email_events']) ? 1 : 0;
    $email_appointments = isset($_POST['email_appointments']) ? 1 : 0;
    $email_community = isset($_POST['email_community']) ? 1 : 0;
    $email_marketing = isset($_POST['email_marketing']) ? 1 : 0;
    $push_events = isset($_POST['push_events']) ? 1 : 0;
    $push_appointments = isset($_POST['push_appointments']) ? 1 : 0;
    $push_community = isset($_POST['push_community']) ? 1 : 0;
    $push_marketing = isset($_POST['push_marketing']) ? 1 : 0;
    
    try {
        $existingPrefs = $db->query(
            "SELECT id FROM notification_preferences WHERE user_id = ? LIMIT 1",
            [$_SESSION['user_id']],
            true
        );
        
        if ($existingPrefs) {
            $db->update(
                'notification_preferences',
                [
                    'email_events' => $email_events,
                    'email_appointments' => $email_appointments,
                    'email_community' => $email_community,
                    'email_marketing' => $email_marketing,
                    'push_events' => $push_events,
                    'push_appointments' => $push_appointments,
                    'push_community' => $push_community,
                    'push_marketing' => $push_marketing,
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'user_id = ?',
                [$_SESSION['user_id']]
            );
        } else {
            $db->insert('notification_preferences', [
                'user_id' => $_SESSION['user_id'],
                'email_events' => $email_events,
                'email_appointments' => $email_appointments,
                'email_community' => $email_community,
                'email_marketing' => $email_marketing,
                'push_events' => $push_events,
                'push_appointments' => $push_appointments,
                'push_community' => $push_community,
                'push_marketing' => $push_marketing,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        }
        
        $notification_prefs = [
            'email_events' => $email_events,
            'email_appointments' => $email_appointments,
            'email_community' => $email_community,
            'email_marketing' => $email_marketing,
            'push_events' => $push_events,
            'push_appointments' => $push_appointments,
            'push_community' => $push_community,
            'push_marketing' => $push_marketing
        ];
        
        setAlert('Vos préférences de notification ont été mises à jour avec succès.', 'success');
        redirect('profile.php');
        exit;
        
    } catch (Exception $e) {
        setAlert('Erreur lors de la mise à jour des préférences de notification: ' . $e->getMessage(), 'danger');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    $errors = [];

    if (empty($currentPassword)) {
        $errors[] = 'Le mot de passe actuel est requis.';
    }

    if (empty($newPassword)) {
        $errors[] = 'Le nouveau mot de passe est requis.';
    } elseif (strlen($newPassword) < 8) {
        $errors[] = 'Le nouveau mot de passe doit contenir au moins 8 caractères.';
    }

    if ($newPassword !== $confirmPassword) {
        $errors[] = 'Les mots de passe ne correspondent pas.';
    }

    if (empty($errors)) {
        try {
            $userPassword = $db->query(
                "SELECT password FROM users WHERE id = ? LIMIT 1",
                [$_SESSION['user_id']],
                true
            );

            if ($userPassword && password_verify($currentPassword, $userPassword['password'])) {

                $passwordHash = password_hash($newPassword, PASSWORD_DEFAULT);

                $db->update(
                    'users',
                    [
                        'password' => $passwordHash,
                        'updated_at' => date('Y-m-d H:i:s')
                    ],
                    'id = ?',
                    [$_SESSION['user_id']]
                );

                setAlert('Votre mot de passe a été mis à jour avec succès.', 'success');
                redirect('profile.php');
                exit;
            } else {
                setAlert('Le mot de passe actuel est incorrect.', 'danger');
            }
        } catch (Exception $e) {
            setAlert('Erreur lors de la mise à jour du mot de passe: ' . $e->getMessage(), 'danger');
        }
    } else {
        setAlert(implode('<br>', $errors), 'danger');
    }
}


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Mon Profil</h1>
    </div>

    <div class="row">
        <div class="col-xl-8 col-lg-7">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informations personnelles</h6>
                </div>
                <div class="card-body">
                    <form action="profile.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="update_profile" value="1">

                        <div class="row mb-4">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="first_name" class="form-label">Prénom</label>
                                        <input type="text" class="form-control" id="first_name" name="first_name"
                                            value="<?= htmlspecialchars($user['first_name'] ?? '') ?>" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="last_name" class="form-label">Nom</label>
                                        <input type="text" class="form-control" id="last_name" name="last_name"
                                            value="<?= htmlspecialchars($user['last_name'] ?? '') ?>" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email"
                                        value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Téléphone</label>
                                    <input type="tel" class="form-control" id="phone" name="phone"
                                        value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <h6 class="mb-3 text-primary">Informations complémentaires</h6>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="gender" class="form-label">Genre</label>
                                <select class="form-select" id="gender" name="gender">
                                    <option value="">Non spécifié</option>
                                    <option value="M" <?= ($user['gender'] ?? '') == 'M' ? 'selected' : '' ?>>Homme</option>
                                    <option value="F" <?= ($user['gender'] ?? '') == 'F' ? 'selected' : '' ?>>Femme</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="birthdate" class="form-label">Date de naissance</label>
                                <input type="date" class="form-control" id="birthdate" name="birthdate"
                                    value="<?= htmlspecialchars($user['birthdate'] ?? '') ?>">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">Adresse</label>
                            <input type="text" class="form-control" id="address" name="address"
                                value="<?= htmlspecialchars($user['address'] ?? '') ?>">
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label for="postal_code" class="form-label">Code postal</label>
                                <input type="text" class="form-control" id="postal_code" name="postal_code"
                                    value="<?= htmlspecialchars($user['postal_code'] ?? '') ?>">
                            </div>
                            <div class="col-md-8">
                                <label for="city" class="form-label">Ville</label>
                                <input type="text" class="form-control" id="city" name="city"
                                    value="<?= htmlspecialchars($user['city'] ?? '') ?>">
                            </div>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
                        </div>
                    </form>
                </div>
            </div>
            


        <div class="col-xl-4 col-lg-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Sécurité</h6>
                </div>
                <div class="card-body">
                    <form action="profile.php" method="post">
                        <input type="hidden" name="change_password" value="1">

                        <div class="mb-3">
                            <label for="current_password" class="form-label">Mot de passe actuel</label>
                            <input type="password" class="form-control" id="current_password" name="current_password"
                                required>
                        </div>

                        <div class="mb-3">
                            <label for="new_password" class="form-label">Nouveau mot de passe</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required
                                minlength="8">
                            <div class="form-text">8 caractères minimum</div>
                        </div>

                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirmer le mot de passe</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password"
                                required>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">Changer le mot de passe</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informations sur l'entreprise</h6>
                </div>
                <div class="card-body">
                    <div class="mb-4">
                        <h6>Votre entreprise</h6>
                        <p class="lead mb-1"><?= htmlspecialchars($user['company_name'] ?? 'Non spécifié') ?></p>
                        <p class="text-muted mb-0">ID: <?= htmlspecialchars($user['company_id'] ?? 'N/A') ?></p>
                    </div>

                    <div class="mb-4">
                        <h6>Accès aux services</h6>
                        <div class="d-flex align-items-center mb-2">
                            <div>
                                <ul class="list-unstyled mb-0">
                                    <li><i class="fas fa-check-circle text-success me-2"></i> Rendez-vous médicaux</li>
                                    <li><i class="fas fa-check-circle text-success me-2"></i> Événements bien-être</li>
                                    <li><i class="fas fa-check-circle text-success me-2"></i> Accès carte NFC</li>
                                    <li><i class="fas fa-check-circle text-success me-2"></i> Communautés</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="nfc-card.php" class="btn btn-sm btn-primary">
                            <i class="fas fa-id-card me-1"></i> Gérer ma carte NFC
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include_once __DIR__ . '/../includes/footer.php';
?>