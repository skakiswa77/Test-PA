<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';


if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'company_admin') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que entreprise.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}


$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT company_id FROM users WHERE id = :user_id");
$stmt->execute(['user_id' => $admin_id]);
$company_id = $stmt->fetchColumn();

if (!$company_id) {
    $error_message = "Erreur: Vous n'êtes pas associé à une entreprise.";
} else {

    $stmt = $pdo->prepare("SELECT * FROM companies WHERE id = :company_id");
    $stmt->execute(['company_id' => $company_id]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);
    

    $stmt = $pdo->prepare("
        SELECT s.*, sp.* 
        FROM subscriptions s
        JOIN subscription_plans sp ON s.plan_id = sp.id
        WHERE s.company_id = :company_id AND s.is_active = 1
        ORDER BY s.end_date DESC
        LIMIT 1
    ");
    $stmt->execute(['company_id' => $company_id]);
    $subscription = $stmt->fetch(PDO::FETCH_ASSOC);
    
    
    $stmt = $pdo->prepare("SELECT * FROM subscription_plans ORDER BY max_employees");
    $stmt->execute();
    $available_plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
    

    $stmt = $pdo->prepare("
        SELECT i.*, CONCAT(u.first_name, ' ', u.last_name) as paid_by
        FROM invoices i
        LEFT JOIN users u ON i.paid_by_user_id = u.id
        WHERE i.company_id = :company_id
        ORDER BY i.issue_date DESC
    ");
    $stmt->execute(['company_id' => $company_id]);
    $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as employee_count 
        FROM users 
        WHERE company_id = :company_id AND role = 'employee'
    ");
    $stmt->execute(['company_id' => $company_id]);
    $employee_count = $stmt->fetchColumn();
    
  
    $current_month_start = date('Y-m-01');
    $current_month_end = date('Y-m-t');
    

    $stmt = $pdo->prepare("
        SELECT COUNT(DISTINCT e.id) as event_count
        FROM events e
        JOIN event_registrations er ON e.id = er.event_id
        JOIN users u ON er.user_id = u.id
        WHERE u.company_id = :company_id
        AND e.start_datetime BETWEEN :start_date AND :end_date
    ");
    $stmt->execute([
        'company_id' => $company_id,
        'start_date' => $current_month_start . ' 00:00:00',
        'end_date' => $current_month_end . ' 23:59:59'
    ]);
    $event_count = $stmt->fetchColumn();
    

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as appointment_count
        FROM medical_appointments ma
        JOIN users u ON ma.user_id = u.id
        WHERE u.company_id = :company_id
        AND ma.appointment_datetime BETWEEN :start_date AND :end_date
    ");
    $stmt->execute([
        'company_id' => $company_id,
        'start_date' => $current_month_start . ' 00:00:00',
        'end_date' => $current_month_end . ' 23:59:59'
    ]);
    $appointment_count = $stmt->fetchColumn();
    

    $stmt = $pdo->prepare("
        SELECT COUNT(*) as chatbot_count
        FROM chatbot_questions cq
        JOIN users u ON cq.user_id = u.id
        WHERE u.company_id = :company_id
        AND cq.created_at BETWEEN :start_date AND :end_date
    ");
    $stmt->execute([
        'company_id' => $company_id,
        'start_date' => $current_month_start . ' 00:00:00',
        'end_date' => $current_month_end . ' 23:59:59'
    ]);
    $chatbot_count = $stmt->fetchColumn();
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_plan'])) {
        $new_plan_id = $_POST['new_plan_id'];
        
      
        $plan_exists = false;
        foreach ($available_plans as $plan) {
            if ($plan['id'] == $new_plan_id) {
                $plan_exists = true;
                $selected_plan = $plan;
                break;
            }
        }
        
        if ($plan_exists) {
            
            if ($employee_count <= $selected_plan['max_employees']) {
                try {
                    $pdo->beginTransaction();
                    
                    
                    if ($subscription) {
                        $stmt = $pdo->prepare("
                            UPDATE subscriptions 
                            SET is_active = 0
                            WHERE id = :subscription_id
                        ");
                        $stmt->execute(['subscription_id' => $subscription['id']]);
                    }
                    
                   
                    $start_date = date('Y-m-d');
                    $end_date = date('Y-m-d', strtotime('+1 year'));
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO subscriptions (company_id, plan_id, start_date, end_date, is_active)
                        VALUES (:company_id, :plan_id, :start_date, :end_date, 1)
                    ");
                    
                    $stmt->execute([
                        'company_id' => $company_id,
                        'plan_id' => $new_plan_id,
                        'start_date' => $start_date,
                        'end_date' => $end_date
                    ]);
                    
                    $subscription_id = $pdo->lastInsertId();
                    
                   
                    $amount = $selected_plan['price_per_employee_yearly'] * $employee_count;
                    $invoice_number = 'INV-' . date('Ymd') . '-' . $company_id . '-' . $subscription_id;
                    
                    $stmt = $pdo->prepare("
                        INSERT INTO invoices (company_id, subscription_id, invoice_number, amount, issue_date, due_date, status)
                        VALUES (:company_id, :subscription_id, :invoice_number, :amount, :issue_date, :due_date, 'pending')
                    ");
                    
                    $stmt->execute([
                        'company_id' => $company_id,
                        'subscription_id' => $subscription_id,
                        'invoice_number' => $invoice_number,
                        'amount' => $amount,
                        'issue_date' => date('Y-m-d'),
                        'due_date' => date('Y-m-d', strtotime('+15 days'))
                    ]);
                    
                    $pdo->commit();
                    
                    $success_message = "Votre abonnement a été mis à jour avec succès. Une nouvelle facture a été générée.";
                    
                
                    $stmt = $pdo->prepare("
                        SELECT s.*, sp.* 
                        FROM subscriptions s
                        JOIN subscription_plans sp ON s.plan_id = sp.id
                        WHERE s.id = :subscription_id
                    ");
                    $stmt->execute(['subscription_id' => $subscription_id]);
                    $subscription = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    
                    $stmt = $pdo->prepare("
                        SELECT i.*, CONCAT(u.first_name, ' ', u.last_name) as paid_by
                        FROM invoices i
                        LEFT JOIN users u ON i.paid_by_user_id = u.id
                        WHERE i.company_id = :company_id
                        ORDER BY i.issue_date DESC
                    ");
                    $stmt->execute(['company_id' => $company_id]);
                    $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                } catch (PDOException $e) {
                    $pdo->rollBack();
                    $error_message = "Une erreur est survenue lors de la mise à jour de l'abonnement: " . $e->getMessage();
                }
            } else {
                $error_message = "Le plan sélectionné ne peut pas accueillir tous vos employés. Veuillez choisir un plan avec une capacité plus élevée.";
            }
        } else {
            $error_message = "Le plan sélectionné n'existe pas.";
        }
    }
    
   
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_invoice'])) {
        $invoice_id = $_POST['invoice_id'];
        $payment_method = $_POST['payment_method'];
        
        try {
            $stmt = $pdo->prepare("
                UPDATE invoices 
                SET status = 'paid', 
                    payment_method = :payment_method,
                    paid_by_user_id = :paid_by_user_id,
                    paid_date = NOW()
                WHERE id = :invoice_id AND company_id = :company_id
            ");
            
            $stmt->execute([
                'payment_method' => $payment_method,
                'paid_by_user_id' => $admin_id,
                'invoice_id' => $invoice_id,
                'company_id' => $company_id
            ]);
            
            $invoice_success_message = "Le paiement de la facture a été enregistré avec succès.";
            
        
            $stmt = $pdo->prepare("
                SELECT i.*, CONCAT(u.first_name, ' ', u.last_name) as paid_by
                FROM invoices i
                LEFT JOIN users u ON i.paid_by_user_id = u.id
                WHERE i.company_id = :company_id
                ORDER BY i.issue_date DESC
            ");
            $stmt->execute(['company_id' => $company_id]);
            $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            $invoice_error_message = "Une erreur est survenue lors du paiement de la facture: " . $e->getMessage();
        }
    }
}

?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Gestion de l'abonnement</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    
                    <ul class="nav nav-tabs" id="subscriptionTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="current-tab" data-toggle="tab" href="#current" role="tab" aria-controls="current" aria-selected="true">Abonnement actuel</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="change-tab" data-toggle="tab" href="#change" role="tab" aria-controls="change" aria-selected="false">Changer d'abonnement</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="invoices-tab" data-toggle="tab" href="#invoices" role="tab" aria-controls="invoices" aria-selected="false">Factures</a>
                        </li>
                    </ul>
                    
                    <div class="tab-content mt-3" id="subscriptionTabsContent">
                        
                        <div class="tab-pane fade show active" id="current" role="tabpanel" aria-labelledby="current-tab">
                            <?php if (!$subscription): ?>
                                <div class="alert alert-warning">Vous n'avez pas d'abonnement actif.</div>
                            <?php else: ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="card mb-4">
                                            <div class="card-header bg-primary text-white">
                                                <h5 class="mb-0">Plan <?php echo htmlspecialchars($subscription['name']); ?></h5>
                                            </div>
                                            <div class="card-body">
                                                <p><?php echo nl2br(htmlspecialchars($subscription['description'])); ?></p>
                                                <hr>
                                                <p><strong>Date de début:</strong> <?php echo date('d/m/Y', strtotime($subscription['start_date'])); ?></p>
                                                <p><strong>Date de fin:</strong> <?php echo date('d/m/Y', strtotime($subscription['end_date'])); ?></p>
                                                <p><strong>Statut:</strong> 
                                                    <?php if ($subscription['is_active']): ?>
                                                        <span class="badge badge-success">Actif</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-danger">Inactif</span>
                                                    <?php endif; ?>
                                                </p>
                                                <p><strong>Prix par employé:</strong> <?php echo $subscription['price_per_employee_yearly']; ?> € / an</p>
                                                <p><strong>Employés actuels:</strong> <?php echo $employee_count; ?> / <?php echo $subscription['max_employees']; ?></p>
                                                
                                                <?php
                                                
                                                $total_amount = $subscription['price_per_employee_yearly'] * $employee_count;
                                                ?>
                                                <div class="alert alert-info">
                                                    <strong>Montant total annuel:</strong> <?php echo $total_amount; ?> €
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="card mb-4">
                                            <div class="card-header bg-info text-white">
                                                <h5 class="mb-0">Consommation du mois en cours</h5>
                                            </div>
                                            <div class="card-body">
                                                <div class="mb-3">
                                                    <label class="font-weight-bold">Activités / Événements</label>
                                                    <div class="progress mb-2">
                                                        <?php 
                                                        $event_percentage = min(100, ($event_count / $subscription['activities_per_month']) * 100);
                                                        ?>
                                                        <div class="progress-bar <?php echo $event_percentage > 80 ? 'bg-warning' : 'bg-success'; ?>" 
                                                            role="progressbar" 
                                                            style="width: <?php echo $event_percentage; ?>%" 
                                                            aria-valuenow="<?php echo $event_percentage; ?>" 
                                                            aria-valuemin="0" 
                                                            aria-valuemax="100">
                                                            <?php echo $event_count; ?> / <?php echo $subscription['activities_per_month']; ?>
                                                        </div>
                                                    </div>
                                                    <small class="text-muted">
                                                        <?php echo $subscription['activities_per_month'] - $event_count; ?> activité(s) restante(s) ce mois-ci
                                                    </small>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label class="font-weight-bold">Rendez-vous médicaux</label>
                                                    <div class="progress mb-2">
                                                        <?php 
                                                        $appointment_percentage = min(100, ($appointment_count / $subscription['medical_appointments_per_month']) * 100);
                                                        ?>
                                                        <div class="progress-bar <?php echo $appointment_percentage > 80 ? 'bg-warning' : 'bg-success'; ?>" 
                                                            role="progressbar" 
                                                            style="width: <?php echo $appointment_percentage; ?>%" 
                                                            aria-valuenow="<?php echo $appointment_percentage; ?>" 
                                                            aria-valuemin="0" 
                                                            aria-valuemax="100">
                                                            <?php echo $appointment_count; ?> / <?php echo $subscription['medical_appointments_per_month']; ?>
                                                        </div>
                                                    </div>
                                                    <small class="text-muted">
                                                        <?php echo $subscription['medical_appointments_per_month'] - $appointment_count; ?> rendez-vous restant(s) ce mois-ci
                                                    </small>
                                                    <br>
                                                    <small class="text-muted">
                                                        Coût supplémentaire: <?php echo $subscription['extra_medical_appointment_cost']; ?> € / rendez-vous
                                                    </small>
                                                </div>
                                                
                                                <div class="mb-3">
                                                    <label class="font-weight-bold">Questions Chatbot</label>
                                                    <?php if ($subscription['chatbot_questions_limit'] > 0): ?>
                                                        <div class="progress mb-2">
                                                            <?php 
                                                            $chatbot_percentage = min(100, ($chatbot_count / $subscription['chatbot_questions_limit']) * 100);
                                                            ?>
                                                            <div class="progress-bar <?php echo $chatbot_percentage > 80 ? 'bg-warning' : 'bg-success'; ?>" 
                                                                role="progressbar" 
                                                                style="width: <?php echo $chatbot_percentage; ?>%" 
                                                                aria-valuenow="<?php echo $chatbot_percentage; ?>" 
                                                                aria-valuemin="0" 
                                                                aria-valuemax="100">
                                                                <?php echo $chatbot_count; ?> / <?php echo $subscription['chatbot_questions_limit']; ?>
                                                            </div>
                                                        </div>
                                                        <small class="text-muted">
                                                            <?php echo $subscription['chatbot_questions_limit'] - $chatbot_count; ?> question(s) restante(s) ce mois-ci
                                                        </small>
                                                    <?php else: ?>
                                                        <div class="alert alert-success py-2">
                                                            <small>Questions illimitées (plan Premium)</small>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                
                                                <div class="mt-4">
                                                    <h6>Fonctionnalités incluses</h6>
                                                    <ul class="list-group">
                                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                                            Conseils hebdomadaires personnalisés
                                                            <?php if ($subscription['personalized_tips']): ?>
                                                                <span class="badge badge-success">Inclus</span>
                                                            <?php else: ?>
                                                                <span class="badge badge-secondary">Non inclus</span>
                                                            <?php endif; ?>
                                                        </li>
                                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                                            Accès aux fiches pratiques
                                                            <span class="badge badge-success">Illimité</span>
                                                        </li>
                                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                                            Événements et communautés internes
                                                            <span class="badge badge-success">Accès illimité</span>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        
                        <div class="tab-pane fade" id="change" role="tabpanel" aria-labelledby="change-tab">
                            <div class="alert alert-info mb-4">
                                <i class="fas fa-info-circle"></i> Changer d'abonnement entraînera la création d'une nouvelle facture et l'annulation de votre abonnement actuel.
                                Le nouvel abonnement démarrera immédiatement.
                            </div>
                            
                            <div class="row">
                                <?php foreach ($available_plans as $plan): ?>
                                    <div class="col-md-4 mb-4">
                                        <div class="card h-100 <?php echo $subscription && $subscription['id'] == $plan['id'] ? 'border-primary' : ''; ?>">
                                            <div class="card-header <?php echo $subscription && $subscription['id'] == $plan['id'] ? 'bg-primary text-white' : ''; ?>">
                                                <h5 class="mb-0">Plan <?php echo htmlspecialchars($plan['name']); ?></h5>
                                                <?php if ($subscription && $subscription['id'] == $plan['id']): ?>
                                                    <span class="badge badge-light">Actuel</span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="card-body">
                                                <h6 class="font-weight-bold text-center mb-3"><?php echo $plan['price_per_employee_yearly']; ?> € / employé / an</h6>
                                                <p><?php echo nl2br(htmlspecialchars($plan['description'])); ?></p>
                                                <hr>
                                                <ul class="list-unstyled">
                                                    <li><i class="fas fa-users"></i> Max <?php echo $plan['max_employees'] == 999999 ? 'illimité' : $plan['max_employees']; ?> employés</li>
                                                    <li><i class="fas fa-calendar-alt"></i> <?php echo $plan['activities_per_month']; ?> activités / mois</li>
                                                    <li><i class="fas fa-user-md"></i> <?php echo $plan['medical_appointments_per_month']; ?> RDV médicaux / mois</li>
                                                    <li><i class="fas fa-comment-dots"></i> 
                                                        <?php echo $plan['chatbot_questions_limit'] == -1 ? 'Questions illimitées' : $plan['chatbot_questions_limit'] . ' questions / mois'; ?>
                                                    </li>
                                                    <li><i class="fas fa-lightbulb"></i> 
                                                        <?php echo $plan['personalized_tips'] ? 'Conseils personnalisés' : 'Conseils génériques'; ?>
                                                    </li>
                                                </ul>
                                                
                                                <?php
                                                
                                                $plan_total = $plan['price_per_employee_yearly'] * $employee_count;
                                                ?>
                                                <div class="alert alert-info mt-3">
                                                    <strong>Total annuel:</strong> <?php echo $plan_total; ?> €
                                                    <br>
                                                    <small>Pour <?php echo $employee_count; ?> employés</small>
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <?php if ($employee_count > $plan['max_employees']): ?>
                                                    <button class="btn btn-secondary btn-block" disabled>
                                                        Trop d'employés (<?php echo $employee_count; ?>/<?php echo $plan['max_employees']; ?>)
                                                    </button>
                                                <?php elseif ($subscription && $subscription['id'] == $plan['id']): ?>
                                                    <button class="btn btn-success btn-block" disabled>
                                                        Plan actuel
                                                    </button>
                                                <?php else: ?>
                                                    <form method="post" action="" onsubmit="return confirm('Êtes-vous sûr de vouloir changer pour le plan <?php echo htmlspecialchars($plan['name']); ?> ?');">
                                                        <input type="hidden" name="new_plan_id" value="<?php echo $plan['id']; ?>">
                                                        <button type="submit" name="change_plan" class="btn btn-primary btn-block">
                                                            Choisir ce plan
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="invoices" role="tabpanel" aria-labelledby="invoices-tab">
                            <?php if (isset($invoice_success_message)): ?>
                                <div class="alert alert-success"><?php echo $invoice_success_message; ?></div>
                            <?php endif; ?>
                            
                            <?php if (isset($invoice_error_message)): ?>
                                <div class="alert alert-danger"><?php echo $invoice_error_message; ?></div>
                            <?php endif; ?>
                            
                            <?php if (empty($invoices)): ?>
                                <div class="alert alert-info">Aucune facture disponible.</div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-striped" id="invoicesTable">
                                        <thead>
                                            <tr>
                                                <th>Numéro</th>
                                                <th>Date d'émission</th>
                                                <th>Date d'échéance</th>
                                                <th>Montant</th>
                                                <th>Statut</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($invoices as $invoice): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($invoice['invoice_number']); ?></td>
                                                    <td><?php echo date('d/m/Y', strtotime($invoice['issue_date'])); ?></td>
                                                    <td><?php echo date('d/m/Y', strtotime($invoice['due_date'])); ?></td>
                                                    <td><?php echo $invoice['amount']; ?> €</td>
                                                    <td>
                                                     <?php 
                                                        switch ($invoice['status']) {
                                                            case 'pending':
                                                                echo '<span class="badge badge-warning">En attente</span>';
                                                                break;
                                                            case 'paid':
                                                                echo '<span class="badge badge-success">Payée</span>';
                                                                break;
                                                            case 'overdue':
                                                                echo '<span class="badge badge-danger">En retard</span>';
                                                                break;
                                                            case 'cancelled':
                                                                echo '<span class="badge badge-secondary">Annulée</span>';
                                                                break;
                                                        }
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group">
                                                            <a href="../download_invoice.php?id=<?php echo $invoice['id']; ?>" class="btn btn-sm btn-info" target="_blank">
                                                                <i class="fas fa-download"></i> Télécharger
                                                            </a>
                                                            
                                                            <?php if ($invoice['status'] === 'pending' || $invoice['status'] === 'overdue'): ?>
                                                                <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#payInvoiceModal" data-invoice-id="<?php echo $invoice['id']; ?>" data-invoice-number="<?php echo htmlspecialchars($invoice['invoice_number']); ?>" data-invoice-amount="<?php echo $invoice['amount']; ?>">
                                                                    <i class="fas fa-credit-card"></i> Payer
                                                                </button>
                                                            <?php elseif ($invoice['status'] === 'paid'): ?>
                                                                <button class="btn btn-sm btn-secondary" disabled>
                                                                    <i class="fas fa-check"></i> Payée le <?php echo date('d/m/Y', strtotime($invoice['paid_date'])); ?>
                                                                </button>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="payInvoiceModal" tabindex="-1" role="dialog" aria-labelledby="payInvoiceModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="payInvoiceModalLabel">Payer la facture</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <input type="hidden" name="invoice_id" id="modal_invoice_id">
                    
                    <div class="alert alert-info">
                        <p>Vous êtes sur le point de payer la facture <strong id="modal_invoice_number"></strong> d'un montant de <strong id="modal_invoice_amount"></strong> €.</p>
                    </div>
                    
                    <div class="form-group">
                        <label for="payment_method">Méthode de paiement</label>
                        <select name="payment_method" id="payment_method" class="form-control" required>
                            <option value="">Sélectionner une méthode</option>
                            <option value="credit_card">Carte bancaire</option>
                            <option value="bank_transfer">Virement bancaire</option>
                            <option value="direct_debit">Prélèvement automatique</option>
                        </select>
                    </div>
                    
                    <div id="credit_card_details" class="payment-details d-none">
                        <div class="form-group">
                            <label for="card_number">Numéro de carte</label>
                            <input type="text" id="card_number" class="form-control" placeholder="1234 5678 9012 3456">
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="expiry_date">Date d'expiration</label>
                                    <input type="text" id="expiry_date" class="form-control" placeholder="MM/AA">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="cvv">Code de sécurité</label>
                                    <input type="text" id="cvv" class="form-control" placeholder="123">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div id="bank_transfer_details" class="payment-details d-none">
                        <div class="alert alert-secondary">
                            <p>Veuillez effectuer un virement aux coordonnées bancaires suivantes:</p>
                            <p><strong>IBAN:</strong> FR76 3000 1007 1600 0000 0000 000</p>
                            <p><strong>BIC:</strong> BNPAFRPPXXX</p>
                            <p><strong>Référence:</strong> <span id="bank_transfer_reference"></span></p>
                        </div>
                    </div>
                    
                    <div id="direct_debit_details" class="payment-details d-none">
                        <div class="form-group">
                            <label for="iban">IBAN</label>
                            <input type="text" id="iban" class="form-control" placeholder="FR76 3000 1007 1600 0000 0000 000">
                        </div>
                        <div class="form-group">
                            <label for="account_holder">Titulaire du compte</label>
                            <input type="text" id="account_holder" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" name="pay_invoice" class="btn btn-success">Confirmer le paiement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#invoicesTable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json"
            },
            "order": [[1, "desc"]]
        });
        
        $('#payInvoiceModal').on('show.bs.modal', function (event) {
            const button = $(event.relatedTarget);
            const invoiceId = button.data('invoice-id');
            const invoiceNumber = button.data('invoice-number');
            const invoiceAmount = button.data('invoice-amount');
            
            const modal = $(this);
            modal.find('#modal_invoice_id').val(invoiceId);
            modal.find('#modal_invoice_number').text(invoiceNumber);
            modal.find('#modal_invoice_amount').text(invoiceAmount);
            modal.find('#bank_transfer_reference').text(invoiceNumber);
            
            modal.find('#payment_method').val('');
            $('.payment-details').addClass('d-none');
        });
        
        $('#payment_method').change(function() {
            const selectedMethod = $(this).val();
            $('.payment-details').addClass('d-none');
            
            if (selectedMethod) {
                $(`#${selectedMethod}_details`).removeClass('d-none');
            }
        });
    });
</script>

<?php include '../includes/footer.php'; ?> 
                                                                