<!DOCTYPE html>
<html>
<head>
    <title>Back Office - Dashboard</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
    <h1>Back Office - Gestion de Businness Care</h1>
    <nav>
        <a href="../dashboard.php">Menu</a> |
        <a href="../events/index.php">Gestion des Événements</a> |
        <a href="../companies/index.php">Gestion des Entreprises</a> |
        <a href="../nfc-card/index.php">Gestion des Carte NFC</a> |
        <a href="../providers/index.php">Gestion des Prestatairess</a> |
        <a href="../users/index.php">Gestion des Utilisateurs</a> |
        <a href="../subscriptions/index.php">Gestion des Abonnements</a> |
        <a href="../invoices/index.php">Gestion des Factures</a> |
        <a href="../quote/index.php">Gestion des Devis</a> |
        <a href="../../../logout.php">Déconnexion
            </a>
        
    </nav>
</body>
</html>