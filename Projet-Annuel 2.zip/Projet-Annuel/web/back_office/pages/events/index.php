<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Événements</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>
<?php


require_once '../../config/database.php';

$stmt = $pdo->query("SELECT e.*, et.name as event_type_name FROM events e 
                     LEFT JOIN event_types et ON e.event_type_id = et.id
                     ORDER BY e.start_datetime DESC");
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php
require_once '../../composants/nav.php';
?>

<h2>Gestion des Événements</h2>
<a href="add.php">Ajouter un Événement</a>
<table>
    <tr>
        <th>ID</th>
        <th>Titre</th>
        <th>Type</th>
        <th>Date & Heure</th>
        <th>Lieu</th>
        <th>Date de création</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($events as $event): ?>
        <tr>
            <td><?php echo $event['id']; ?></td>
            <td><?php echo htmlspecialchars($event['title']); ?></td>
            <td><?php echo htmlspecialchars($event['event_type_name']); ?></td>
            <td><?php echo date('d/m/Y H:i', strtotime($event['start_datetime'])); ?></td>
            <td>
                <?php if ($event['is_virtual']): ?>
                    <span>Événement virtuel</span>
                <?php else: ?>
                    <?php echo htmlspecialchars($event['location']); ?>
                <?php endif; ?>
            </td>
            <td><?php echo date('d/m/Y', strtotime($event['created_at'])); ?></td>
            <td>
                <a href="edit.php?id=<?php echo $event['id']; ?>">Modifier</a>
                <a href="archive.php?id=<?php echo $event['id']; ?>"
                    onclick="return confirm('Voulez-vous vraiment supprimer cet événement?')">Supprimer</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>
</body>
</html>