<?php
session_start();
require_once '../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$employee_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT c.name as company_name, sp.name as plan_name, sp.description as plan_description,
           s.start_date, s.end_date, s.is_active,
           sp.activities_per_month, sp.medical_appointments_per_month, sp.extra_medical_appointment_cost,
           sp.chatbot_questions_limit, sp.personalized_tips
    FROM users u
    JOIN companies c ON u.company_id = c.id
    JOIN subscriptions s ON c.id = s.company_id
    JOIN subscription_plans sp ON s.plan_id = sp.id
    WHERE u.id = :user_id
");
$stmt->execute(['user_id' => $employee_id]);
$subscription = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT e.id) as events_count
    FROM events e
    JOIN event_registrations er ON e.id = er.event_id
    JOIN users u ON er.user_id = u.id
    WHERE u.company_id = (SELECT company_id FROM users WHERE id = :user_id)
    AND MONTH(e.start_datetime) = MONTH(CURRENT_DATE())
    AND YEAR(e.start_datetime) = YEAR(CURRENT_DATE())
");
$stmt->execute(['user_id' => $employee_id]);
$events_count = $stmt->fetch(PDO::FETCH_ASSOC)['events_count'];

$stmt = $pdo->prepare("
    SELECT COUNT(DISTINCT ma.id) as appointments_count
    FROM medical_appointments ma
    JOIN users u ON ma.user_id = u.id
    WHERE u.company_id = (SELECT company_id FROM users WHERE id = :user_id)
    AND MONTH(ma.appointment_datetime) = MONTH(CURRENT_DATE())
    AND YEAR(ma.appointment_datetime) = YEAR(CURRENT_DATE())
");
$stmt->execute(['user_id' => $employee_id]);
$appointments_count = $stmt->fetch(PDO::FETCH_ASSOC)['appointments_count'];

$stmt = $pdo->prepare("
    SELECT COUNT(*) as chatbot_count
    FROM chatbot_questions
    WHERE user_id = :user_id
    AND MONTH(created_at) = MONTH(CURRENT_DATE())
    AND YEAR(created_at) = YEAR(CURRENT_DATE())
");
$stmt->execute(['user_id' => $employee_id]);
$chatbot_count = $stmt->fetch(PDO::FETCH_ASSOC)['chatbot_count'];


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Informations sur l'abonnement</h4>
                </div>
                <div class="card-body">
                    <?php if (!$subscription): ?>
                        <div class="alert alert-warning">Impossible de récupérer les informations sur l'abonnement.</div>
                    <?php else: ?>
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Entreprise</h5>
                                <p><strong>Nom:</strong> <?php echo htmlspecialchars($subscription['company_name']); ?></p>
                                <p><strong>Plan:</strong> <?php echo htmlspecialchars($subscription['plan_name']); ?></p>
                                <p><strong>Date de début:</strong> <?php echo date('d/m/Y', strtotime($subscription['start_date'])); ?></p>
                                <p><strong>Date de fin:</strong> <?php echo date('d/m/Y', strtotime($subscription['end_date'])); ?></p>
                                <p><strong>Statut:</strong> 
                                    <?php echo $subscription['is_active'] ? 
                                        '<span class="badge badge-success">Actif</span>' : 
                                        '<span class="badge badge-danger">Inactif</span>'; ?>
                                </p>
                            </div>
                            <div class="col-md-6">
                                <h5>Description du plan</h5>
                                <p><?php echo nl2br(htmlspecialchars($subscription['plan_description'])); ?></p>
                            </div>
                        </div>
                        
                        <hr>
                        
                        <h5>Droits et consommation du mois en cours</h5>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h6 class="card-title">Activités / Événements</h6>
                                        <div class="progress mb-3">
                                            <?php 
                                            $events_percentage = min(100, ($events_count / $subscription['activities_per_month']) * 100);
                                            ?>
                                            <div class="progress-bar <?php echo $events_percentage > 80 ? 'bg-warning' : 'bg-success'; ?>" 
                                                role="progressbar" 
                                                style="width: <?php echo $events_percentage; ?>%" 
                                                aria-valuenow="<?php echo $events_percentage; ?>" 
                                                aria-valuemin="0" 
                                                aria-valuemax="100">
                                                <?php echo $events_count; ?> / <?php echo $subscription['activities_per_month']; ?>
                                            </div>
                                        </div>
                                        <p class="card-text">
                                            <small class="text-muted">
                                                <?php echo $subscription['activities_per_month'] - $events_count; ?> activité(s) restante(s) ce mois-ci
                                            </small>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h6 class="card-title">Rendez-vous médicaux</h6>
                                        <div class="progress mb-3">
                                            <?php 
                                            $appointments_percentage = min(100, ($appointments_count / $subscription['medical_appointments_per_month']) * 100);
                                            ?>
                                            <div class="progress-bar <?php echo $appointments_percentage > 80 ? 'bg-warning' : 'bg-success'; ?>" 
                                                role="progressbar" 
                                                style="width: <?php echo $appointments_percentage; ?>%" 
                                                aria-valuenow="<?php echo $appointments_percentage; ?>" 
                                                aria-valuemin="0" 
                                                aria-valuemax="100">
                                                <?php echo $appointments_count; ?> / <?php echo $subscription['medical_appointments_per_month']; ?>
                                            </div>
                                        </div>
                                        <p class="card-text">
                                            <small class="text-muted">
                                                <?php echo $subscription['medical_appointments_per_month'] - $appointments_count; ?> rendez-vous restant(s) ce mois-ci
                                            </small>
                                        </p>
                                        <p class="card-text">
                                            <small class="text-muted">
                                                Coût supplémentaire: <?php echo $subscription['extra_medical_appointment_cost']; ?> € / rendez-vous
                                            </small>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h6 class="card-title">Questions Chatbot</h6>
                                        <?php if ($subscription['chatbot_questions_limit'] > 0): ?>
                                            <div class="progress mb-3">
                                                <?php 
                                                $chatbot_percentage = min(100, ($chatbot_count / $subscription['chatbot_questions_limit']) * 100);
                                                ?>
                                                <div class="progress-bar <?php echo $chatbot_percentage > 80 ? 'bg-warning' : 'bg-success'; ?>" 
                                                    role="progressbar" 
                                                    style="width: <?php echo $chatbot_percentage; ?>%" 
                                                    aria-valuenow="<?php echo $chatbot_percentage; ?>" 
                                                    aria-valuemin="0" 
                                                    aria-valuemax="100">
                                                    <?php echo $chatbot_count; ?> / <?php echo $subscription['chatbot_questions_limit']; ?>
                                                </div>
                                            </div>
                                            <p class="card-text">
                                                <small class="text-muted">
                                                    <?php echo $subscription['chatbot_questions_limit'] - $chatbot_count; ?> question(s) restante(s) ce mois-ci
                                                </small>
                                            </p>
                                        <?php else: ?>
                                            <p class="card-text">
                                                <span class="badge badge-success">Questions illimitées</span>
                                            </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <h5>Fonctionnalités du plan</h5>
                        <ul class="list-group mb-3">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Conseils hebdomadaires personnalisés
                                <?php if ($subscription['personalized_tips']): ?>
                                    <span class="badge badge-success">Inclus</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">Non inclus</span>
                                <?php endif; ?>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Accès aux fiches pratiques
                                <span class="badge badge-success">Illimité</span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Événements et communautés internes
                                <span class="badge badge-success">Accès illimité</span>
                            </li>
                        </ul>
                        
                        <div class="alert alert-info">
                            Pour toute question concernant votre abonnement ou pour demander des services supplémentaires, veuillez contacter votre administrateur d'entreprise.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>