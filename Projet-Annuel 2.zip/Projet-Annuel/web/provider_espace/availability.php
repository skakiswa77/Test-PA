<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'provider') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que prestataire.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Gestion des Disponibilités";
$providerId = $_SESSION['user_id'];

$daysOfWeek = [
    0 => 'Dimanche',
    1 => 'Lundi',
    2 => 'Mardi',
    3 => 'Mercredi',
    4 => 'Jeudi',
    5 => 'Vendredi',
    6 => 'Samedi'
];

try {
    $availabilities = $db->query(
        "SELECT * FROM provider_availability 
         WHERE provider_id = ? 
         ORDER BY day_of_week",
        [$providerId]
    );
    
    $currentAvailabilities = [];
    foreach ($availabilities as $availability) {
        $currentAvailabilities[$availability['day_of_week']] = $availability;
    }
} catch (Exception $e) {
    $currentAvailabilities = [];
    setAlert('Erreur lors du chargement des disponibilités: ' . $e->getMessage(), 'danger');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['save_availability'])) {
        try {
            $db->beginTransaction();
            
            $db->execute(
                "DELETE FROM provider_availability WHERE provider_id = ?",
                [$providerId]
            );
            
            foreach ($daysOfWeek as $dayNum => $dayName) {
                if (isset($_POST['is_available'][$dayNum])) {
                    $startTime = $_POST['start_time'][$dayNum] ?? '09:00';
                    $endTime = $_POST['end_time'][$dayNum] ?? '18:00';
                    
                    $db->execute(
                        "INSERT INTO provider_availability 
                         (provider_id, day_of_week, start_time, end_time, is_available, created_at, updated_at) 
                         VALUES (?, ?, ?, ?, 1, NOW(), NOW())",
                        [$providerId, $dayNum, $startTime, $endTime]
                    );
                }
            }
            
            $db->commit();
            setAlert('Vos disponibilités ont été mises à jour avec succès.', 'success');
            
            $availabilities = $db->query(
                "SELECT * FROM provider_availability 
                 WHERE provider_id = ? 
                 ORDER BY day_of_week",
                [$providerId]
            );
            
            $currentAvailabilities = [];
            foreach ($availabilities as $availability) {
                $currentAvailabilities[$availability['day_of_week']] = $availability;
            }
            
        } catch (Exception $e) {

            try {

                $db->rollBack();
            } catch (Exception $rollbackEx) {

                error_log('Erreur lors du rollback: ' . $rollbackEx->getMessage());
            }
            
            setAlert('Erreur lors de la mise à jour des disponibilités: ' . $e->getMessage(), 'danger');
        }
    } elseif (isset($_POST['toggle_global_availability'])) {
        $globalStatus = isset($_POST['global_is_available']) ? 1 : 0;
        
        try {

            $existingGlobalStatus = $db->query(
                "SELECT id FROM provider_availability 
                 WHERE provider_id = ? AND day_of_week = -1 
                 LIMIT 1",
                [$providerId],
                true
            );
            
            if ($existingGlobalStatus) {
                $db->execute(
                    "UPDATE provider_availability 
                     SET is_available = ?, updated_at = NOW() 
                     WHERE provider_id = ? AND day_of_week = -1",
                    [$globalStatus, $providerId]
                );
            } else {
                $db->execute(
                    "INSERT INTO provider_availability 
                     (provider_id, day_of_week, start_time, end_time, is_available, created_at, updated_at) 
                     VALUES (?, -1, '00:00', '23:59', ?, NOW(), NOW())",
                    [$providerId, $globalStatus]
                );
            }
            
            setAlert('Votre disponibilité globale a été mise à jour.', 'success');
            
        } catch (Exception $e) {
            setAlert('Erreur lors de la mise à jour de la disponibilité globale: ' . $e->getMessage(), 'danger');
        }
    }
}

try {
    $globalAvailability = $db->query(
        "SELECT is_available FROM provider_availability 
         WHERE provider_id = ? AND day_of_week = -1 
         LIMIT 1",
        [$providerId],
        true
    );
    
    $isGloballyAvailable = $globalAvailability ? $globalAvailability['is_available'] : true;
} catch (Exception $e) {
    $isGloballyAvailable = true;
}

?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Gestion des Disponibilités</h1>
        <a href="appointments.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Retour aux rendez-vous
        </a>
    </div>
    
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Disponibilité Globale</h6>
                </div>
                <div class="card-body">
                    <form method="post" action="">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" id="globalAvailabilitySwitch" 
                                   name="global_is_available" <?= $isGloballyAvailable ? 'checked' : '' ?>>
                            <label class="form-check-label" for="globalAvailabilitySwitch">
                                <span class="fw-bold">Je suis disponible pour des rendez-vous</span>
                            </label>
                        </div>
                        <p class="text-muted small">
                            Ce paramètre affecte votre disponibilité globale. Si vous le désactivez, vous ne serez plus disponible pour aucun rendez-vous, 
                            indépendamment de vos heures de disponibilité spécifiques.
                        </p>
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" name="toggle_global_availability" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i> Enregistrer
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Horaires de Disponibilité</h6>
        </div>
        <div class="card-body">
            <form method="post" action="">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Jour</th>
                                <th>Disponible</th>
                                <th>Heure de début</th>
                                <th>Heure de fin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($daysOfWeek as $dayNum => $dayName): ?>
                                <tr>
                                    <td><?= $dayName ?></td>
                                    <td>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input day-switch" type="checkbox" 
                                                   id="day<?= $dayNum ?>" name="is_available[<?= $dayNum ?>]" value="1"
                                                   data-day="<?= $dayNum ?>"
                                                   <?= isset($currentAvailabilities[$dayNum]) ? 'checked' : '' ?>>
                                        </div>
                                    </td>
                                    <td>
                                        <input type="time" class="form-control time-input" 
                                               id="startTime<?= $dayNum ?>" name="start_time[<?= $dayNum ?>]"
                                               value="<?= isset($currentAvailabilities[$dayNum]) ? $currentAvailabilities[$dayNum]['start_time'] : '09:00' ?>"
                                               <?= isset($currentAvailabilities[$dayNum]) ? '' : 'disabled' ?>>
                                    </td>
                                    <td>
                                        <input type="time" class="form-control time-input" 
                                               id="endTime<?= $dayNum ?>" name="end_time[<?= $dayNum ?>]"
                                               value="<?= isset($currentAvailabilities[$dayNum]) ? $currentAvailabilities[$dayNum]['end_time'] : '18:00' ?>"
                                               <?= isset($currentAvailabilities[$dayNum]) ? '' : 'disabled' ?>>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                    <button type="submit" name="save_availability" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Enregistrer les disponibilités
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Informations</h6>
        </div>
        <div class="card-body">
            <p><i class="fas fa-info-circle me-2 text-primary"></i> Vos disponibilités sont utilisées pour :</p>
            <ul>
                <li>Déterminer les créneaux disponibles pour les rendez-vous médicaux</li>
                <li>Informer les entreprises et les employés de vos heures de disponibilité</li>
                <li>Planifier les événements et ateliers en fonction de votre emploi du temps</li>
            </ul>
            <p class="mb-0">Pour les absences ponctuelles ou les congés, veuillez les signaler séparément.</p>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const daySwitches = document.querySelectorAll('.day-switch');
    
    daySwitches.forEach(function(daySwitch) {
        daySwitch.addEventListener('change', function() {
            const dayNum = this.dataset.day;
            const startTimeInput = document.getElementById('startTime' + dayNum);
            const endTimeInput = document.getElementById('endTime' + dayNum);
            
            if (this.checked) {
                startTimeInput.removeAttribute('disabled');
                endTimeInput.removeAttribute('disabled');
            } else {
                startTimeInput.setAttribute('disabled', 'disabled');
                endTimeInput.setAttribute('disabled', 'disabled');
            }
        });
    });
});
</script>
<?php
include_once __DIR__ . '/../includes/footer.php';
?>