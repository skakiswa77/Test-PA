<?php
$paths = [
    'Employee Dashboard' => '/web/employee_espace/dashboard.php',
    'Company Admin Dashboard' => '/web/client_espace/dashboards.php',
    'Provider Dashboard' => '/web/provider_espace/dashboard.php',
    'Admin Dashboard' => '/../back_office/pages/dashboard.php'
];

echo "<!DOCTYPE html><html><body>";
echo "<h1>Path Verification for MAMP</h1>";
echo "<table border='1'>";
echo "<tr><th>Path Description</th><th>Full Path</th><th>Exists</th></tr>";

foreach ($paths as $description => $path) {
    $fullPath = $_SERVER['DOCUMENT_ROOT'] . $path;
    $exists = file_exists($fullPath);
    
    echo "<tr>";
    echo "<td>" . htmlspecialchars($description) . "</td>";
    echo "<td>" . htmlspecialchars($fullPath) . "</td>";
    echo "<td>" . ($exists ? "✅ Yes" : "❌ No") . "</td>";
    echo "</tr>";
}

echo "</table>";

echo "<h2>Server Information</h2>";
echo "<p>Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p>Current Script: " . $_SERVER['SCRIPT_FILENAME'] . "</p>";
echo "</body></html>";

