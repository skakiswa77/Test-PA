<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Entreprises</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>
    <?php
require_once '../../composants/nav.php';
require_once '../../config/database.php';

    if (!$pdo) {
        die("Erreur de connexion à la base de données");
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            $stmt = $pdo->prepare("INSERT INTO companies (name, address, phone, email, created_at, updated_at) 
                             VALUES (:name, :address, :phone, :email, NOW(), NOW())");

            $result = $stmt->execute([
                ':name' => $_POST['name'],
                ':address' => $_POST['address'],
                ':phone' => $_POST['phone'],
                ':email' => $_POST['email'],
            ]);

            if ($result) {
                header("Location: index.php");
                exit();
            } else {
                echo "<p style='color: red;'>Erreur lors de l'ajout de l'entreprise</p>";
            }
        } catch (PDOException $e) {
            echo "<p style='color: red;'>Erreur: " . $e->getMessage() . "</p>";
        }
    }
    ?>

    <h2>Ajouter une Entreprise</h2>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        <div>
            <input type="text" name="name" placeholder="Nom de l'Entreprise" required>
        </div>
        <div>
            <input type="text" name="address" placeholder="Adresse" required>
        </div>
        <div>
            <input type="tel" name="phone" placeholder="Numéro de téléphone" required>
        </div>
        <div>
            <input type="email" name="email" placeholder="Email" required>
        </div>
        <div>
            <button type="submit">Ajouter</button>
        </div>
    </form>
</body>

</html>