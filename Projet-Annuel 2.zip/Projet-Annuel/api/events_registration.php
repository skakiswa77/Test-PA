<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id']) ? $_GET['id'] : null;

switch ($method) {
    case 'GET':
        if ($id) {
            getRegistration($db, $id);
        } else {
            getRegistrations($db);
        }
        break;
    case 'POST':
        createRegistration($db);
        break;
    case 'PUT':
        if ($id) {
            updateRegistrationStatus($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID inscription manquant."));
        }
        break;
    case 'DELETE':
        if ($id) {
            deleteRegistration($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID inscription manquant."));
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Méthode non autorisée."));
        break;
}

function getRegistrations($db)
{
    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $start = ($page - 1) * $limit;

    $where = "WHERE 1";
    $params = array();

    if (isset($_GET['event_id']) && !empty($_GET['event_id'])) {
        $where .= " AND er.event_id = :event_id";
        $params[':event_id'] = $_GET['event_id'];
    }

    if (isset($_GET['user_id']) && !empty($_GET['user_id'])) {
        $where .= " AND er.user_id = :user_id";
        $params[':user_id'] = $_GET['user_id'];
    }

    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $where .= " AND er.status = :status";
        $params[':status'] = $_GET['status'];
    }

    $query = "SELECT er.*, e.title as event_title, e.start_datetime, 
              u.first_name, u.last_name, u.email
              FROM event_registrations er 
              JOIN events e ON er.event_id = e.id 
              JOIN users u ON er.user_id = u.id 
              $where 
              ORDER BY er.registration_date DESC 
              LIMIT :start, :limit";

    $stmt = $db->prepare($query);
    $stmt->bindParam(':start', $start, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    $stmt->execute();

    $countQuery = "SELECT COUNT(*) as total 
                  FROM event_registrations er 
                  JOIN events e ON er.event_id = e.id 
                  JOIN users u ON er.user_id = u.id 
                  $where";
    $countStmt = $db->prepare($countQuery);

    foreach ($params as $key => $value) {
        $countStmt->bindValue($key, $value);
    }

    $countStmt->execute();
    $row = $countStmt->fetch(PDO::FETCH_ASSOC);
    $totalRegistrations = $row['total'];

    if ($stmt->rowCount() > 0) {
        $registrations_arr = array();
        $registrations_arr["registrations"] = array();
        $registrations_arr["pagination"] = array(
            "total" => $totalRegistrations,
            "pages" => ceil($totalRegistrations / $limit),
            "current_page" => (int) $page,
            "per_page" => (int) $limit
        );

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $registration_item = array(
                "id" => $row['id'],
                "event" => array(
                    "id" => $row['event_id'],
                    "title" => $row['event_title'],
                    "start_datetime" => $row['start_datetime']
                ),
                "user" => array(
                    "id" => $row['user_id'],
                    "name" => $row['first_name'] . ' ' . $row['last_name'],
                    "email" => $row['email']
                ),
                "status" => $row['status'],
                "registration_date" => $row['registration_date']
            );

            array_push($registrations_arr["registrations"], $registration_item);
        }

        http_response_code(200);
        echo json_encode($registrations_arr);
    } else {
        http_response_code(200);
        echo json_encode(array("message" => "Aucune inscription trouvée.", "registrations" => array()));
    }
}

function getRegistration($db, $id)
{
    $query = "SELECT er.*, e.title as event_title, e.description as event_description, 
              e.start_datetime, e.end_datetime, e.location, e.is_virtual, e.max_participants,
              et.name as event_type_name, et.is_medical,
              u.first_name, u.last_name, u.email, u.phone
              FROM event_registrations er 
              JOIN events e ON er.event_id = e.id 
              JOIN event_types et ON e.event_type_id = et.id 
              JOIN users u ON er.user_id = u.id 
              WHERE er.id = :id";

    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        $registration = array(
            "id" => $row['id'],
            "event" => array(
                "id" => $row['event_id'],
                "title" => $row['event_title'],
                "description" => $row['event_description'],
                "type" => $row['event_type_name'],
                "is_medical" => (bool) $row['is_medical'],
                "start_datetime" => $row['start_datetime'],
                "end_datetime" => $row['end_datetime'],
                "location" => $row['location'],
                "is_virtual" => (bool) $row['is_virtual'],
                "max_participants" => $row['max_participants']
            ),
            "user" => array(
                "id" => $row['user_id'],
                "first_name" => $row['first_name'],
                "last_name" => $row['last_name'],
                "email" => $row['email'],
                "phone" => $row['phone']
            ),
            "status" => $row['status'],
            "registration_date" => $row['registration_date']
        );

        http_response_code(200);
        echo json_encode($registration);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Inscription non trouvée."));
    }
}

function createRegistration($db)
{
    $data = json_decode(file_get_contents("php://input"));

    if (!empty($data->event_id) && !empty($data->user_id)) {
        $eventQuery = "SELECT e.id, e.max_participants, e.start_datetime, et.is_medical 
                      FROM events e 
                      JOIN event_types et ON e.event_type_id = et.id 
                      WHERE e.id = :id";
        $eventStmt = $db->prepare($eventQuery);
        $eventStmt->bindParam(':id', $data->event_id);
        $eventStmt->execute();

        if ($eventStmt->rowCount() == 0) {
            http_response_code(404);
            echo json_encode(array("message" => "Événement non trouvé."));
            return;
        }

        $eventData = $eventStmt->fetch(PDO::FETCH_ASSOC);

        $now = new DateTime();
        $eventDate = new DateTime($eventData['start_datetime']);

        if ($eventDate < $now) {
            http_response_code(400);
            echo json_encode(array("message" => "Impossible de s'inscrire à un événement passé."));
            return;
        }

        $userQuery = "SELECT id FROM users WHERE id = :id";
        $userStmt = $db->prepare($userQuery);
        $userStmt->bindParam(':id', $data->user_id);
        $userStmt->execute();

        if ($userStmt->rowCount() == 0) {
            http_response_code(404);
            echo json_encode(array("message" => "Utilisateur non trouvé."));
            return;
        }
        $checkQuery = "SELECT id FROM event_registrations 
                      WHERE event_id = :event_id AND user_id = :user_id";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindParam(':event_id', $data->event_id);
        $checkStmt->bindParam(':user_id', $data->user_id);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {
            http_response_code(400);
            echo json_encode(array("message" => "L'utilisateur est déjà inscrit à cet événement."));
            return;
        }

        if ($eventData['max_participants'] > 0) {
            $countQuery = "SELECT COUNT(*) as count FROM event_registrations WHERE event_id = :event_id";
            $countStmt = $db->prepare($countQuery);
            $countStmt->bindParam(':event_id', $data->event_id);
            $countStmt->execute();
            $countData = $countStmt->fetch(PDO::FETCH_ASSOC);

            if ($countData['count'] >= $eventData['max_participants']) {
                http_response_code(400);
                echo json_encode(array("message" => "L'événement est complet."));
                return;
            }
        }
        $query = "INSERT INTO event_registrations
                 (event_id, user_id, registration_date, status) 
                 VALUES 
                 (:event_id, :user_id, NOW(), :status)";

        $stmt = $db->prepare($query);

        $status = isset($data->status) ? $data->status : 'pending';

        $stmt->bindParam(':event_id', $data->event_id);
        $stmt->bindParam(':user_id', $data->user_id);
        $stmt->bindParam(':status', $status);

        if ($stmt->execute()) {
            $registration_id = $db->lastInsertId();

            http_response_code(201);
            echo json_encode(array(
                "message" => "Inscription créée avec succès.",
                "id" => $registration_id
            ));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Impossible de créer l'inscription."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Données incomplètes."));
    }
}

function updateRegistrationStatus($db, $id)
{
    $data = json_decode(file_get_contents("php://input"));

    if (!empty($data->status)) {

        $checkQuery = "SELECT id FROM event_registrations WHERE id = :id";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindParam(':id', $id);
        $checkStmt->execute();

        if ($checkStmt->rowCount() > 0) {

            $validStatuses = array('pending', 'confirmed', 'cancelled', 'attended');

            if (!in_array($data->status, $validStatuses)) {
                http_response_code(400);
                echo json_encode(array("message" => "Statut non valide."));
                return;
            }

            $query = "UPDATE event_registrations SET status = :status WHERE id = :id";

            $stmt = $db->prepare($query);
            $stmt->bindParam(':status', $data->status);
            $stmt->bindParam(':id', $id);

            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("message" => "Statut de l'inscription mis à jour avec succès."));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de mettre à jour le statut de l'inscription."));
            }
        } else {
            http_response_code(404);
            echo json_encode(array("message" => "Inscription non trouvée."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Statut manquant."));
    }
}

function deleteRegistration($db, $id)
{
    $checkQuery = "SELECT er.id, e.start_datetime 
                  FROM event_registrations er 
                  JOIN events e ON er.event_id = e.id 
                  WHERE er.id = :id";
    $checkStmt = $db->prepare($checkQuery);
    $checkStmt->bindParam(':id', $id);
    $checkStmt->execute();

    if ($checkStmt->rowCount() > 0) {
        $row = $checkStmt->fetch(PDO::FETCH_ASSOC);
        $now = new DateTime();
        $eventDate = new DateTime($row['start_datetime']);

        if ($eventDate < $now) {
            http_response_code(400);
            echo json_encode(array("message" => "Impossible de supprimer une inscription pour un événement déjà commencé ou terminé."));
            return;
        }
        $query = "DELETE FROM event_registrations WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("message" => "Inscription supprimée avec succès."));
        } else {
            http_response_code(503);
            echo json_encode(array("message" => "Impossible de supprimer l'inscription."));
        }
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Inscription non trouvée."));
    }
}
?>