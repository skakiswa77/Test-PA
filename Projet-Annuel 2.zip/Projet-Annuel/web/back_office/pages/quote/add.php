<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un Devis</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $stmt = $pdo->prepare("INSERT INTO quotes (user_id, company_id, amount, issue_date, expiration_date, 
                          status, description, created_at, updated_at) 
                          VALUES (:user_id, :company_id, :amount, :issue_date, :expiration_date, 
                          :status, :description, NOW(), NOW())");
        $stmt->execute([
            ':user_id' => $_POST['user_id'],
            ':company_id' => $_POST['company_id'],
            ':amount' => $_POST['amount'],
            ':issue_date' => $_POST['issue_date'],
            ':expiration_date' => $_POST['expiration_date'],
            ':status' => $_POST['status'],
            ':description' => $_POST['description']
        ]);
        header("Location: index.php");
        exit();
    }

    $stmt = $pdo->query("SELECT id, first_name, last_name FROM users ORDER BY last_name, first_name");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, name FROM companies ORDER BY name");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Ajouter un Devis</h2>
    <form method="POST">
        <label for="user_id">Client</label>
        <select name="user_id" id="user_id" required>
            <option value="">Sélectionner un client</option>
            <?php foreach ($users as $user): ?>
                <option value="<?php echo $user['id']; ?>">
                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="company_id">Entreprise</label>
        <select name="company_id" id="company_id" required>
            <option value="">Sélectionner une entreprise</option>
            <?php foreach ($companies as $company): ?>
                <option value="<?php echo $company['id']; ?>">
                    <?php echo htmlspecialchars($company['name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="amount">Montant</label>
        <input type="number" name="amount" id="amount" step="0.01" placeholder="0.00" required><br>

        <label for="issue_date">Date d'émission</label>
        <input type="date" name="issue_date" id="issue_date" value="<?php echo date('Y-m-d'); ?>" required><br>

        <label for="expiration_date">Date d'expiration</label>
        <input type="date" name="expiration_date" id="expiration_date"
            value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>" required><br>

        <label for="status">Statut</label>
        <select name="status" id="status" required>
            <option value="draft">Brouillon</option>
            <option value="sent">Envoyé</option>
            <option value="accepted">Accepté</option>
            <option value="rejected">Refusé</option>
            <option value="expired">Expiré</option>
        </select><br>

        <label for="description">Description</label>
        <textarea name="description" id="description" rows="4"
            placeholder="Description détaillée du devis..."></textarea><br>

        <button type="submit">Ajouter</button>
    </form>

</body>

</html>