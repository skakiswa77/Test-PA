<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'provider') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que prestataire.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Compte Rendu de Consultation";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setAlert('ID de rendez-vous invalide.', 'danger');
    redirect('appointments.php');
    exit;
}

$appointmentId = (int)$_GET['id'];

try {
    $appointment = $db->query(
        "SELECT a.*, u.first_name, u.last_name, u.email, c.name as company_name 
         FROM medical_appointments a
         JOIN users u ON a.user_id = u.id
         LEFT JOIN companies c ON u.company_id = c.id
         WHERE a.id = ? AND a.provider_id = ?
         LIMIT 1",
        [$appointmentId, $_SESSION['user_id']],
        true
    );

    if (!$appointment) {
        setAlert('Rendez-vous non trouvé ou vous n\'êtes pas autorisé à y accéder.', 'danger');
        redirect('appointments.php');
        exit;
    }

    $existingReport = $db->query(
        "SELECT * FROM provider_services 
         WHERE appointment_id = ? 
         LIMIT 1",
        [$appointmentId],
        true
    );

} catch (Exception $e) {
    setAlert('Erreur lors du chargement des données: ' . $e->getMessage(), 'danger');
    redirect('appointments.php');
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hours = $_POST['hours'] ?? '';
    $notes = $_POST['notes'] ?? '';
    
    if (empty($hours) || !is_numeric($hours) || $hours <= 0) {
        $errors[] = 'Veuillez saisir une durée valide pour la consultation.';
    }
    
    if (empty($notes)) {
        $errors[] = 'Veuillez saisir un compte rendu pour la consultation.';
    }
    
    if (empty($errors)) {
        try {

            $providerProfile = $db->query(
                "SELECT * FROM provider_profiles WHERE user_id = ? LIMIT 1",
                [$_SESSION['user_id']],
                true
            );
            
            if (!$providerProfile) {
                throw new Exception('Profil du prestataire non trouvé.');
            }
            
            $rate = $providerProfile['hourly_rate'];
            $totalAmount = $rate * (float)$hours;
            
            $serviceData = [
                'provider_id' => $_SESSION['user_id'],
                'appointment_id' => $appointmentId,
                'service_date' => date('Y-m-d', strtotime($appointment['appointment_datetime'])),
                'hours' => $hours,
                'rate' => $rate,
                'total_amount' => $totalAmount,
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $db->update(
                'medical_appointments',
                [
                    'status' => 'completed',
                    'notes' => $notes,
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'id = ?',
                [$appointmentId]
            );
            
            if ($existingReport) {
                $db->update(
                    'provider_services',
                    $serviceData,
                    'id = ?',
                    [$existingReport['id']]
                );
            } else {
                $db->insert('provider_services', $serviceData);
            }
            
            $db->insert('action_logs', [
                'user_id' => $_SESSION['user_id'],
                'action' => 'create_appointment_report',
                'description' => "Création du compte rendu pour le rendez-vous #$appointmentId",
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $success = true;
            setAlert('Le compte rendu a été enregistré avec succès.', 'success');
         
            $appointment = $db->query(
                "SELECT a.*, u.first_name, u.last_name FROM medical_appointments a
                 JOIN users u ON a.user_id = u.id
                 WHERE a.id = ? LIMIT 1",
                [$appointmentId],
                true
            );
            
            $existingReport = $db->query(
                "SELECT * FROM provider_services WHERE appointment_id = ? LIMIT 1",
                [$appointmentId],
                true
            );
            
        } catch (Exception $e) {
            $errors[] = 'Erreur lors de l\'enregistrement du compte rendu: ' . $e->getMessage();
        }
    }
}


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="h3 mb-0">Compte Rendu de Consultation</h1>
            <p class="text-muted">
                Patient: <?= htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']) ?> |
                Date: <?= date('d/m/Y', strtotime($appointment['appointment_datetime'])) ?>
            </p>
        </div>
        <div class="col-md-4 text-end">
            <a href="appointment_details.php?id=<?= $appointmentId ?>" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i> Retour aux détails
            </a>
        </div>
    </div>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            Le compte rendu a été enregistré avec succès.
        </div>
    <?php endif; ?>

    <div class="card shadow">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                <?= $existingReport ? 'Modifier le compte rendu' : 'Créer un compte rendu' ?>
            </h6>
        </div>
        <div class="card-body">
            <form method="post" action="appointment_report.php?id=<?= $appointmentId ?>">
                <div class="mb-3">
                    <label for="hours" class="form-label">Durée de la consultation (en heures)</label>
                    <input type="number" step="0.25" min="0.25" max="8" class="form-control" id="hours" name="hours" 
                           value="<?= $existingReport ? $existingReport['hours'] : '1' ?>" required>
                    <div class="form-text">Exemple: 1 pour 1 heure, 0.5 pour 30 minutes, 1.5 pour 1h30, etc.</div>
                </div>
                
                <div class="mb-3">
                    <label for="notes" class="form-label">Compte rendu de la consultation</label>
                    <textarea class="form-control" id="notes" name="notes" rows="10" required><?= htmlspecialchars($appointment['notes'] ?? '') ?></textarea>
                    <div class="form-text">
                        Décrivez ici le déroulement de la consultation, les observations, recommandations et suivi.
                        <strong>Note:</strong> Ce compte rendu sera accessible par l'employé et l'administrateur de l'entreprise.
                    </div>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Enregistrer le compte rendu
                    </button>
                </div>
            </form>
            
            <?php if ($existingReport): ?>
            <hr class="my-4">
            <div class="card bg-light">
                <div class="card-body">
                    <h5 class="card-title">Résumé du service</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Date du service:</strong> <?= date('d/m/Y', strtotime($existingReport['service_date'])) ?></p>
                            <p class="mb-1"><strong>Durée facturée:</strong> <?= $existingReport['hours'] ?> heure(s)</p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-1"><strong>Tarif horaire:</strong> <?= number_format($existingReport['rate'], 2, ',', ' ') ?> €</p>
                            <p class="mb-1"><strong>Montant total:</strong> <?= number_format($existingReport['total_amount'], 2, ',', ' ') ?> €</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
include_once __DIR__ . '/../includes/footer.php';
?>