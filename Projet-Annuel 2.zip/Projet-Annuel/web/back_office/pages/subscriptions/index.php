<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Abonnements</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    $stmt = $pdo->query("SELECT s.*, c.name as company_name, sp.name as plan_name FROM subscriptions s 
                    LEFT JOIN companies c ON s.company_id = c.id
                    LEFT JOIN subscription_plans sp ON s.plan_id = sp.id
                    WHERE s.is_active = 1
                    ORDER BY s.start_date DESC");
    $subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Gestion des Abonnements</h2>
    <a href="add.php">Ajouter un abonnement</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Entreprise</th>
            <th>Plan</th>
            <th>Date de début</th>
            <th>Date de fin</th>
            <th>Statut</th>
            <th>Date de création</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($subscriptions as $subscription): ?>
            <tr>
                <td><?php echo $subscription['id']; ?></td>
                <td><?php echo htmlspecialchars($subscription['company_name']); ?></td>
                <td><?php echo htmlspecialchars($subscription['plan_name']); ?></td>
                <td><?php echo date('d/m/Y', strtotime($subscription['start_date'])); ?></td>
                <td><?php echo date('d/m/Y', strtotime($subscription['end_date'])); ?></td>
                <td><?php echo $subscription['is_active'] ? 'Actif' : 'Inactif'; ?></td>
                <td><?php echo date('d/m/Y', strtotime($subscription['created_at'])); ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $subscription['id']; ?>">Modifier</a>
                    <a href="deactivate.php?id=<?php echo $subscription['id']; ?>"
                        onclick="return confirm('Voulez-vous vraiment désactiver cet abonnement?')">Désactiver</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

</body>

</html>