<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id']) || !isset($_GET['action'])) {
    setAlert('Paramètres invalides.', 'danger');
    redirect('appointments.php');
    exit;
}

$appointmentId = (int)$_GET['id'];
$action = $_GET['action'];
$employee_id = $_SESSION['user_id'];

$validActions = ['cancel', 'reschedule', 'confirm_attendance'];
if (!in_array($action, $validActions)) {
    setAlert('Action non valide.', 'danger');
    redirect('appointments.php');
    exit;
}

$db = Database::getInstance();

try {
    $appointment = $db->query(
        "SELECT * FROM medical_appointments 
         WHERE id = ? AND user_id = ?
         LIMIT 1",
        [$appointmentId, $employee_id],
        true
    );

    if (!$appointment) {
        setAlert('Rendez-vous non trouvé ou vous n\'êtes pas autorisé à le modifier.', 'danger');
        redirect('appointments.php');
        exit;
    }

    switch ($action) {
        case 'cancel':
            if ($appointment['status'] == 'pending' || $appointment['status'] == 'confirmed') {
                $db->update(
                    'medical_appointments',
                    ['status' => 'cancelled', 'updated_at' => date('Y-m-d H:i:s')],
                    'id = ?',
                    [$appointmentId]
                );
                
                $db->insert('action_logs', [
                    'user_id' => $employee_id,
                    'action' => 'cancel_appointment',
                    'description' => "Annulation du rendez-vous #$appointmentId par l'employé",
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                setAlert('Le rendez-vous a été annulé avec succès.', 'success');
            } else {
                setAlert('Ce rendez-vous ne peut pas être annulé.', 'warning');
            }
            break;
            
        case 'reschedule':
            if ($appointment['status'] == 'pending' || $appointment['status'] == 'confirmed') {
                redirect("reschedule_appointment.php?id=$appointmentId");
                exit;
            } else {
                setAlert('Ce rendez-vous ne peut pas être reprogrammé.', 'warning');
            }
            break;
            
        case 'confirm_attendance':
            if ($appointment['status'] == 'confirmed') {
                $currentNotes = $appointment['notes'] ?? '';
                $updatedNotes = "[" . date('d/m/Y H:i') . "] L'employé a confirmé sa présence au rendez-vous.\n\n" . $currentNotes;
                
                $db->update(
                    'medical_appointments',
                    ['notes' => $updatedNotes, 'updated_at' => date('Y-m-d H:i:s')],
                    'id = ?',
                    [$appointmentId]
                );
                
                $db->insert('action_logs', [
                    'user_id' => $employee_id,
                    'action' => 'confirm_attendance',
                    'description' => "Confirmation de présence au rendez-vous #$appointmentId",
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
                    'created_at' => date('Y-m-d H:i:s')
                ]);
                
                setAlert('Votre présence au rendez-vous a été confirmée.', 'success');
            } else {
                setAlert('Vous ne pouvez pas confirmer votre présence pour ce rendez-vous.', 'warning');
            }
            break;
    }

    if (isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], 'appointment_detail.php') !== false) {
        redirect("appointment_detail.php?id=$appointmentId");
    } else {
        redirect('appointments.php');
    }

} catch (Exception $e) {
    setAlert('Erreur lors de la modification du rendez-vous: ' . $e->getMessage(), 'danger');
    redirect('appointments.php');
    exit;
}
?>