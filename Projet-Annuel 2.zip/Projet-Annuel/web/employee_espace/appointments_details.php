<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Détails du Rendez-vous";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setAlert('ID de rendez-vous invalide.', 'danger');
    redirect('appointments.php');
    exit;
}

$appointmentId = (int)$_GET['id'];
$employee_id = $_SESSION['user_id'];

try {
    $appointment = $db->query(
        "SELECT ma.*, u.first_name, u.last_name, ps.name as specialization,
                pp.hourly_rate
         FROM medical_appointments ma
         JOIN provider_profiles pp ON ma.provider_id = pp.id
         JOIN users u ON pp.user_id = u.id
         JOIN provider_specializations ps ON pp.specialization_id = ps.id
         WHERE ma.id = ? AND ma.user_id = ?
         LIMIT 1",
        [$appointmentId, $employee_id],
        true
    );

    if (!$appointment) {
        setAlert('Rendez-vous non trouvé ou vous n\'êtes pas autorisé à y accéder.', 'danger');
        redirect('appointments.php');
        exit;
    }
    $service = null;
    if ($appointment['status'] === 'completed') {
        $service = $db->query(
            "SELECT * FROM provider_services 
             WHERE appointment_id = ? 
             LIMIT 1",
            [$appointmentId],
            true
        );
    }

} catch (Exception $e) {
    setAlert('Erreur lors du chargement des détails du rendez-vous: ' . $e->getMessage(), 'danger');
    redirect('appointments.php');
    exit;
}


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Détails du Rendez-vous</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="appointments.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Retour à mes rendez-vous
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Informations sur le rendez-vous</h4>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p class="mb-1 text-muted">Date et heure</p>
                            <p class="mb-3 fw-bold">
                                <?= date('d/m/Y à H:i', strtotime($appointment['appointment_datetime'])) ?>
                            </p>

                            <p class="mb-1 text-muted">Statut</p>
                            <p class="mb-3">
                                <?php
                                switch ($appointment['status']) {
                                    case 'pending':
                                        echo '<span class="badge badge-warning">En attente</span>';
                                        break;
                                    case 'confirmed':
                                        echo '<span class="badge badge-success">Confirmé</span>';
                                        break;
                                    case 'cancelled':
                                        echo '<span class="badge badge-danger">Annulé</span>';
                                        break;
                                    case 'completed':
                                        echo '<span class="badge badge-info">Terminé</span>';
                                        break;
                                }
                                ?>
                            </p>

                            <p class="mb-1 text-muted">Type de rendez-vous</p>
                            <p class="mb-3">
                                <?= $appointment['is_virtual'] ? 'Visioconférence' : 'Présentiel' ?>
                            </p>
                        </div>
                        
                        <div class="col-md-6">
                            <p class="mb-1 text-muted">Prestataire</p>
                            <p class="mb-3 fw-bold">
                                <?= htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']) ?>
                            </p>

                            <p class="mb-1 text-muted">Spécialité</p>
                            <p class="mb-3">
                                <?= htmlspecialchars($appointment['specialization']) ?>
                            </p>

                            <?php if ($appointment['notes'] && $appointment['status'] === 'completed'): ?>
                                <p class="mb-1 text-muted">Compte rendu de la consultation</p>
                                <div class="mb-3 p-3 bg-light rounded">
                                    <?= nl2br(htmlspecialchars($appointment['notes'])) ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($service && $appointment['status'] === 'completed'): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Détails de la prestation</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-1 text-muted">Date du service</p>
                            <p class="mb-3">
                                <?= date('d/m/Y', strtotime($service['service_date'])) ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p class="mb-1 text-muted">Durée</p>
                            <p class="mb-3">
                                <?= $service['hours'] ?> heure(s)
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Actions</h4>
                </div>
                <div class="card-body">
                    <?php if ($appointment['status'] === 'pending' || $appointment['status'] === 'confirmed'): ?>
                        <a href="cancel_appointment.php?id=<?= $appointment['id'] ?>" class="btn btn-danger btn-block mb-3"
                           onclick="return confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous?')">
                            <i class="fas fa-times"></i> Annuler ce rendez-vous
                        </a>
                    <?php endif; ?>

                    <?php if ($appointment['status'] === 'completed' && !isset($_GET['feedback_submitted'])): ?>
                        <a href="appointment_feedback.php?id=<?= $appointment['id'] ?>" class="btn btn-primary btn-block mb-3">
                            <i class="fas fa-comment"></i> Donner mon avis
                        </a>
                    <?php endif; ?>

                    <?php if ($appointment['is_virtual'] && $appointment['status'] === 'confirmed'): ?>
                        <div class="alert alert-info">
                            <p class="mb-2"><strong>Instructions pour la visioconférence:</strong></p>
                            <p>Le lien de connexion vous sera envoyé par email 15 minutes avant le début de la consultation.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($appointment['status'] === 'confirmed'): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Rappel</h4>
                </div>
                <div class="card-body">
                    <p>Votre rendez-vous est confirmé pour le:</p>
                    <p class="h5 mb-3"><?= date('d/m/Y à H:i', strtotime($appointment['appointment_datetime'])) ?></p>
                    
                    <?php
                    $now = new DateTime();
                    $appointmentDate = new DateTime($appointment['appointment_datetime']);
                    $interval = $now->diff($appointmentDate);
                    $days = $interval->days;
                    $hours = $interval->h + ($interval->days * 24);
                    ?>
                    
                    <?php if ($now < $appointmentDate): ?>
                        <p class="alert alert-info">
                            <?php if ($days > 0): ?>
                                Votre rendez-vous est dans <?= $days ?> jour(s).
                            <?php else: ?>
                                Votre rendez-vous est dans <?= $hours ?> heure(s).
                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>