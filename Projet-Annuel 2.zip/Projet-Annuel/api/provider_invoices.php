<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once 'utils/database.php';
$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

$id = isset($_GET['id']) ? $_GET['id'] : null;

switch($method) {
    case 'GET':
        if($id) {
            getInvoice($db, $id);
        } else {
            getInvoices($db);
        }
        break;
    case 'POST':
        generateInvoice($db);
        break;
    case 'PUT':
        if($id) {
            updateInvoiceStatus($db, $id);
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "ID facture manquant."));
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("message" => "Méthode non autorisée."));
        break;
}

function getInvoices($db) {

    $page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? $_GET['limit'] : 10;
    $start = ($page - 1) * $limit;
    

    $where = "WHERE 1";
    $params = array();
    
    if(isset($_GET['provider_id']) && !empty($_GET['provider_id'])) {
        $where .= " AND pi.provider_id = :provider_id";
        $params[':provider_id'] = $_GET['provider_id'];
    }
    
    if(isset($_GET['company_id']) && !empty($_GET['company_id'])) {
        $where .= " AND pi.company_id = :company_id";
        $params[':company_id'] = $_GET['company_id'];
    }
    
    if(isset($_GET['status']) && !empty($_GET['status'])) {
        $where .= " AND pi.status = :status";
        $params[':status'] = $_GET['status'];
    }
    
    if(isset($_GET['month']) && !empty($_GET['month'])) {
        $where .= " AND pi.month = :month";
        $params[':month'] = $_GET['month'];
    }
    
    if(isset($_GET['year']) && !empty($_GET['year'])) {
        $where .= " AND pi.year = :year";
        $params[':year'] = $_GET['year'];
    }
    
    $query = "SELECT pi.*, 
              pp.id as provider_profile_id, u.first_name as provider_first_name, u.last_name as provider_last_name,
              c.name as company_name
              FROM provider_invoices pi 
              JOIN provider_profiles pp ON pi.provider_id = pp.id 
              JOIN users u ON pp.user_id = u.id 
              JOIN companies c ON pi.company_id = c.id 
              $where 
              ORDER BY pi.issue_date DESC 
              LIMIT :start, :limit";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':start', $start, PDO::PARAM_INT);
    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
    
    foreach($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->execute();
    
    $countQuery = "SELECT COUNT(*) as total 
                  FROM provider_invoices pi 
                  JOIN provider_profiles pp ON pi.provider_id = pp.id 
                  JOIN users u ON pp.user_id = u.id 
                  JOIN companies c ON pi.company_id = c.id 
                  $where";
    $countStmt = $db->prepare($countQuery);
    
    foreach($params as $key => $value) {
        $countStmt->bindValue($key, $value);
    }
    
    $countStmt->execute();
    $row = $countStmt->fetch(PDO::FETCH_ASSOC);
    $totalInvoices = $row['total'];
    
    if($stmt->rowCount() > 0) {
        $invoices_arr = array();
        $invoices_arr["invoices"] = array();
        $invoices_arr["pagination"] = array(
            "total" => $totalInvoices,
            "pages" => ceil($totalInvoices / $limit),
            "current_page" => (int)$page,
            "per_page" => (int)$limit
        );
        
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $invoice_item = array(
                "id" => $row['id'],
                "invoice_number" => $row['invoice_number'],
                "provider" => array(
                    "id" => $row['provider_profile_id'],
                    "name" => $row['provider_first_name'] . ' ' . $row['provider_last_name']
                ),
                "company" => array(
                    "id" => $row['company_id'],
                    "name" => $row['company_name']
                ),
                "month" => $row['month'],
                "year" => $row['year'],
                "amount" => $row['amount'],
                "issue_date" => $row['issue_date'],
                "status" => $row['status'],
                "pdf_path" => $row['pdf_path']
            );
            
            array_push($invoices_arr["invoices"], $invoice_item);
        }
        
        http_response_code(200);
        echo json_encode($invoices_arr);
    } else {
        http_response_code(200);
        echo json_encode(array("message" => "Aucune facture trouvée.", "invoices" => array()));
    }
}

function getInvoice($db, $id) {
    $query = "SELECT pi.*, 
              pp.id as provider_profile_id, u.id as user_id, u.first_name, u.last_name, u.email,
              c.name as company_name, c.address as company_address
              FROM provider_invoices pi 
              JOIN provider_profiles pp ON pi.provider_id = pp.id 
              JOIN users u ON pp.user_id = u.id 
              JOIN companies c ON pi.company_id = c.id 
              WHERE pi.id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $invoice = array(
            "id" => $row['id'],
            "invoice_number" => $row['invoice_number'],
            "provider" => array(
                "id" => $row['provider_profile_id'],
                "user_id" => $row['user_id'],
                "name" => $row['first_name'] . ' ' . $row['last_name'],
                "email" => $row['email']
            ),
            "company" => array(
                "id" => $row['company_id'],
                "name" => $row['company_name'],
                "address" => $row['company_address']
            ),
            "month" => $row['month'],
            "year" => $row['year'],
            "amount" => $row['amount'],
            "issue_date" => $row['issue_date'],
            "status" => $row['status'],
            "pdf_path" => $row['pdf_path']
        );
        
        $servicesQuery = "SELECT ps.*, 
                         CASE 
                             WHEN ps.event_id IS NOT NULL THEN e.title 
                             WHEN ps.appointment_id IS NOT NULL THEN 'Rendez-vous médical' 
                             ELSE NULL 
                         END as service_name
                         FROM provider_services ps 
                         LEFT JOIN events e ON ps.event_id = e.id 
                         WHERE ps.provider_invoice_id = :invoice_id 
                         ORDER BY ps.service_date";
        
        $servicesStmt = $db->prepare($servicesQuery);
        $servicesStmt->bindParam(':invoice_id', $id);
        $servicesStmt->execute();
        
        $invoice["services"] = array();
        
        while($serviceRow = $servicesStmt->fetch(PDO::FETCH_ASSOC)) {
            $service = array(
                "id" => $serviceRow['id'],
                "name" => $serviceRow['service_name'],
                "service_date" => $serviceRow['service_date'],
                "hours" => $serviceRow['hours'],
                "rate" => $serviceRow['rate'],
                "total_amount" => $serviceRow['total_amount']
            );
            
            array_push($invoice["services"], $service);
        }
        
        http_response_code(200);
        echo json_encode($invoice);
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "Facture non trouvée."));
    }
}

function generateInvoice($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if(
        !empty($data->provider_id) && 
        !empty($data->company_id) && 
        !empty($data->month) && 
        !empty($data->year)
    ) {
        $providerQuery = "SELECT id FROM provider_profiles WHERE id = :id";
        $providerStmt = $db->prepare($providerQuery);
        $providerStmt->bindParam(':id', $data->provider_id);
        $providerStmt->execute();
        
        if($providerStmt->rowCount() == 0) {
            http_response_code(404);
            echo json_encode(array("message" => "Prestataire non trouvé."));
            return;
        }
        
        $companyQuery = "SELECT id FROM companies WHERE id = :id";
        $companyStmt = $db->prepare($companyQuery);
        $companyStmt->bindParam(':id', $data->company_id);
        $companyStmt->execute();
        
        if($companyStmt->rowCount() == 0) {
            http_response_code(404);
            echo json_encode(array("message" => "Société non trouvée."));
            return;
        }
        
        $checkQuery = "SELECT id FROM provider_invoices 
                      WHERE provider_id = :provider_id AND month = :month AND year = :year";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindParam(':provider_id', $data->provider_id);
        $checkStmt->bindParam(':month', $data->month);
        $checkStmt->bindParam(':year', $data->year);
        $checkStmt->execute();
        
        if($checkStmt->rowCount() > 0) {
            http_response_code(400);
            echo json_encode(array("message" => "Une facture existe déjà pour ce prestataire, ce mois et cette année."));
            return;
        }
        
        $servicesQuery = "SELECT * FROM provider_services 
                         WHERE provider_id = :provider_id 
                         AND MONTH(service_date) = :month 
                         AND YEAR(service_date) = :year 
                         AND provider_invoice_id IS NULL";
        $servicesStmt = $db->prepare($servicesQuery);
        $servicesStmt->bindParam(':provider_id', $data->provider_id);
        $servicesStmt->bindParam(':month', $data->month);
        $servicesStmt->bindParam(':year', $data->year);
        $servicesStmt->execute();
        
        if($servicesStmt->rowCount() == 0) {
            http_response_code(400);
            echo json_encode(array("message" => "Aucun service à facturer pour ce mois et cette année."));
            return;
        }
        

        $totalAmount = 0;
        $services = array();
        
        while($serviceRow = $servicesStmt->fetch(PDO::FETCH_ASSOC)) {
            $totalAmount += $serviceRow['total_amount'];
            $services[] = $serviceRow;
        }
        

        $invoiceNumber = 'BC-' . $data->year . sprintf('%02d', $data->month) . '-' . uniqid();
        

        $query = "INSERT INTO provider_invoices 
                 (provider_id, company_id, invoice_number, month, year, amount, issue_date, status) 
                 VALUES 
                 (:provider_id, :company_id, :invoice_number, :month, :year, :amount, CURDATE(), 'pending')";
        
        $stmt = $db->prepare($query);
        

        $stmt->bindParam(':provider_id', $data->provider_id);
        $stmt->bindParam(':company_id', $data->company_id);
        $stmt->bindParam(':invoice_number', $invoiceNumber);
        $stmt->bindParam(':month', $data->month);
        $stmt->bindParam(':year', $data->year);
        $stmt->bindParam(':amount', $totalAmount);
        

        $db->beginTransaction();
        
        try {

            if($stmt->execute()) {
                $invoiceId = $db->lastInsertId();
                
                foreach($services as $service) {
                    $updateServiceQuery = "UPDATE provider_services 
                                         SET provider_invoice_id = :invoice_id 
                                         WHERE id = :service_id";
                    $updateServiceStmt = $db->prepare($updateServiceQuery);
                    $updateServiceStmt->bindParam(':invoice_id', $invoiceId);
                    $updateServiceStmt->bindParam(':service_id', $service['id']);
                    $updateServiceStmt->execute();
                }
                
                $db->commit();
                
                http_response_code(201);
                echo json_encode(array(
                    "message" => "Facture générée avec succès.",
                    "id" => $invoiceId,
                    "invoice_number" => $invoiceNumber,
                    "amount" => $totalAmount
                ));
            } else {
                throw new Exception("Erreur lors de la création de la facture.");
            }
        } catch(Exception $e) {
            $db->rollBack();
            
            http_response_code(503);
            echo json_encode(array(
                "message" => "Impossible de générer la facture.",
                "error" => $e->getMessage()
            ));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Données incomplètes."));
    }
}

function updateInvoiceStatus($db, $id) {
    $data = json_decode(file_get_contents("php://input"));
    
    if(!empty($data->status)) {
        $checkQuery = "SELECT id FROM provider_invoices WHERE id = :id";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindParam(':id', $id);
        $checkStmt->execute();
        
        if($checkStmt->rowCount() > 0) {
            $validStatuses = array('pending', 'paid', 'cancelled');
            
            if(!in_array($data->status, $validStatuses)) {
                http_response_code(400);
                echo json_encode(array("message" => "Statut non valide."));
                return;
            }
            
            $query = "UPDATE provider_invoices SET status = :status";
            
            if($data->status == 'paid') {
                $query .= ", date_paiement = NOW()";
            }
            
            $query .= " WHERE id = :id";
            
            $stmt = $db->prepare($query);
            $stmt->bindParam(':status', $data->status);
            $stmt->bindParam(':id', $id);
            
            if($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("message" => "Statut de la facture mis à jour avec succès."));
            } else {
                http_response_code(503);
                echo json_encode(array("message" => "Impossible de mettre à jour le statut de la facture."));
            }
        } else {
            http_response_code(404);
            echo json_encode(array("message" => "Facture non trouvée."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Statut manquant."));
    }
}
?>