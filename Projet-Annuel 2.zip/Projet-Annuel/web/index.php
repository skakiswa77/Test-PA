<?php
session_start();

require_once 'config/config.php';
require_once 'utils/database.php';
require_once 'utils/helpers.php';


$page = isset($_GET['page']) ? $_GET['page'] : 'home';

include_once 'includes/header.php';


switch ($page) {
    case 'home':
        include_once 'pages/home.php';
        break;
    case 'login':
        include_once 'pages/login.php';
        break;
    case 'register':
        include_once 'pages/register.php';
        break;
    case 'services':
        include_once 'pages/services.php';
        break;
    case 'about':
        include_once 'pages/about.php';
        break;
    case 'contact':
        include_once 'pages/contact.php';
        break;
    case 'quote':
        include_once 'pages/quote.php';
        break;
    case 'terms':
        include_once 'pages/terms.php';
        break;
    case 'privacy':
        include_once 'pages/privacy.php';
        break;
    case 'faq':
        include_once 'pages/faq.php';
        break;

    case 'forgot_password':
        include 'pages/forgot_password.php';
        break;

    case 'reset_password':
        include 'pages/reset_password.php';
        break;

    case 'appointments':
        include 'provider_espace/appointments.php';
        include 'employee_espace/appointments.php';
        break;

    case 'events':
        include 'provider_espace/events.php';
        include 'employee_espace/events.php';
        break;

    case 'messages':
        include 'provider_espace/messages.php';
        include 'employee_espace/messages.php';
        include 'client_espace/messages.php';
        break;

    case 'profile':
        include 'provider_espace/profile.php';
        include 'employee_espace/profile.php';
        include 'client_espace/profile.php';
        break;

    case 'invoices':
        include 'provider_espace/invoices.php';
        break;

    case 'verification':
        include 'provider_espace/verification.php';
        break;

    case 'nfc-card':
        include 'employee_espace/nfc-card.php';
        break;

        case 'subscriptions':
        include 'client_espace/subscriptions.php';
        include 'employee_espace/subscriptions.php';
        break;

        case 'reports':
        include 'client_espace/reports.php';
        break;

        case 'generate_quote':
        include 'client_espace/generate_quote.php';
        break;


        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'newsletter_subscribe') {
            include 'actions/newsletter_subscribe.php';
            exit;
        }
    case 'payment':

        $plan = isset($_GET['plan']) ? $_GET['plan'] : '';
        $employees = isset($_GET['employees']) ? (int) $_GET['employees'] : 0;
        include_once 'pages/payment.php';
        break;

    case 'dashboard':
        function checkUserSession()
        {
            if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
                header("Location: index.php?page=login");
                exit;
            }
            return true;
        }

        
        if ($_SESSION['user_role'] === 'company_admin') {
            include_once 'client_espace/dashboard.php';
        } elseif ($_SESSION['user_role'] === 'employee') {
            include_once 'employee_espace/dashboard.php';
        } elseif ($_SESSION['user_role'] === 'provider') {
            include_once 'provider_espace/dashboard.php';
        }
        break;

    default:
        include_once 'pages/404.php';
        break;
}

include_once 'includes/footer.php';
?>

