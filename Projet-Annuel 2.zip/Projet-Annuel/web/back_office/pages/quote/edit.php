<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Devis</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    $id = $_GET['id'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $stmt = $pdo->prepare("UPDATE quotes SET 
                          user_id = :user_id,
                          company_id = :company_id,
                          amount = :amount, 
                          issue_date = :issue_date,
                          expiration_date = :expiration_date,
                          status = :status,
                          description = :description,
                          updated_at = NOW()
                          WHERE id = :id");
        $stmt->execute([
            ':user_id' => $_POST['user_id'],
            ':company_id' => $_POST['company_id'],
            ':amount' => $_POST['amount'],
            ':issue_date' => $_POST['issue_date'],
            ':expiration_date' => $_POST['expiration_date'],
            ':status' => $_POST['status'],
            ':description' => $_POST['description'],
            ':id' => $id
        ]);
        header("Location: index.php");
        exit();
    }

    $stmt = $pdo->prepare("SELECT * FROM quotes WHERE id = ?");
    $stmt->execute([$id]);
    $quote = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, first_name, last_name FROM users ORDER BY last_name, first_name");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, name FROM companies ORDER BY name");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Modifier un Devis</h2>
    <form method="POST">
        <label for="user_id">Client</label>
        <select name="user_id" id="user_id" required>
            <option value="">Sélectionner un client</option>
            <?php foreach ($users as $user): ?>
                <option value="<?php echo $user['id']; ?>" <?php if ($quote['user_id'] == $user['id'])
                       echo 'selected'; ?>>
                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="company_id">Entreprise</label>
        <select name="company_id" id="company_id" required>
            <option value="">Sélectionner une entreprise</option>
            <?php foreach ($companies as $company): ?>
                <option value="<?php echo $company['id']; ?>" <?php if ($quote['company_id'] == $company['id'])
                       echo 'selected'; ?>>
                    <?php echo htmlspecialchars($company['name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="amount">Montant</label>
        <input type="number" name="amount" id="amount" step="0.01" value="<?php echo $quote['amount']; ?>" required><br>

        <label for="issue_date">Date d'émission</label>
        <input type="date" name="issue_date" id="issue_date" value="<?php echo $quote['issue_date']; ?>" required><br>

        <label for="expiration_date">Date d'expiration</label>
        <input type="date" name="expiration_date" id="expiration_date" value="<?php echo $quote['expiration_date']; ?>"
            required><br>

        <label for="status">Statut</label>
        <select name="status" id="status" required>
            <option value="draft" <?php if ($quote['status'] == 'draft')
                echo 'selected'; ?>>Brouillon</option>
            <option value="sent" <?php if ($quote['status'] == 'sent')
                echo 'selected'; ?>>Envoyé</option>
            <option value="accepted" <?php if ($quote['status'] == 'accepted')
                echo 'selected'; ?>>Accepté</option>
            <option value="rejected" <?php if ($quote['status'] == 'rejected')
                echo 'selected'; ?>>Refusé</option>
            <option value="expired" <?php if ($quote['status'] == 'expired')
                echo 'selected'; ?>>Expiré</option>
        </select><br>

        <label for="description">Description</label>
        <textarea name="description" id="description"
            rows="4"><?php $description = htmlspecialchars($quote['description'] ?? ''); ?></textarea><br>

        <button type="submit">Mettre à jour</button>
    </form>

</body>

</html>