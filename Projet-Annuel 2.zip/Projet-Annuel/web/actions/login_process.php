<?php
session_start();
require_once __DIR__ . '/../utils/database.php';

$db = Database::getInstance();

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$role = $_POST['role'] ?? '';
$remember = isset($_POST['remember']) ? true : false;

if (empty($email) || empty($password) || empty($role)) {
    $_SESSION['login_form_data'] = [
        'email' => $email,
        'role' => $role
    ];
    header('Location: ../index.php?page=login&error=empty_fields');
    exit;
}

$user = $db->query(
    "SELECT * FROM users WHERE email = ? AND role = ?",
    [$email, $role],
    true
);

if ($user && password_verify($password, $user['password'])) {

    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['user_company_id'] = $user['company_id'];


    if ($remember) {
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+30 days'));
        
        $db->insert('remember_tokens', [
            'user_id' => $user['id'],
            'token' => $token,
            'expires_at' => $expires_at,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
    
        setcookie('remember_token', $token, time() + (86400 * 30), '/');
    }

    $db->insert('action_logs', [
        'user_id' => $user['id'],
        'action' => 'login',
        'description' => 'Connexion au système',
        'ip_address' => $_SERVER['REMOTE_ADDR'],
        'user_agent' => $_SERVER['HTTP_USER_AGENT'],
        'created_at' => date('Y-m-d H:i:s')
    ]);

 
switch ($role) {
    case 'employee':
        $redirectUrl = '/web/employee_espace/dashboard.php';
        break;
    case 'company_admin':
        $redirectUrl = '/web/client_espace/dashboard.php';
        break;
    case 'provider':
        $redirectUrl = '/web/provider_espace/dashboard.php';
        break;
    case 'admin':
        $redirectUrl = '../back_office/pages/dashboard.php';
        break;
    default:
        $redirectUrl = '../index.php';
        break;
}
    
    header("Location: $redirectUrl");
    exit;
} else {

    $_SESSION['login_form_data'] = [
        'email' => $email,
        'role' => $role
    ];
    header('Location: ../index.php?page=login&error=invalid_credentials');
    exit;
}
?>