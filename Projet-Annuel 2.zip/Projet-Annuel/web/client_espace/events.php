<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'company_admin') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant qu\'administrateur d\'entreprise.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$admin_id = $_SESSION['user_id'];
$db = Database::getInstance();

$company_id = $db->query(
    "SELECT company_id FROM users WHERE id = ?",
    [$admin_id],
    true
)['company_id'];

if (!$company_id) {
    setAlert('Erreur: Vous n\'êtes pas associé à une entreprise.', 'danger');
    redirect(APP_URL . '/index.php?page=dashboard');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_event'])) {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $event_type_id = (int)$_POST['event_type_id'];
    $location = trim($_POST['location']);
    $is_virtual = isset($_POST['is_virtual']) ? 1 : 0;
    $max_participants = !empty($_POST['max_participants']) ? (int)$_POST['max_participants'] : null;
    $provider_id = !empty($_POST['provider_id']) ? (int)$_POST['provider_id'] : null;
    $start_date = $_POST['start_date'];
    $start_time = $_POST['start_time'];
    $end_date = $_POST['end_date'];
    $end_time = $_POST['end_time'];
    
    $start_datetime = $start_date . ' ' . $start_time;
    $end_datetime = $end_date . ' ' . $end_time;
    
    try {
        if (empty($title) || empty($description) || empty($event_type_id) || empty($start_datetime) || empty($end_datetime)) {
            throw new Exception("Veuillez remplir tous les champs obligatoires.");
        }
        
        if (strtotime($start_datetime) >= strtotime($end_datetime)) {
            throw new Exception("La date de fin doit être postérieure à la date de début.");
        }
        
        if (strtotime($start_datetime) <= time()) {
            throw new Exception("La date de début doit être dans le futur.");
        }
        
        $db->insert(
            'events',
            [
                'title' => $title,
                'description' => $description,
                'event_type_id' => $event_type_id,
                'location' => $location,
                'is_virtual' => $is_virtual,
                'max_participants' => $max_participants,
                'provider_id' => $provider_id,
                'start_datetime' => $start_datetime,
                'end_datetime' => $end_datetime,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]
        );
        
        $db->insert('action_logs', [
            'user_id' => $admin_id,
            'action' => 'create_event',
            'description' => "Création de l'événement: $title",
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        $success_message = "L'événement a été créé avec succès.";
    } catch (Exception $e) {
        $error_message = "Erreur lors de la création de l'événement: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_event'])) {
    $event_id = (int)$_POST['event_id'];
    
    try {
        $event = $db->query(
            "SELECT e.* FROM events e
            LEFT JOIN provider_profiles pp ON e.provider_id = pp.id
            LEFT JOIN users u ON pp.user_id = u.id
            WHERE e.id = ? AND (u.company_id = ? OR e.id IN (
                SELECT DISTINCT er.event_id FROM event_registrations er 
                JOIN users u ON er.user_id = u.id 
                WHERE u.company_id = ?
            ))",
            [$event_id, $company_id, $company_id],
            true
        );
        
        if (!$event) {
            throw new Exception("Événement non trouvé ou vous n'êtes pas autorisé à le modifier.");
        }
        
        $db->execute(
            "UPDATE event_registrations SET status = 'cancelled' WHERE event_id = ?",
            [$event_id]
        );
    
        $db->execute(
            "DELETE FROM events WHERE id = ?",
            [$event_id]
        );
        
        $db->insert('action_logs', [
            'user_id' => $admin_id,
            'action' => 'cancel_event',
            'description' => "Annulation de l'événement #$event_id",
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        $success_message = "L'événement a été annulé avec succès.";
    } catch (Exception $e) {
        $error_message = "Erreur lors de l'annulation de l'événement: " . $e->getMessage();
    }
}

$event_types = $db->query(
    "SELECT * FROM event_types ORDER BY name"
);

$providers = $db->query(
    "SELECT pp.id, u.first_name, u.last_name, ps.name as specialization
    FROM provider_profiles pp
    JOIN users u ON pp.user_id = u.id
    JOIN provider_specializations ps ON pp.specialization_id = ps.id
    WHERE pp.is_verified = 1
    ORDER BY u.last_name, u.first_name"
);

$upcoming_events = $db->query(
    "SELECT e.*, et.name as event_type, u.first_name, u.last_name,
           (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id) as registered_count,
           (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id AND er.status = 'confirmed') as confirmed_count,
           (SELECT COUNT(*) FROM event_registrations er 
            JOIN users u ON er.user_id = u.id 
            WHERE er.event_id = e.id AND u.company_id = ?) as company_registrations
    FROM events e
    JOIN event_types et ON e.event_type_id = et.id
    LEFT JOIN provider_profiles pp ON e.provider_id = pp.id
    LEFT JOIN users u ON pp.user_id = u.id
    WHERE e.start_datetime >= NOW()
    AND (u.company_id = ? OR EXISTS (
        SELECT 1 FROM event_registrations er 
        JOIN users u2 ON er.user_id = u2.id 
        WHERE er.event_id = e.id AND u2.company_id = ?
    ))
    ORDER BY e.start_datetime ASC",
    [$company_id, $company_id, $company_id]
);
$past_events = $db->query(
    "SELECT e.*, et.name as event_type, u.first_name, u.last_name,
           (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id) as registered_count,
           (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id AND er.status = 'attended') as attended_count,
           (SELECT COUNT(*) FROM event_registrations er 
            JOIN users u ON er.user_id = u.id 
            WHERE er.event_id = e.id AND u.company_id = ?) as company_registrations
    FROM events e
    JOIN event_types et ON e.event_type_id = et.id
    LEFT JOIN provider_profiles pp ON e.provider_id = pp.id
    LEFT JOIN users u ON pp.user_id = u.id
    WHERE e.start_datetime < NOW()
    AND (u.company_id = ? OR EXISTS (
        SELECT 1 FROM event_registrations er 
        JOIN users u2 ON er.user_id = u2.id 
        WHERE er.event_id = e.id AND u2.company_id = ?
    ))
    ORDER BY e.start_datetime DESC
    LIMIT 10",
    [$company_id, $company_id, $company_id]
);

$employees = $db->query(
    "SELECT COUNT(*) as total_employees FROM users WHERE company_id = ? AND role = 'employee' AND is_active = 1",
    [$company_id],
    true
)['total_employees'];


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>Gestion des événements</h4>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#createEventModal">
                        <i class="fas fa-plus"></i> Créer un événement
                    </button>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <div class="card bg-primary text-white">
                                <div class="card-body text-center">
                                    <h5 class="card-title">Événements à venir</h5>
                                    <h2 class="display-4"><?php echo count($upcoming_events); ?></h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-success text-white">
                                <div class="card-body text-center">
                                    <h5 class="card-title">Participations employés</h5>
                                    <h2 class="display-4">
                                        <?php 
                                        $total_company_registrations = array_sum(array_column($upcoming_events, 'company_registrations'));
                                        echo $total_company_registrations; 
                                        ?>
                                    </h2>
                                    <p class="mb-0">sur <?php echo $employees; ?> employés</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-info text-white">
                                <div class="card-body text-center">
                                    <h5 class="card-title">Taux de participation</h5>
                                    <h2 class="display-4">
                                        <?php 
                                        $participation_rate = $employees > 0 ? round(($total_company_registrations / $employees) * 100) : 0;
                                        echo $participation_rate . '%'; 
                                        ?>
                                    </h2>
                                </div>
                            </div>
                        </div>
                    </div>

                    <h5 class="mb-3">Événements à venir</h5>
                    <?php if (empty($upcoming_events)): ?>
                        <div class="alert alert-info">Aucun événement à venir pour le moment.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped" id="upcomingEventsTable">
                                <thead>
                                    <tr>
                                        <th>Titre</th>
                                        <th>Type</th>
                                        <th>Date</th>
                                        <th>Lieu</th>
                                        <th>Animateur</th>
                                        <th>Inscriptions</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($upcoming_events as $event): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($event['title']); ?></td>
                                            <td><?php echo htmlspecialchars($event['event_type']); ?></td>
                                            <td>
                                                <?php 
                                                echo date('d/m/Y H:i', strtotime($event['start_datetime']));
                                                if (date('Y-m-d', strtotime($event['start_datetime'])) === date('Y-m-d', strtotime($event['end_datetime']))) {
                                                    echo ' - ' . date('H:i', strtotime($event['end_datetime']));
                                                } else {
                                                    echo '<br>au ' . date('d/m/Y H:i', strtotime($event['end_datetime']));
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo $event['is_virtual'] ? 'Événement virtuel' : htmlspecialchars($event['location']); ?></td>
                                            <td><?php echo $event['first_name'] ? htmlspecialchars($event['first_name'] . ' ' . $event['last_name']) : 'Non spécifié'; ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="mr-2"><?php echo $event['confirmed_count']; ?> / <?php echo $event['max_participants'] ?: '∞'; ?></div>
                                                    <?php if ($event['max_participants']): ?>
                                                        <div class="progress flex-grow-1" style="height: 5px;">
                                                            <div class="progress-bar" role="progressbar" style="width: <?php echo ($event['max_participants'] > 0) ? (($event['registered_count'] / $event['max_participants']) * 100) : 0; ?>%" aria-valuenow="<?php echo $event['registered_count']; ?>" aria-valuemin="0" aria-valuemax="<?php echo $event['max_participants']; ?>"></div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td>
                                                <a href="event_detail.php?id=<?php echo $event['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="event_participants.php?id=<?php echo $event['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-users"></i>
                                                </a>
                                                <form method="post" action="" class="d-inline">
                                                    <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                                    <button type="submit" name="cancel_event" class="btn btn-sm btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir annuler cet événement? Tous les participants seront notifiés.')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    
                    <hr class="my-4">
                    
                    <h5 class="mb-3">Événements passés</h5>
                    <?php if (empty($past_events)): ?>
                        <div class="alert alert-info">Aucun événement passé.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped" id="pastEventsTable">
                                <thead>
                                    <tr>
                                        <th>Titre</th>
                                        <th>Type</th>
                                        <th>Date</th>
                                        <th>Lieu</th>
                                        <th>Animateur</th>
                                        <th>Participation</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($past_events as $event): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($event['title']); ?></td>
                                            <td><?php echo htmlspecialchars($event['event_type']); ?></td>
                                            <td>
                                                <?php 
                                                echo date('d/m/Y H:i', strtotime($event['start_datetime']));
                                                if (date('Y-m-d', strtotime($event['start_datetime'])) === date('Y-m-d', strtotime($event['end_datetime']))) {
                                                    echo ' - ' . date('H:i', strtotime($event['end_datetime']));
                                                } else {
                                                    echo '<br>au ' . date('d/m/Y H:i', strtotime($event['end_datetime']));
                                                }
                                                ?>
                                            </td>
                                            <td><?php echo $event['is_virtual'] ? 'Événement virtuel' : htmlspecialchars($event['location']); ?></td>
                                            <td><?php echo $event['first_name'] ? htmlspecialchars($event['first_name'] . ' ' . $event['last_name']) : 'Non spécifié'; ?></td>
                                            <td>
                                                <?php echo $event['attended_count']; ?> / <?php echo $event['registered_count']; ?> participants
                                            </td>
                                            <td>
                                                <a href="event_detail.php?id=<?php echo $event['id']; ?>" class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="event_participants.php?id=<?php echo $event['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-users"></i>
                                                </a>
                                                <a href="event_report.php?id=<?php echo $event['id']; ?>" class="btn btn-sm btn-secondary">
                                                    <i class="fas fa-chart-bar"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="createEventModal" tabindex="-1" role="dialog" aria-labelledby="createEventModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createEventModalLabel">Créer un nouvel événement</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="post" action="">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="title">Titre *</label>
                                <input type="text" name="title" id="title" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="event_type_id">Type d'événement *</label>
                                <select name="event_type_id" id="event_type_id" class="form-control" required>
                                    <option value="">Sélectionner un type</option>
                                    <?php foreach ($event_types as $type): ?>
                                        <option value="<?php echo $type['id']; ?>"><?php echo htmlspecialchars($type['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description *</label>
                        <textarea name="description" id="description" class="form-control" rows="3" required></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="provider_id">Prestataire (optionnel)</label>
                                <select name="provider_id" id="provider_id" class="form-control">
                                    <option value="">Aucun</option>
                                    <?php foreach ($providers as $provider): ?>
                                        <option value="<?php echo $provider['id']; ?>">
                                            <?php echo htmlspecialchars($provider['first_name'] . ' ' . $provider['last_name'] . ' (' . $provider['specialization'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="max_participants">Nombre maximum de participants (optionnel)</label>
                                <input type="number" name="max_participants" id="max_participants" class="form-control" min="1">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="form-check">
                            <input type="checkbox" name="is_virtual" id="is_virtual" class="form-check-input">
                            <label for="is_virtual" class="form-check-label">Événement virtuel</label>
                        </div>
                    </div>
                    
                    <div id="location_container" class="form-group">
                        <label for="location">Lieu</label>
                        <input type="text" name="location" id="location" class="form-control">
                    </div>
                    
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="start_date">Date de début *</label>
                                <input type="date" name="start_date" id="start_date" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="start_time">Heure de début *</label>
                                <input type="time" name="start_time" id="start_time" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="end_date">Date de fin *</label>
                                <input type="date" name="end_date" id="end_date" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="end_time">Heure de fin *</label>
                                <input type="time" name="end_time" id="end_time" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" name="create_event" class="btn btn-primary">Créer l'événement</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#upcomingEventsTable, #pastEventsTable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/French.json"
            },
            "order": [[2, 'asc']]
        });
        
        $('#is_virtual').change(function() {
            if($(this).is(':checked')) {
                $('#location_container').hide();
                $('#location').val('');
            } else {
                $('#location_container').show();
            }
        });
        
        let tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const tomorrowFormatted = tomorrow.toISOString().split('T')[0];
        $('#start_date, #end_date').val(tomorrowFormatted);
        
        $('#start_date').change(function() {
            const startDate = $(this).val();
            if($('#end_date').val() < startDate) {
                $('#end_date').val(startDate);
            }
        });
    });
</script>

<?php include '../includes/footer.php'; ?>