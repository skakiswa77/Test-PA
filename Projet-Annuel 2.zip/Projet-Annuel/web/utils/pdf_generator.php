// Dans web/utils/pdf_generator.php

<?php
require_once '../vendor/fpdf/fpdf.php';

class QuotePDF extends FPDF {
    function Header() {
      
        $this->Image('/web/assets/images/BCLogo.png', 10, 10, 30);
        

        $this->SetFont('Arial', 'B', 15);
        $this->Cell(0, 10, 'DEVIS', 0, 1, 'C');
        
        $this->SetFont('Arial', '', 10);
        $this->Cell(0, 5, 'BusinessCare', 0, 1, 'R');
        $this->Cell(0, 5, '123 Rue des Entreprises', 0, 1, 'R');
        $this->Cell(0, 5, '75000 Paris, France', 0, 1, 'R');
        $this->Cell(0, 5, 'Tel: 01 23 45 67 89', 0, 1, 'R');
        $this->Cell(0, 5, 'Email: contact@businesscare.com', 0, 1, 'R');
        
        $this->Line(10, 50, 200, 50);
        $this->Ln(15);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
    
    function ClientInfo($client) {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Informations client', 0, 1);
        
        $this->SetFont('Arial', '', 10);
        $this->Cell(30, 5, 'Nom:', 0);
        $this->Cell(0, 5, $client['name'], 0, 1);
        
        $this->Cell(30, 5, 'Entreprise:', 0);
        $this->Cell(0, 5, $client['company'], 0, 1);
        
        $this->Cell(30, 5, 'Adresse:', 0);
        $this->Cell(0, 5, $client['address'], 0, 1);
        
        $this->Cell(30, 5, 'Email:', 0);
        $this->Cell(0, 5, $client['email'], 0, 1);
        
        $this->Cell(30, 5, 'Téléphone:', 0);
        $this->Cell(0, 5, $client['phone'], 0, 1);
        
        $this->Ln(10);
    }
    
    function QuoteDetails($quote) {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Détails du devis', 0, 1);
        
        $this->SetFont('Arial', '', 10);
        $this->Cell(40, 5, 'Numéro de devis:', 0);
        $this->Cell(0, 5, $quote['id'], 0, 1);
        
        $this->Cell(40, 5, 'Date:', 0);
        $this->Cell(0, 5, $quote['date'], 0, 1);
        
        $this->Cell(40, 5, 'Validité:', 0);
        $this->Cell(0, 5, $quote['validity'], 0, 1);
        
        $this->Ln(10);
    }
    
    function ItemsTable($items) {
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(10, 7, '#', 1, 0, 'C');
        $this->Cell(90, 7, 'Description', 1, 0, 'C');
        $this->Cell(30, 7, 'Quantité', 1, 0, 'C');
        $this->Cell(30, 7, 'Prix unitaire', 1, 0, 'C');
        $this->Cell(30, 7, 'Total', 1, 1, 'C');
        
        $this->SetFont('Arial', '', 10);
        
        $totalHT = 0;
        $i = 1;
        
        foreach ($items as $item) {
            $this->Cell(10, 6, $i, 1, 0, 'C');
            $this->Cell(90, 6, $item['description'], 1, 0);
            $this->Cell(30, 6, $item['quantity'], 1, 0, 'C');
            $this->Cell(30, 6, number_format($item['price'], 2) . ' €', 1, 0, 'R');
            $total = $item['quantity'] * $item['price'];
            $this->Cell(30, 6, number_format($total, 2) . ' €', 1, 1, 'R');
            $totalHT += $total;
            $i++;
        }
        
        $this->Cell(130, 6, '', 0, 0);
        $this->Cell(30, 6, 'Total HT:', 1, 0, 'R');
        $this->Cell(30, 6, number_format($totalHT, 2) . ' €', 1, 1, 'R');
        
        $tva = $totalHT * 0.2;
        $this->Cell(130, 6, '', 0, 0);
        $this->Cell(30, 6, 'TVA (20%):', 1, 0, 'R');
        $this->Cell(30, 6, number_format($tva, 2) . ' €', 1, 1, 'R');
        

        $totalTTC = $totalHT + $tva;
        $this->SetFont('Arial', 'B', 10);
        $this->Cell(130, 6, '', 0, 0);
        $this->Cell(30, 6, 'Total TTC:', 1, 0, 'R');
        $this->Cell(30, 6, number_format($totalTTC, 2) . ' €', 1, 1, 'R');
    }
    
    function Terms() {
        $this->Ln(10);
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Conditions et modalités', 0, 1);
        
        $this->SetFont('Arial', '', 10);
        $this->MultiCell(0, 5, "1. Ce devis est valable pour une durée de 30 jours à compter de la date d'émission.\n2. Les prix indiqués sont en euros et hors taxes, sauf indication contraire.\n3. Le paiement s'effectue à 50% à la commande et 50% à la livraison.\n4. Les délais de livraison sont donnés à titre indicatif.\n5. Ce devis est soumis à nos conditions générales de vente.");
    }
}

function generateQuotePDF($quoteData) {
    $pdf = new QuotePDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();

    $pdf->ClientInfo($quoteData['client']);
    
    $pdf->QuoteDetails($quoteData['quote']);
    
    $pdf->ItemsTable($quoteData['items']);
    
    $pdf->Terms();
    
    $filename = 'devis_' . $quoteData['quote']['id'] . '.pdf';
    $pdf->Output('D', $filename);
}
?>