<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Cartes NFC</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

<?php

require_once '../../config/database.php';

$stmt = $pdo->query("SELECT n.*, CONCAT(u.first_name, ' ', u.last_name) as user_name 
                    FROM nfc_cards n 
                    JOIN users u ON n.user_id = u.id 
                    WHERE n.is_active = 1
                    ORDER BY n.issued_date DESC");
$nfc_cards = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php require_once '../../composants/nav.php'; ?>

<h2>Gestion des Cartes NFC</h2>
<a href="add.php">Ajouter une carte NFC</a>
<table>
    <tr>
        <th>ID</th>
        <th>Utilisateur</th>
        <th>UID de la carte</th>
        <th>Statut</th>
        <th>Date d'émission</th>
        <th>Date de création</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($nfc_cards as $card): ?>
        <tr>
            <td><?php echo $card['id']; ?></td>
            <td><?php echo htmlspecialchars($card['user_name']); ?></td>
            <td><?php echo htmlspecialchars($card['card_uid']); ?></td>
            <td><?php echo $card['is_active'] ? 'Active' : 'Inactive'; ?></td>
            <td><?php echo date('d/m/Y', strtotime($card['issued_date'])); ?></td>
            <td><?php echo date('d/m/Y', strtotime($card['created_at'])); ?></td>
            <td>
                <a href="edit.php?id=<?php echo $card['id']; ?>">Modifier</a>
                <a href="deactivate.php?id=<?php echo $card['id']; ?>"
                    onclick="return confirm('Voulez-vous vraiment désactiver cette carte?')">Désactiver</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

</body>
</html>