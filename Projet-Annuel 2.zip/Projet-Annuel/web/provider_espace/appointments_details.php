<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'provider') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que prestataire.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$db = Database::getInstance();
$pageTitle = "Détails du Rendez-vous";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    setAlert('ID de rendez-vous invalide.', 'danger');
    redirect('appointments.php');
    exit;
}

$appointmentId = (int)$_GET['id'];

try {
    $appointment = $db->query(
        "SELECT a.*, u.first_name, u.last_name, u.email, u.phone, 
                u.gender, u.birthdate, c.name as company_name 
         FROM medical_appointments a
         JOIN users u ON a.user_id = u.id
         LEFT JOIN companies c ON u.company_id = c.id
         WHERE a.id = ? AND a.provider_id = ?
         LIMIT 1",
        [$appointmentId, $_SESSION['user_id']],
        true
    );

    if (!$appointment) {
        setAlert('Rendez-vous non trouvé ou vous n\'êtes pas autorisé à y accéder.', 'danger');
        redirect('appointments.php');
        exit;
    }
} catch (Exception $e) {
    setAlert('Erreur lors du chargement des détails du rendez-vous: ' . $e->getMessage(), 'danger');
    redirect('appointments.php');
    exit;
}


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-md-8">
            <h1 class="h3 mb-0">Détails du Rendez-vous</h1>
        </div>
        <div class="col-md-4 text-end">
            <a href="appointments.php" class="btn btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i> Retour aux rendez-vous
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informations sur le rendez-vous</h6>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p class="mb-1 text-muted">Date et heure</p>
                            <p class="mb-3 fw-bold">
                                <?= date('d/m/Y à H:i', strtotime($appointment['appointment_datetime'])) ?>
                            </p>

                            <p class="mb-1 text-muted">Statut</p>
                            <?php
                            $statusClass = '';
                            $statusText = '';
                            
                            switch ($appointment['status']) {
                                case 'confirmed':
                                    $statusClass = 'success';
                                    $statusText = 'Confirmé';
                                    break;
                                case 'cancelled':
                                    $statusClass = 'danger';
                                    $statusText = 'Annulé';
                                    break;
                                case 'completed':
                                    $statusClass = 'info';
                                    $statusText = 'Terminé';
                                    break;
                                default:
                                    $statusClass = 'warning';
                                    $statusText = 'En attente';
                            }
                            ?>
                            <p class="mb-3">
                                <span class="badge bg-<?= $statusClass ?>"><?= $statusText ?></span>
                            </p>

                            <p class="mb-1 text-muted">Type de consultation</p>
                            <p class="mb-3">
                                <?= $appointment['is_virtual'] ? 'Virtuelle (Téléconsultation)' : 'Présentielle' ?>
                            </p>
                        </div>
                        
                        <div class="col-md-6">
                            <p class="mb-1 text-muted">Notes</p>
                            <p class="mb-3">
                                <?= htmlspecialchars($appointment['notes'] ?? 'Aucune note') ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informations sur le patient</h6>
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($appointment['first_name'] . ' ' . $appointment['last_name']) ?></h5>
                    
                    <p class="mb-1 text-muted small">Entreprise</p>
                    <p class="mb-3"><?= htmlspecialchars($appointment['company_name'] ?? 'Non spécifié') ?></p>
                    
                    <p class="mb-1 text-muted small">Email</p>
                    <p class="mb-3"><?= htmlspecialchars($appointment['email']) ?></p>
                    
                    <p class="mb-1 text-muted small">Téléphone</p>
                    <p class="mb-3"><?= htmlspecialchars($appointment['phone'] ?? 'Non spécifié') ?></p>
                    
                    <?php if ($appointment['gender'] || $appointment['birthdate']): ?>
                    <p class="mb-1 text-muted small">Informations personnelles</p>
                    <p class="mb-3">
                        <?php if ($appointment['gender']): ?>
                            <?= $appointment['gender'] == 'male' ? 'Homme' : 'Femme' ?><br>
                        <?php endif; ?>
                        
                        <?php if ($appointment['birthdate']): ?>
                            Né(e) le <?= date('d/m/Y', strtotime($appointment['birthdate'])) ?>
                            (<?= date('Y') - date('Y', strtotime($appointment['birthdate'])) ?> ans)
                        <?php endif; ?>
                    </p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Actions</h6>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <?php if ($appointment['status'] == 'pending'): ?>
                            <a href="appointment_action.php?id=<?= $appointment['id'] ?>&action=confirm" class="btn btn-success">
                                <i class="fas fa-check me-1"></i> Confirmer
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($appointment['status'] != 'cancelled' && $appointment['status'] != 'completed'): ?>
                            <a href="appointment_action.php?id=<?= $appointment['id'] ?>&action=cancel" class="btn btn-danger" 
                               onclick="return confirm('Êtes-vous sûr de vouloir annuler ce rendez-vous?')">
                                <i class="fas fa-times me-1"></i> Annuler
                            </a>
                        <?php endif; ?>
                        
                        <?php if ($appointment['status'] == 'confirmed' || $appointment['status'] == 'completed'): ?>
                            <a href="appointment_report.php?id=<?= $appointment['id'] ?>" class="btn btn-primary">
                                <i class="fas fa-file-medical me-1"></i> Gérer le compte rendu
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include_once __DIR__ . '/../includes/footer.php';
?>