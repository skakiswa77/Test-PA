<div class="container text-center py-5">
    <h1 class="display-1 text-danger">404</h1>
    <h2 class="mb-4">Page non trouvée</h2>
    <p class="lead mb-4">Désolé, la page que vous recherchez n'existe pas ou a été déplacée.</p>
    <div>
        <a href="index.php" class="btn btn-primary">Retour à l'accueil</a>
    </div>
</div>