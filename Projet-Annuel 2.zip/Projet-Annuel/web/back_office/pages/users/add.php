<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Utilisateurs</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
require_once '../../composants/nav.php';
require_once '../../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, email, phone, gender, birthdate, 
                          address, postal_code, city, password, role, company_id, is_active, created_at, updated_at) 
                          VALUES (:first_name, :last_name, :email, :phone, :gender, :birthdate, 
                          :address, :postal_code, :city, :password, :role, :company_id, :is_active, NOW(), NOW())");

        $stmt->execute([
            ':first_name' => $_POST['first_name'],
            ':last_name' => $_POST['last_name'],
            ':email' => $_POST['email'],
            ':phone' => $_POST['phone'],
            ':gender' => $_POST['gender'],
            ':birthdate' => $_POST['birthdate'],
            ':address' => $_POST['address'],
            ':postal_code' => $_POST['postal_code'],
            ':city' => $_POST['city'],
            ':password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
            ':role' => $_POST['role'],
            ':company_id' => !empty($_POST['company_id']) ? $_POST['company_id'] : null,
            ':is_active' => isset($_POST['is_active']) ? 1 : 0
        ]);

        header("Location: index.php");
        exit();
    }

    $stmt = $pdo->query("SELECT id, name FROM companies ORDER BY name");
    $companies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Ajouter un utilisateur</h2>
    <form method="POST">
        <label for="first_name">Prénom</label>
        <input type="text" name="first_name" id="first_name" placeholder="Prénom" required><br>

        <label for="last_name">Nom</label>
        <input type="text" name="last_name" id="last_name" placeholder="Nom" required><br>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" placeholder="Email" required><br>

        <label for="phone">Téléphone</label>
        <input type="text" name="phone" id="phone" placeholder="Téléphone"><br>

        <label for="gender">Genre</label>
        <select name="gender" id="gender">
            <option value="M">Homme</option>
            <option value="F">Femme</option>
            <option value="">Non spécifié</option>
        </select><br>

        <label for="birthdate">Date de naissance</label>
        <input type="date" name="birthdate" id="birthdate"><br>

        <label for="address">Adresse</label>
        <input type="text" name="address" id="address" placeholder="Adresse"><br>

        <label for="postal_code">Code postal</label>
        <input type="text" name="postal_code" id="postal_code" placeholder="Code postal"><br>

        <label for="city">Ville</label>
        <input type="text" name="city" id="city" placeholder="Ville"><br>

        <label for="password">Mot de passe</label>
        <input type="password" name="password" id="password" placeholder="Mot de passe" required><br>

        <label for="role">Rôle</label>
        <select name="role" id="role" required>
            <option value="admin">Administrateur</option>
            <option value="company_admin">Admin d'entreprise</option>
            <option value="employee">Employé</option>
            <option value="provider">Prestataire</option>
        </select><br>

        <label for="company_id">Entreprise</label>
        <select name="company_id" id="company_id">
            <option value="">Aucune entreprise</option>
            <?php foreach ($companies as $company): ?>
                <option value="<?php echo $company['id']; ?>">
                    <?php echo htmlspecialchars($company['name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="is_active">Compte actif</label>
        <input type="checkbox" name="is_active" id="is_active" checked><br>

        <button type="submit">Ajouter</button>
    </form>

</body>

</html>