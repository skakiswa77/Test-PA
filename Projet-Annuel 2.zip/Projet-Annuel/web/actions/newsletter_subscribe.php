<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);


$webPath = dirname(__DIR__);

require_once $webPath . '/config/config.php';
require_once $webPath . '/utils/database.php';
require_once $webPath . '/utils/helpers.php';

require_once $webPath . '/vendor/phpmailer/phpmailer/src/Exception.php';
require_once $webPath . '/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require_once $webPath . '/vendor/phpmailer/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

$db = Database::getInstance();

function sendNewsletterEmail($email) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'businesscareams@gmail.com';
        $mail->Password   = 'jtew sppg slcq xpqr'; 
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';
        
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];
        
        $mail->setFrom('businesscareams@gmail.com', 'BusinessCare');
        $mail->addAddress($email);
        
        $mail->isHTML(true);
        $mail->Subject = "Votre inscription à la newsletter BusinessCare";
        $mail->Body    = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Newsletter BusinessCare</title>
        </head>
        <body>
            <div style="max-width: 600px; margin: 0 auto; padding: 20px; font-family: Arial, sans-serif;">
                <div style="background-color: #4CAF50; color: white; padding: 10px; text-align: center;">
                    <h1>BusinessCare</h1>
                </div>
                <div style="padding: 20px; background-color: #f9f9f9;">
                    <h2>Merci pour votre inscription!</h2>
                    <p>Bonjour,</p>
                    <p>Nous sommes ravis de vous compter parmi nos abonnés. Vous recevrez désormais nos dernières actualités et offres directement dans votre boîte mail.</p>
                </div>
                <div style="padding: 10px; text-align: center; font-size: 12px; color: #777;">
                    <p>© ' . date('Y') . ' BusinessCare. Tous droits réservés.</p>
                </div>
            </div>
        </body>
        </html>
        ';
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Erreur d'envoi d'email: " . $e->getMessage());
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['alert'] = [
            'type' => 'danger',
            'message' => 'Veuillez fournir une adresse email valide.'
        ];
        header("Location: " . $_SERVER['HTTP_REFERER'] ?? '../index.php');
        exit;
    }
    
    try {
        try {
            $db->execute("
                CREATE TABLE IF NOT EXISTS newsletter_subscribers (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    email VARCHAR(255) NOT NULL UNIQUE,
                    subscription_date DATETIME NOT NULL,
                    status ENUM('active', 'inactive') DEFAULT 'active'
                )
            ");
        } catch (Exception $e) {
        }
        
        $isNewSubscriber = false;
        $checkResult = $db->query("SELECT id FROM newsletter_subscribers WHERE email = ?", [$email], true);
        
        if (!$checkResult) {
            $isNewSubscriber = true;
            $db->insert('newsletter_subscribers', [
                'email' => $email,
                'subscription_date' => date('Y-m-d H:i:s')
            ]);
        }
        
        $emailSent = sendNewsletterEmail($email);
        
        if ($isNewSubscriber) {
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Merci de vous être abonné à notre newsletter.' . 
                            ($emailSent ? ' Un email de confirmation a été envoyé.' : '')
            ];
        } else {
            $_SESSION['alert'] = [
                'type' => 'success',
                'message' => 'Vous êtes déjà inscrit à notre newsletter.' . 
                            ($emailSent ? ' Un email vous a été envoyé.' : '')
            ];
        }
        
        header("Location: " . $_SERVER['HTTP_REFERER'] ?? '../index.php');
        exit;
    } catch (Exception $e) {
        $_SESSION['alert'] = [
            'type' => 'danger',
            'message' => 'Une erreur technique est survenue: ' . $e->getMessage()
        ];
        error_log("Erreur newsletter: " . $e->getMessage());
        header("Location: " . $_SERVER['HTTP_REFERER'] ?? '../index.php');
        exit;
    }
} else {
    header("Location: ../index.php");
    exit;
}
?>