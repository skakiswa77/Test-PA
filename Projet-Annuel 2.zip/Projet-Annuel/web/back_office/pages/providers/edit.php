<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Prestataire</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php
    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    $id = $_GET['id'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $stmt = $pdo->prepare("UPDATE provider_profiles SET 
                          specialization_id = :specialization_id,
                          bio = :bio,
                          hourly_rate = :hourly_rate,
                          is_verified = :is_verified,
                          updated_at = NOW()
                          WHERE id = :id");
        $stmt->execute([
            ':specialization_id' => $_POST['specialization_id'],
            ':bio' => $_POST['bio'],
            ':hourly_rate' => $_POST['hourly_rate'],
            ':is_verified' => isset($_POST['is_verified']) ? 1 : 0,
            ':id' => $id
        ]);
        header("Location: index.php");
        exit();
    }

    $stmt = $pdo->prepare("SELECT pp.*, u.first_name, u.last_name, u.email, u.phone 
                      FROM provider_profiles pp
                      JOIN users u ON pp.user_id = u.id
                      WHERE pp.id = ?");
    $stmt->execute([$id]);
    $provider = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, name, description FROM provider_specializations ORDER BY name");
    $specializations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Modifier un Prestataire</h2>
    <form method="POST">
        <label for="provider_info">Informations du prestataire</label>
        <input type="text" id="provider_info"
            value="<?php echo htmlspecialchars($provider['first_name'] . ' ' . $provider['last_name'] . ' - ' . $provider['email']); ?>"
            disabled><br>

        <label for="specialization_id">Spécialisation</label>
        <select name="specialization_id" id="specialization_id" required>
            <option value="">Sélectionner une spécialisation</option>
            <?php foreach ($specializations as $specialization): ?>
                <option value="<?php echo $specialization['id']; ?>" <?php if ($provider['specialization_id'] == $specialization['id'])
                       echo 'selected'; ?>>
                    <?php echo htmlspecialchars($specialization['name'] . ' - ' . $specialization['description']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="bio">Biographie</label>
        <textarea name="bio" id="bio" rows="4"><?php
        echo htmlspecialchars($provider['bio'] ?? '');
        ?></textarea><br>

        <label for="hourly_rate">Taux horaire (€)</label>
        <input type="number" name="hourly_rate" id="hourly_rate" step="0.01"
            value="<?php echo $provider['hourly_rate']; ?>" required><br>

        <label for="is_verified">Prestataire vérifié</label>
        <input type="checkbox" name="is_verified" id="is_verified" <?php if ($provider['is_verified'])
            echo 'checked'; ?>><br>

        <label for="rating">Note actuelle</label>
        <input type="text" id="rating"
            value="<?php echo $provider['rating'] > 0 ? number_format($provider['rating'], 1, ',', ' ') . '/5' : 'Aucune note'; ?>"
            disabled><br>

        <button type="submit">Mettre à jour</button>
    </form>

</body>

</html>