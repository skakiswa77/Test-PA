<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$employee_id = $_SESSION['user_id'];
$db = Database::getInstance();

$nfc_card = $db->query(
    "SELECT * FROM nfc_cards WHERE user_id = ?",
    [$employee_id],
    true
);

$access_logs = [];
if ($nfc_card) {
    $access_logs = $db->query(
        "SELECT nal.* FROM nfc_access_logs nal
        WHERE nal.card_id = ?
        ORDER BY nal.access_datetime DESC
        LIMIT 20",
        [$nfc_card['id']]
    );
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_new_card'])) {
    try {
        $db->beginTransaction();

        if ($nfc_card) {
            $db->execute(
                "UPDATE nfc_cards SET is_active = 0 WHERE id = ?",
                [$nfc_card['id']]
            );
        }
        $card_uid = bin2hex(random_bytes(8)); 
        
        $db->execute(
            "INSERT INTO nfc_cards (user_id, card_uid, is_active, issued_date)
            VALUES (?, ?, 1, CURDATE())",
            [$employee_id, $card_uid]
        );
        
        $db->commit();
        
        $success_message = "Votre demande de nouvelle carte NFC a été enregistrée. Vous serez notifié lorsqu'elle sera prête à être récupérée.";
        
        redirect('nfc-card.php');
        exit;
    } catch (Exception $e) {
        try {
            $db->rollBack();
        } catch (Exception $rollbackEx) {
            error_log("Erreur lors du rollback: " . $rollbackEx->getMessage());
        }
        $error_message = "Une erreur est survenue lors de la demande de nouvelle carte: " . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deactivate_card'])) {
    try {
        $db->execute(
            "UPDATE nfc_cards
            SET is_active = 0
            WHERE id = ? AND user_id = ?",
            [$_POST['card_id'], $employee_id]
        );
        
        $success_message = "Votre carte NFC a été désactivée avec succès.";
        
    
        redirect('nfc-card.php');
        exit;
    } catch (Exception $e) {
        $error_message = "Une erreur est survenue lors de la désactivation de la carte: " . $e->getMessage();
    }
}

?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Ma carte NFC</h4>
                </div>
                <div class="card-body">
                    <?php if (isset($success_message)): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    
                    <?php if ($nfc_card && $nfc_card['is_active']): ?>
                        <div class="alert alert-info">
                            Votre carte NFC est active et peut être utilisée pour accéder aux locaux de BusinessCare et aux événements.
                        </div>
                        
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Informations de la carte</h5>
                                        <p><strong>Numéro de carte:</strong> <?php echo htmlspecialchars(substr($nfc_card['card_uid'], 0, 4) . '...' . substr($nfc_card['card_uid'], -4)); ?></p>
                                        <p><strong>Date d'émission:</strong> <?php echo date('d/m/Y', strtotime($nfc_card['issued_date'])); ?></p>
                                        <p><strong>Statut:</strong> <span class="badge badge-success">Active</span></p>
                                        
                                        <form method="post" action="" onsubmit="return confirm('Êtes-vous sûr de vouloir désactiver votre carte NFC? Vous ne pourrez plus l\'utiliser pour accéder aux locaux.');">
                                            <input type="hidden" name="card_id" value="<?php echo $nfc_card['id']; ?>">
                                            <button type="submit" name="deactivate_card" class="btn btn-danger btn-sm">Signaler perte / Désactiver</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="card-title">Carte virtuelle</h5>
                                        <div class="p-3 border rounded mb-3" style="background-color: #f8f9fa;">
                                            <img src="../assets/img/nfc-logo.png" alt="Logo NFC" class="img-fluid mb-2" style="max-height: 50px;">
                                            <h5>BusinessCare</h5>
                                            <p class="mb-0">Carte d'accès</p>
                                            <hr>
                                            <p class="mb-0"><strong>ID: </strong><?php echo htmlspecialchars(substr($nfc_card['card_uid'], 0, 4) . '...' . substr($nfc_card['card_uid'], -4)); ?></p>
                                            <p class="mb-0"><strong>Date: </strong><?php echo date('d/m/Y', strtotime($nfc_card['issued_date'])); ?></p>
                                        </div>
                                        <small class="text-muted">Cette carte virtuelle ne remplace pas votre carte physique.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <?php if (!empty($access_logs)): ?>
                            <h5>Historique des accès récents</h5>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Date et heure</th>
                                            <th>Localisation</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($access_logs as $log): ?>
                                            <tr>
                                                <td><?php echo date('d/m/Y H:i', strtotime($log['access_datetime'])); ?></td>
                                                <td><?php echo htmlspecialchars($log['location']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                        
                    <?php elseif ($nfc_card && !$nfc_card['is_active']): ?>
                        <div class="alert alert-warning">
                            Votre carte NFC a été désactivée. Si vous avez besoin d'une nouvelle carte, veuillez faire une demande ci-dessous.
                        </div>
                        
                    <?php else: ?>
                        <div class="alert alert-info">
                            Vous n'avez pas encore de carte NFC. Cette carte vous permettra d'accéder aux locaux de BusinessCare et aux événements.
                        </div>
                        
                        <form method="post" action="">
                            <button type="submit" name="request_new_card" class="btn btn-primary">Demander une carte NFC</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>