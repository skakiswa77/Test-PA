<?php
session_start();
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../utils/database.php';
require_once __DIR__ . '/../utils/helpers.php';
require_once __DIR__ . '/../utils/auth.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'employee') {
    setAlert('Accès non autorisé. Veuillez vous connecter en tant que employé.', 'danger');
    redirect(APP_URL . '/index.php?page=login');
    exit;
}

$employee_id = $_SESSION['user_id'];
$db = Database::getInstance();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_event'])) {
    $event_id = $_POST['event_id'];
    
    try {
        $registration = $db->query(
            "SELECT id FROM event_registrations 
            WHERE event_id = ? AND user_id = ?",
            [$event_id, $employee_id],
            true
        );
        
        if ($registration) {
            $error_message = "Vous êtes déjà inscrit à cet événement.";
        } else {
            $db->execute(
                "INSERT INTO event_registrations (event_id, user_id, status)
                VALUES (?, ?, 'pending')",
                [$event_id, $employee_id]
            );
            
            $success_message = "Votre inscription à l'événement a bien été enregistrée.";
        }
    } catch (Exception $e) {
        $error_message = "Une erreur est survenue lors de l'inscription à l'événement: " . $e->getMessage();
    }
}

$upcoming_events = $db->query(
    "SELECT e.*, et.name as event_type, u.first_name, u.last_name,
           (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id) as registered_count,
           (SELECT COUNT(*) FROM event_registrations er WHERE er.event_id = e.id AND er.user_id = ?) as is_registered
    FROM events e
    JOIN event_types et ON e.event_type_id = et.id
    LEFT JOIN provider_profiles pp ON e.provider_id = pp.id
    LEFT JOIN users u ON pp.user_id = u.id
    WHERE e.start_datetime >= NOW()
    ORDER BY e.start_datetime ASC",
    [$employee_id]
);

$my_events = $db->query(
    "SELECT e.*, et.name as event_type, er.status as registration_status, u.first_name, u.last_name
    FROM event_registrations er
    JOIN events e ON er.event_id = e.id
    JOIN event_types et ON e.event_type_id = et.id
    LEFT JOIN provider_profiles pp ON e.provider_id = pp.id
    LEFT JOIN users u ON pp.user_id = u.id
    WHERE er.user_id = ?
    ORDER BY e.start_datetime DESC",
    [$employee_id]
);


?>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<div class="container mt-4">
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Événements à venir</h4>
                </div>
                <div class="card-body">
                    <?php if (empty($upcoming_events)): ?>
                        <div class="alert alert-info">Aucun événement à venir pour le moment.</div>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($upcoming_events as $event): ?>
                                <div class="col-md-4 mb-4">
                                    <div class="card h-100">
                                        <div class="card-header bg-light">
                                            <h5 class="card-title"><?php echo htmlspecialchars($event['title']); ?></h5>
                                            <h6 class="card-subtitle text-muted"><?php echo htmlspecialchars($event['event_type']); ?></h6>
                                        </div>
                                        <div class="card-body">
                                            <p><strong>Date:</strong> <?php echo date('d/m/Y H:i', strtotime($event['start_datetime'])); ?></p>
                                            <p><strong>Lieu:</strong> <?php echo $event['is_virtual'] ? 'Événement virtuel' : htmlspecialchars($event['location']); ?></p>
                                            <p><strong>Animateur:</strong> <?php echo $event['first_name'] ? htmlspecialchars($event['first_name'] . ' ' . $event['last_name']) : 'Non spécifié'; ?></p>
                                            <p><?php echo nl2br(htmlspecialchars(substr($event['description'], 0, 100) . (strlen($event['description']) > 100 ? '...' : ''))); ?></p>
                                            
                                            <p>
                                                <small class="text-muted">
                                                    <?php echo $event['registered_count']; ?> participant(s) inscrit(s)
                                                    <?php echo $event['max_participants'] ? ' / ' . $event['max_participants'] . ' places' : ''; ?>
                                                </small>
                                            </p>
                                        </div>
                                        <div class="card-footer">
                                            
                                            <?php if ($event['is_registered']): ?>
                                                <span class="badge badge-success">Vous êtes inscrit</span>
                                            <?php else: ?>
                                                <?php if (!$event['max_participants'] || $event['registered_count'] < $event['max_participants']): ?>
                                                    <form method="post" action="" class="d-inline">
                                                        <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                                                        <button type="submit" name="register_event" class="btn btn-primary btn-sm">S'inscrire</button>
                                                    </form>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">Complet</span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h4>Mes événements</h4>
                </div>
                <div class="card-body">
                    <?php if (empty($my_events)): ?>
                        <div class="alert alert-info">Vous n'êtes inscrit à aucun événement pour le moment.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Titre</th>
                                        <th>Type</th>
                                        <th>Date et heure</th>
                                        <th>Animateur</th>
                                        <th>Statut</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($my_events as $event): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($event['title']); ?></td>
                                            <td><?php echo htmlspecialchars($event['event_type']); ?></td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($event['start_datetime'])); ?></td>
                                            <td><?php echo $event['first_name'] ? htmlspecialchars($event['first_name'] . ' ' . $event['last_name']) : 'Non spécifié'; ?></td>
                                            <td>
                                                <?php 
                                                switch ($event['registration_status']) {
                                                    case 'pending':
                                                        echo '<span class="badge badge-warning">En attente</span>';
                                                        break;
                                                    case 'confirmed':
                                                        echo '<span class="badge badge-success">Confirmé</span>';
                                                        break;
                                                    case 'cancelled':
                                                        echo '<span class="badge badge-danger">Annulé</span>';
                                                        break;
                                                    case 'attended':
                                                        echo '<span class="badge badge-info">Participé</span>';
                                                        break;
                                                }
                                                ?>
                                            </td>
                                            <td>
                                                <?php if ($event['registration_status'] === 'pending' || $event['registration_status'] === 'confirmed'): ?>
                                                    <?php if (strtotime($event['start_datetime']) > time()): ?>
                                                        <a href="cancel_registration.php?id=<?php echo $event['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir annuler votre inscription?')">Annuler</a>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>