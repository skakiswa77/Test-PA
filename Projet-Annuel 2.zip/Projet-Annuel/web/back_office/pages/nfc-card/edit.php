<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Carte NFC</title>
    <link rel="stylesheet" href="../../assets/style.css">
</head>

<body>

    <?php

    require_once '../../composants/nav.php';
    require_once '../../config/database.php';

    $id = $_GET['id'];


    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        $stmt = $pdo->prepare("UPDATE nfc_cards SET user_id = :user_id, card_uid = :card_uid, 
                          is_active = :is_active, issued_date = :issued_date, updated_at = NOW()
                          WHERE id = :id");
        $stmt->execute([
            ':user_id' => $_POST['user_id'],
            ':card_uid' => $_POST['card_uid'],
            ':is_active' => isset($_POST['is_active']) ? 1 : 0,
            ':issued_date' => $_POST['issued_date'],
            ':id' => $id
        ]);

        header("Location: index.php");
        exit();
    }


    $stmt = $pdo->prepare("SELECT * FROM nfc_cards WHERE id = ?");
    $stmt->execute([$id]);
    $card = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT id, first_name, last_name FROM users ORDER BY last_name, first_name");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <h2>Modifier une Carte NFC</h2>
    <form method="POST">
        <label for="user_id">Utilisateur</label>
        <select name="user_id" id="user_id" required>
            <option value="">Sélectionner un utilisateur</option>
            <?php foreach ($users as $user): ?>
                <option value="<?php echo $user['id']; ?>" <?php if ($card['user_id'] == $user['id'])
                       echo 'selected'; ?>>
                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="card_uid">UID de la carte</label>
        <input type="text" name="card_uid" id="card_uid" value="<?php echo htmlspecialchars($card['card_uid']); ?>"
            required><br>

        <label for="is_active">Carte active</label>
        <input type="checkbox" name="is_active" id="is_active" <?php if ($card['is_active'])
            echo 'checked'; ?>><br>

        <label for="issued_date">Date d'émission</label>
        <input type="date" name="issued_date" id="issued_date" value="<?php echo $card['issued_date']; ?>" required><br>

        <button type="submit">Mettre à jour la Carte</button>
    </form>

</body>

</html>